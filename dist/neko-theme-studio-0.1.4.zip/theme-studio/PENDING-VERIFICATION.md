# 待验证队列（verifier 结束后一次性跑）

在 `verify-v3` 报告之前**不写任何东西**：所有 `install.ps1` / `accept.ps1` /
`build-theme-css.ps1` / `page-eval` 探针都会改 theme.json 或重启插件服务，
污染它的量测。本文件只是把「等它说完要做的事」写下来，不执行。

## 背景：为什么现在必须停手

`verify-v3` 报告 theme.json 的 version 在 6 分钟内走了 `144 -> 1 -> 16`，并正确地
把它标记为「量测期间有人写入」。**那基本是我自己**：20:44–20:50 我跑了两次
`install.ps1`（内部会 `/plugins/reload`，重启插件服务）和三次 `accept.ps1`
（C/E 组调 `reset_theme`、D 组调 `apply_theme` 写 17 个变量）。
`panel-controls` 只改静态文件，已另行通知它不要碰 entry API。

教训（值得写进验收流程）：**一个会自动写共享状态的自检套件，不能在另一个
量测者正在取证时运行。** 真实页量测依赖「谁在写调色板」这一前提，破坏它就
等于破坏证据。

## 队列（按顺序，全部在 verifier 说明结束后才动）

1. **重跑 `test\accept.ps1`** —— 确认 `plugin\README.md` 与 `plugin\static\app.js`
   的最终版本没有破坏 F1（面板 UI 实操）。当前源与安装副本：
   - `plugin\static\app.js` 50138B，两边 sha256 一致（`3F50CF0C836FB7B0`）
     > 历史快照：这是**面板 UI 改版前**的尺寸。当前 `app.js` 1645 行 / 68K、`style.css` 1250 行 / 32K、
     > `index.html` 155 行 / 8K（详见文末「面板 UI 改版」），重跑 `install.ps1` 后两边应再次一致。
   - `plugin\README.md` 源 25031B vs 安装副本 25020B，**不一致**
     （panel-controls 在我上次 install 之后又改了 README）
   → 必须重跑 `install.ps1` 让安装副本与源同步，否则用户从市场装到的 README 是旧的。

2. **重跑 `install.ps1`** —— 验证 F7 的重启窗口重试逻辑（本次新增）。
   已单独验证过一次：`[OK] 已打开自动启动` / `[OK] 插件已在运行（status = 'running'）`
   / `✅ 全部通过（11 项）`。但那是 panel-controls 再改 README 之前的。
   期望：11/11 PASS、exit 0、插件 `running` + `auto_start=True`。

3. **重跑 `tools\build-theme-css.ps1`** —— 确认 `panel-controls` 的 README/app.js
   改动没有碰到 CSS 生成链。期望：exit 0、无 `fallback` 字样、
   零变化亮暗各 0 差异、覆盖亮暗各 110/110、第 5 步真实页 A/B 0 diff。

4. **`test\expr-verify-v3.js` 复跑** —— 确认 10 项 verdict 仍全 True
   （尤其 A 空调色板 0 差异、D `--nts-chat-opacity` 到达 0.33）。

5. **`plugin\__init__.py` 的 KNOWN_VARS 行为验证** —— 新增的未知变量名拒绝
   尚未在活服务上实测（只在文件层面核对过双向差集为 0）。
   要跑：`apply_theme` 传 `--nts-nope-var:'#fff'` 必须进 `rejected` 且**不落盘**；
   传 59 个合法名字之一必须被接受。
   期望：`rejected: ["vars: 未知变量名已拒绝 '--nts-nope-var'（拼写错误？见 README 变量清单）"]`。

6. **核查 v3 下是否还有「面板有控件、CSS 无人消费」** —— v3 全门控后
   这个检查的判据要改成「面板 CATALOG 的 key 集合 ⊇ 后端 KNOWN_VARS ⊆ CSS 出现的
   `--nts-*` 集合」，三者双向差集都应为空。已核对过前两者（59/59/59）。

7. **`THEME_CONTRACT.md` 归档** —— 已更新 §3.0/§3.1/§5/§8/§9.10–§9.12；本轮又补了
   §9.11（F7 重启窗口）与 §9.12（自建套件共享盲区，必须派对抗性验证者）。
   待 verifier 报告后如需再改，一并改完再定稿。

## 已知的、**故意**不修的东西（避免以后被当成缺陷重新"修"一遍）

- `plugin\static\theme.json` 出厂为空 `{"vars":{},"dark_vars":{}}`。这是故意的：
  任何 pin 死的默认值都会在「用户没配过」时改动外观。`reset_theme` 也回到空。
- 面板 CATALOG 的 `native` 字段**从不被读取**，只有 `.darkNative` 与 `.hint`
  会到用户眼前。`native` 只是文档；要影响用户必须写进 `hint`。
- 亮/暗两组**各管各的**（用户已拍板）：只配亮色时暗色保持原生，反之亦然。
  这不是缺陷，是需求。
- `--nts-button-hover-bg` 与 `--nts-highlight`（`::selection`）在静态页上
  无法验证（无指针 / 无选区），只能门控 + 真实页手测。
- 五处「无法在静态页判定」的量测行：`::selection | background-color`
  （UNQUERYABLE）+ 4 项 `:focus-visible`/`:hover`（NO-PSEUDO-STATE）。
  分母里已排除，不是覆盖缺口。
- 市场里没有本插件（134 项里 `theme` ×0）。用户说的「从插件市场安装」目前
  只能靠 `install.ps1` 或 `imported` 包；真上架市场是另一件事。

## 运行期判据（本轮新增，静态排查到此为止）

静态层面已经逐项排除：面板/后端/loader 三处校验器 464 用例 0 不一致；CSS 的 64 个目标选择器
在 `resources/bin/static` 全量 CSS 里全部存在；React bundle 无内联 `!important`（仅 2 处
Suspense 的 `display:none`）；页面无 CSP、无 shadow DOM、无 iframe；部署副本与源码 sha256 相同；
模板补丁渲染正常。**因此故障只可能出在运行期状态**，判据必须来自真实页面。

为此新增两个工具（不改动任何运行时行为，纯诊断）：

1. `theme-studio/test/diagnose-in-app.js` —— 在应用窗口 DevTools Console 整段粘贴即可运行的
   一次性表达式。按链路顺序检查 **12 项**：`loader-mounted` → `loader-version` → `css-link` →
   `css-sheet` → `fetch-theme-json` → `palette-nonempty` → `enabled` → `mode-has-values` →
   `style-injected` → `gates-applied` → `var-resolves` → `bubble-colored`，
   输出 `verdict = CHAIN OK | BREAK AT: <第一处失败>`。
   已在 jsdom + 真实 loader 下对 **9 个场景**验证过判读正确性（全链路通 / 调色板空 / loader 缺失 /
   拉取失败 / 暗色只配亮色 / 亮色只配暗色 / 主题被禁用 / CSS 解析不出规则 / loader 旧版无版本号），
   9/9 符合预期。后两项是自检中新增的：`<link>` 存在≠CSS 加载成功；旧 loader 缺 `scriptVersion` 是真实的部署漂移信号。
2. `theme-studio/test/diagnose-live.ps1` —— 包装 `tools/page-eval.js`，自动找 Chrome/Edge，
   用无头真 Blink 跑同一表达式。**本机无 Windows/PowerShell，未实跑，属 PENDING**；
   用户在真机跑一次即可把它从 PENDING 划掉。

配套文档：`theme-studio/TROUBLESHOOT.md`（按 verdict 的修法对照表 + 三个「以为是 bug 其实不是」）。

### loader 侧本轮同时修掉的两个隐性格（已同步到 `resources/bin/static/neko-theme-studio.js`）

- 旧 `fetchPalette` 只比 `version`：插件被重置后版本号回到 1、而缓存里也是 1 → **永远不再应用**。
  现改为「版本号 + `JSON.stringify` 内容」双判等才跳过。
- 面板「应用」在没有任何改动时仍提示成功（虚假成功）。现改为：亮/暗改动数与 `enabled` 都没变时
  直接告警「没有可应用的改动」；成功提示带上「亮色 N 项 / 暗色 M 项」与「只改了一组」的模式提醒。

### 自检轮（loader v1.1.0）再修掉四处

- **加了 `SCRIPT_VERSION` / `NekoThemeStudio.scriptVersion`**：新 CSS + 旧 loader（老条纹无 `data-nts-l-*` 门控）会让每条规则都门控失败 → 全无颜色，且完全静默。现在 `diagnose()` 与自检脚本都能直接看出 loader 版本。
- **number 类百分比归一**：`50%` → `"0.5"`，数值 >100 三方皆拒。踩坑记录：原正则 `/^[0-9]{1,3}(\.[0-9]+)?%$/` 的唯一捕获组是**小数部分**，直接取 `m[1]` 会让 `50%` 取到 undefined（判非法）、`33.3%` 取到 `.3`（算成 0.003）；已改用专用正则 `RE_PCT_FULL` + `pctToFraction()`。
- **样式表未加载时大声报警**：`document.styleSheets` 里找不到 `neko-theme-studio.css` 时 `console.warn` 一次（否则变量注入成功、无规则消费，表现就是"什么都没变"）。
- **storage 事件按「raw JSON + version」双判等**（原来只比 version，与 `fetchPalette` 口径不一致）。
- **只在单侧模式配了色时大声报警**：`applyPalette` 之后检查「当前模式（`html[data-theme]` / `.dark` / 系统配色）
  这一组是否为空、另一组是否有值」，是则 `console.warn` 一次并说明亮暗各管各的；
  `boot()` 里挂 `MutationObserver` 监听 `data-theme`/`class` 变化后重查（用户先配亮色、再切暗色的场景）。
  这是「面板显示已应用、本体一点没变」的头号成因，以前完全没有运行时反馈。
- **启动横幅**：`boot()` 打一行 `console.info('[theme-studio] loader v1.1.0 已加载，端点 …')`，
  「本体到底有没有加载到脚本」不必再靠猜。

三方校验器差分（`_local_verify/three_way.js` + `corpus.json`，59 变量 × 边界值 = 1894 cases）
**现为 0 不一致**。修前 191 例分两类：4 位 hex `#ffff`（面板/后端补 `[0-9a-f]{4}`）、
`50%`/`100%`/`101%`（面板/后端收、loader 拒）。另外后端/面板加严了负数拦截后，
loader 也镜像了同一条规则（负长度/负模糊一律拒），并移除了只有 loader 认的 `var(--nts-*)` 派生色：
独立语料 `_local_verify/backend/loader_vs_backend.js`（2124 例）同样 0 分歧。

> 注意：面板代码装在 `%LOCALAPPDATA%\N.E.K.O\.neko-plugin-packages\`，**改动要重跑
> `theme-studio/install.ps1` 才生效**；loader/CSS 在 `resources\bin\static\`，同样由 install 复制。

---

## 面板 UI 改版（插件 v0.1.2）—— 本机能测的都测了，剩下靠眼睛

三个文件全量重写：`plugin/static/style.css`（1250 行 / 32K，12 节，含暗色 token 与四个断点）、
`plugin/static/index.html`（155 行 / 8K，保留全部旧 id，面板从此有结构化的头部/工具栏/footer）、
`plugin/static/app.js`（1311 → 1645 行）。要点：

- **每行五列**：标签（含「已改 / 已清空」状态标记）｜色块或类型标签｜输入｜透明度或原生参考值｜清空按钮。
  颜色行以前**没有**清空按钮，要清掉一个已保存的颜色只能手删十六进制框 —— 本次补齐。
- 输入框 `placeholder` 显示该变量的原生参考值（`原生 #44b7fe` / `原生 12px`），
  长值退回「留空 = 原生」，省掉「我该填什么」的猜。
- 工具栏：搜索过滤（标签/变量名/提示文字）、只看改动、全部收起/展开；
  状态栏与通知有了 ok / warn / error / busy 四态（底部状态点 + 左侧色条 + 应用按钮 spinner）。
- 键盘：`/` 聚焦搜索、`Ctrl/⌘+Enter` 应用、`Esc` 清搜索或关弹窗、模式页签左右方向键、
  弹窗 Tab 焦点陷阱并在关闭后归还焦点；分组标题 `role=button` 可回车/空格折叠。
- 面板自身支持 `prefers-color-scheme: dark`（跟随**系统**，不是应用窗口里的亮/暗主题 —— 它在跨源 iframe 里）。
- 读取时顶部 2px 进度条；分组标题吸顶；提示文字默认单行、悬停展开；`prefers-reduced-motion` 下关掉动效。

配色对比度按 WCAG AA 小字标准（≥4.5:1）逐个算过并调整了 token：亮色 faint 5.07 / accent 5.18 /
danger 5.39 / ok 5.11 / warn 5.40、主按钮白字 5.18；暗色 faint 5.91 / accent 6.66、主按钮白字 4.92
（暗色不能直接拿 `--accent` 当按钮底色：白字只有 2.54，已单列 `--accent-fill`）。
随时可用 `_local_verify/ui_contrast.js` 复算。

本机跑过的验证（全部 exit 0）：`test/panel-smoke.js` 18/18、新建 `test/panel-ui.js` 41/41
（搜索命中数与 CATALOG 对齐、无命中提示、清空搜索、只看改动、颜色行清空按钮提交空串、
placeholder、分组折叠、复制 dump）、`_local_verify/ui_consistency.js`（app.js 引用 47 个 id
全部存在、无 CSS 类缺失）、三方与后端回归（1894 / 2124 例 0 分歧、206/206、acceptance_v2 全通过）。

**需要在 Windows 上人工看的（本机是 aarch64 容器，装不了 Chromium，无法真渲染）**：

1. 重跑 `install.ps1` → 打开面板，确认 1080px / 900px 以下 / 760px 以下三档布局不重叠、不横向滚动；
2. 把系统切到暗色（Windows 设置 → 个性化 → 颜色），确认面板整体跟着变暗、色块与文字对比度可读；
3. 键盘走一遍：`/` 搜索 → `Enter` 跳行 → 改值 → `Ctrl+Enter` 应用；`Esc` 关导出弹窗后焦点回到「导出」按钮；
4. 重跑 `test\accept.ps1`，确认 F1（真实面板键入→应用→落盘→重置）仍全绿 —— 它依赖
   `#btn-apply` 文案「应用（1 项改动）」、`.row.is-dirty`、`#notice` 文本，这三处本次没改语义；
5. 若发现按钮文案/行高与预期不符，多半是安装副本没更新：面板装在
   `%LOCALAPPDATA%\N.E.K.O\.neko-plugin-packages\`，改动必须重跑 `install.ps1`。


---

## 缺陷审计轮（插件 v0.1.3 / loader v1.1.1）—— 「改了没反应」的几类真实原因

这一轮不只看静态契约，而是按真实交互（jsdom 逐键输入、点色板、拖滑块、点清空、应用）复现并修掉：

| # | 症状 | 根因 | 修法 |
| --- | --- | --- | --- |
| 1 | 值是 `transparent` 的行，点色板选实色，画面依旧全透明 | 选中新颜色时继承了当前 alpha=0 | 全透明时按实色（alpha=1）处理；滑块本来就被置灰 |
| 2 | 值 `transparent` 在十六进制框里显示成 `#000000` | 解析后按 RGB 回写，丢了 alpha=0 | 全透明显示 `transparent`，滑块 disabled 并给出 title |
| 3 | 干净行点「清空」凭空多出 1 项改动 | 无条件记 `cleared`，提交空串 | 服务器本来没有该键时只撤销本地编辑；有值才记删除 |
| 4 | 改「聊天气泡圆角」，预览纹丝不动 | 预览所有圆角都读 `--nts-radius` | 外壳读 `--nts-shell-radius`、气泡读 `--nts-bubble-radius`，缺失才回退通用值 |
| 5 | 阴影/字体族逐个字符敲，空格被吃掉（`0 2px` → `02px`、`Segoe UI` → `SegoeUI`） | 每次 `input` 都 trim 后回写输入框 | 输入中保留原文、只对 trim 后的值做校验；`change` 时才定稿 |
| 6 | 合法 box-shadow 面板显示已应用，本体却没阴影 | 三处校验都只做 token 白名单，放行 `0 0 10% #000`（百分比非法）、`1px`（长度不足）、5 个长度等浏览器会整条丢弃的值；loader 还把 `rgba(0, 0, 0, .2)` 按空格拆碎 | 三处统一按 `inset? && length{2,4} && color?` 结构校验；loader 新增括号感知的 `shadowTokens()` |
| 7 | 清空「毛玻璃模糊」后预览仍带滤镜 | 预览只在有值时才写 `backdrop-filter` | 改为 `!== undefined` 判断并写空串；裸长度 `18px` 预览时归一成 `blur(18px)` |
| 8 | 应用后因后端拒绝而没生效的值，面板上直接消失 | 成功后无条件清空 `edited/cleared` | 解析 `rejected` 里的变量名，把原值回填并提示「已把原值放回面板便于就地修正」 |
| 9 | 应用一次后，全透明行的透明度滑块又能拖了（拖出纯黑） | `setBusy(false)` 无条件启用所有行控件 | 解锁时逐行重算：`transparent` / 解析失败的行继续置灰 |
| 10 | 搜索后按回车，焦点落在色块（无法键入） | `firstVisibleRow()` 第一个匹配是 `input.swatch` | 只找 `input.hex, input.raw` |
| 11 | 调试 API `NekoThemeStudio.clear()` 后调色板再也回不来 | `currentVersion/lastRaw` 没重置，轮询判定「无变化」 | `clear()` 一并重置判等缓存 |
| 12 | `diagnose()` 报的模式与实际级联不一致 | 只看 `data-theme`，忽略 `.dark` 类与 `prefers-color-scheme` | 改用 `currentMode()` |

验证（全部 exit 0）：`_local_verify/panel_bugs.js` 11 项（透明/清空/预览圆角/模糊/阴影标红/被拒回填）、
`test/panel-smoke.js` 18/18、`test/panel-ui.js` 41/41、`_local_verify/three_way.js` 1903 例 0 分歧、
`_local_verify/backend/loader_vs_backend.js` 2132 例 0 分歧、`audit_backend.py` 205/205、
`acceptance_v2.py` 全通过、`loader_smoke.js` CASE1–6、`diag_test.js` 9/9。

**Windows 上需要做的**：

1. 重跑 `theme-studio/install.ps1`（面板 + loader 都在安装副本里才生效），重启应用窗口；
2. Console 应出现 `[theme-studio] loader v1.2.0 已加载`，且 `NekoThemeStudio.scriptVersion === "1.2.0"`；
3. 若仍「面板显示已应用、本体不变」，先跑 `theme-studio/test/diagnose-in-app.js` 取 `VERDICT`，再看 Console 有无「单侧模式」告警。

已知取舍：`--nts-shadow` 的负值只允许出现在前两个长度（x/y 偏移）；负扩散半径是合法 CSS，但为了拦住同样会整条失效的负模糊半径，
三处统一从严 —— 面板会把负扩散标红而不是静默丢弃。
## 本轮（0.1.4 打包 + 卸载补齐）—— 已完成，无需再排期

| 项 | 结果 | 证据 |
| --- | --- | --- |
| `install.ps1 -Verify` | **13/13 PASS，exit 0** | 含两项「热更新哈希」（期望 `-4c8cf87c` / `-17fec53d`） |
| 真实应用补丁面 | **23 个模板**带标记 | `resources\bin\templates` 全量 ASCII 扫描 `NTS:BEGIN` |
| loader 五副本一致 | 36672B / `17fec53d` | `app\`、`plugin\static\loader\`、安装目录、`resources\bin\static\`、`app-patch\files\` |
| 端到端生效 | `data-nts-active=1`、`--nts-accent=#00c2ff`、`--nts-user-bubble-bg=#123456`、`cssRules=262` | 无头 Chrome（`tools\page-eval.js`）读 `http://localhost:48911/chat` |
| 分发包 | `dist\neko-theme-studio-0.1.4.zip`（约 455 KB / 68 项，含 `neko_theme_studio.neko-plugin`） | `tools\package-dist.ps1 -IncludePackage`，打完自检 15 个关键文件 |
| 分发包可用性 | 解压到假安装根后 `install.ps1 -SkipPluginInstall` → **6 项变更、13/13 PASS、exit 0** | 假根里预置 37 个**未打补丁**的模板作全新机器 |
| 卸载完整性 | 一次跑清 **23 个**模板（不只 chat/index），二次跑全部「没有标记，无需改动」 | 假安装根 + `-WhatIf` 与实跑两轮 |

### 本轮修掉的两个真实缺陷

1. **`uninstall.ps1` 只回滚 chat/index 两个模板**。`install.ps1` 补 2 个、插件 `_app_patch.py` 补 23 个，
   卸载却只认 2 个 → 另外 21 个模板里的标记段会永久残留，去加载已被删除的静态文件（每次开页面两个 404）。
   现改为「扫 `templates\*.html` 里含 `NTS:BEGIN` 的全部纳入」，chat/index 仍在列表头部。
2. **`uninstall.ps1` 把 `{{ static_asset_version }}` 当硬条件**。该变量原本只有少数模板有，
   但注入的标记行**自身带这个变量**，所以删前 23 个模板「都含有它」→ 删除后必然「缺少」→
   误判为「校验未通过 → 需整文件还原」。在假根上实测触发 12 个假警告。
   现改为只校验「标记数归零 + 仍有 `</html>` + 长度未腰斩」，哨兵完整性交给 `install.ps1 -Verify`
   针对真正拥有该变量的模板负责。

### 仍然是 PENDING 的（需要真机人眼）

- `--nts-button-hover-bg` / `--nts-highlight`：静态页无指针、无选区，只能门控 + 手测。
- 冷启动后宿主是否 autostart 拉起插件：本机 `agent_runtime_intent.json` 已是
  `analyzer_enabled: true` + `user_plugin_enabled: true`，重启实测 status=running；
  但「注册表空 → loader 自愈 refresh+start」这条路径没能在真实冷启动里稳定复现窗口期，
  只做了等价验证（base 指向死端口 / 404 前缀时 `reviveCount` 确实递增、`lastReviveError` 记录原因）。
- 真上架 N.E.K.O 插件市场：本机 48916 没有发布端点，需把包交给市场服务端。

---

## 修复轮（2026-11-15，本机实测）—— 0.1.4 已改并重打包

### 根因与修复（用户症状「面板显示已应用、窗口一点没变」）

| # | 根因 | 证据 | 修法 |
| --- | --- | --- | --- |
| 1 | 主题 CSS 只覆盖 `.chat-window` / `.chat-body` 等**紧凑态下 0 高且被 `transparent !important` 压平**的元素，真正可见的胶囊 `::before` 与 HUD 内联 `var(--neko-popup-*)` 从未被覆盖 | headless 实测：全量 59 变量下这些元素计算色仍 transparent；`.compact-chat-surface-frame::before` 不受影响 | `test/targets.js` 新增 H 段（胶囊变量桥接 + 边框/阴影/模糊/按钮）与 I 段（HUD tab）；`NTS_GATED.popupBridge` 目标从 2 个扩到 5 个、映射 5→9 项；`gen-css.js` 支持输出 `--custom-prop: var(--nts-*)` |
| 2 | `body .message-block-markdown { color: var(--nts-ai-bubble-text) }` 无作用域，用户气泡里的 markdown 正文被染成 AI 文本色 | 合成气泡实测：用户气泡内 markdown 同时命中 ai/user 两条规则 | A 段改为按 `.message-bubble-assistant/-tool/-system/.message.gemini` 作用域；只留 ai gate 时用户正文保持原生色（实测 rgb(20,32,51)） |
| 3 | blur 归一化把 `18%` 写成非法 CSS `blur(18%)`，加载器静默丢弃 → 面板报成功、无效果 | `_canonicalize_value('--nts-chat-blur','18%')='blur(18%)'` | 后端 `RE_BLUR_BARE`（px/rem/em/pt）、加载器同款、面板 blur 分支只收绝对长度；`_probe/test_blur.py` 12/12 |
| 4 | 面板 15 项交互缺陷（palette=null 时名称/启用无法提交、silent reload 假成功、transparent 被记成纯黑、非法行不回滚、导出/复制 JSON 非法、轮询 404 重试 25s、fetch 无超时…） | panel-review 只读审查 15 条 | `plugin/static/app.js` 1827→2141 行（ES5），`node --check` 通过；headless 实测：blur 18% 被拒（`aria-invalid=true`）、18px 接受、transparent 行 alpha 滑块可再用、`#dump` 可 `JSON.parse`、面板 59 行 7 组无控制台错误 |
| 5 | 安装器/补丁 13 项（lone BEGIN 静默删内容、卸载不持久、重装覆盖用户调色板、先删后装无回滚、`-Force` 未声明、备份目录两套…） | patch-review 只读审查 13 条 + 假安装根复现 | `_app_patch.py`（残缺标记安全化、写前守卫、kill-switch、`_sync_asset` 失败计入 ok）、`install.ps1`（预检两阶段、用户调色板备份回写、.bak 回滚、严格解码、原子写、验证扩到全部锚点模板）、`uninstall.ps1`（`-Force`、标记、auto_start=false+stop） |
| 6 | 面板静态资源 `./app.js` / `./style.css` 无版本串，而宿主给 `ui/*.js|css` 发 `max-age=3600` → 升级后最长 1 小时跑旧脚本 | 响应头实测 | `index.html` 改为 `?v=0.1.4`（改这两个文件时必须同步提版本号） |

### 本机实测证据

- 生成器：`node tools/gen-css.js …` → `build/neko-theme-studio.css` **61590 B / sha8 dbba1d18**
  （第二轮；第一轮为 60878 B / `5e983639`），`targets: 131 emitted (260 gated rule block(s))`、`fallbacks: 0`；
  五份 CSS 副本与安装副本哈希一致。
- 加载器 **1.4.0**（40993 B / sha8 efda2160）四副本与安装副本哈希一致；模板 marker 已自动改为
  `?v={{ static_asset_version }}-dbba1d18` / `-efda2160`。
- 零变化不变量：屏蔽 loader/旧 CSS 后注入新 CSS，32 个采样属性 **零差异**；只留 ai gate 时用户气泡 markdown 不串色。
- 全量调色板（59 亮 + 59 暗，version 8）在真 `/chat` 上：`diagnose()={cssRules:372, gates:119}`，
  胶囊 `::before` 底色 = 配置的 `--nts-chat-bg`、HUD 背景/文字/任务 tab、发送按钮、工具按钮、
  聊天外壳圆角、字体、`--neko-chat-opacity-factor` 全部生效；暗色模式（`data-theme=dark` + `.dark`）全部生效。
- 面板活服务实测：`rows=59 / groups=7`、`CONSOLE []`、`NETFAIL []`、版本 9（用户原调色板 2 项已还原）。
- `install.ps1` / `uninstall.ps1` 在假安装根：首装 30 项全过、`-Force` 卸载干净、二次幂等、
  kill-switch 生效、重装恢复自愈与用户调色板、端口关闭回滚、锚点损坏预检中止。
- 用户调色板：测试期间被改成 version 9/E2E-FULL，收工前已用 `_probe/theme.json.live-backup`
  通过 `import_theme` 还原为原 2 项（version 9，内容 = 原 version 6）。

### 仍 PENDING（本轮未做，别当成已修）

1. ~~`dist\neko-theme-studio-0.1.4.zip` 未重打包~~ —— **已重打包**（当时 475,491 B / 69 文件；
   *注：最终包见文末「第三轮 · 收尾」（69 条目）*，
   含 0.1.4 两轮修复后的样式表、加载器、面板、安装器、卸载器、测试套件；内嵌 `.neko-plugin` 105,807 B，
   其 `static/theme.json` 是出厂空调色板）。
2. ~~真实安装根上的 `install.ps1` / `uninstall.ps1` 全流程未跑~~ —— **已在真实安装根跑完**：
   `install.ps1` 30/30 校验 PASS（含重装保留用户 `theme.json`）、`uninstall.ps1` 23 个模板标记归零 +
   写 kill-switch 标记、再装一次 30/30 PASS 且插件 `status=running`。期间发现并修掉
   `multiple_installations`（旧插件目录被改名为 `<id>.bak` 留在插件扫描目录里）与「先 reload 后删标记」
   两个真实缺陷。
3. ~~`test/accept.ps1` 在本机跑不了~~ —— 已修：候选路径 + data: URL 预检（`NTS_BROWSER_PATH` 可覆盖），
   真机 **78 passed, 0 failed**（F3 文字色作用域新增 22 项，见下文第二轮）；套件现在会快照/还原用户调色板，不再把它 reset 清空。
4. ~~`test/panel-smoke.js` 依赖开发机 jsdom 绝对路径~~ —— 已修：`NTS_JSDOM_PATH` → 本地 `node_modules` → `jsdom`
   三级回退，缺 jsdom 打印 SKIP + exit 2；真机 **panel-smoke 22/22、panel-ui 41/41**。
5. 真实历史消息气泡（非合成 DOM）的实渲染未验证：headless 打开 `/chat` 时聊天历史未下发，
   用克隆结构 + 级联比对替代。
6. `--nts-button-hover-bg` / `--nts-highlight`（`::selection`）仍需人眼/强制伪类确认。

### 修复轮补充：收尾前的真机证据（2026-11-15 06:0x）

- 真机 `install.ps1 -Verify`：**30 项全 PASS**（23 模板 BEGIN/END=1、Jinja、资源哈希、/static 200、
  `/chat` 与 `/` 含标记、插件 running）。
- 真机 `accept.ps1`（`NTS_BROWSER_PATH=<chrome-headless-shell>`）：**78 passed, 0 failed**，
  跑完自动还原用户调色板（内容回到 2 项，版本号会变）。
- 真机读页面：`diagnose()={scriptVersion:'1.4.0', cssRules:376, gates:[…ai-bubble-text, user-bubble-text]}`，
  无控制台错误、无网络失败。

---

## 第二轮修复（2026-11-15 06:2x）：气泡文字色串染 / 用户文字色无效

用户反馈（原话）：「问题修改ai文字颜色，用户文字颜色也会变，而且用户文字设置不起作用，我需要你修复这些问题，并修复其他类似问题」

### 根因（三条叠加）

| # | 根因 | 证据 | 修法 |
| --- | --- | --- | --- |
| 1 | 样式表里 AI 文字色是**无作用域**全局规则：`body .message-block-text { color: var(--nts-ai-bubble-text) !important }`（markdown 同理） | `_probe/old-nts.css:116/120`；旧 CSS 45843 B | 生成器（`test/targets.js`）把 AI 文字规则收进 `.message-bubble-assistant` 作用域 |
| 2 | 用户文字色只挂在**死选择器** `.message.user .message-block-markdown` 上；真实 DOM 是 `.message-bubble-user`（React `neko-chat-window.es.js:61250`）→ 用户色永远不生效 | 真 /chat DOM 实测 | 补 `.message-bubble-user .message-block-text` / `.message-block-text-plain` / `.message-block-markdown` 三条作用域规则 |
| 3 | tool/system 内层正文用 `--nts-ai-bubble-text`，与自身气泡底色变量（`--nts-tool-bubble-text`）自相矛盾 → 改 AI 色会串到工具/系统消息 | targets.js A 段 | 内层正文改用 `--nts-tool-bubble-text` |
| 4 | 运行中的聊天窗还持有 01:00 加载的**旧页面**（旧 loader 1.2.0 + 旧 CSS），模板 URL 已换但页面没重载 → 修好了用户看到的仍是旧 bug | Chromium 缓存里 `f_000008/f_0000ca` = 旧 CSS 45843 B（01:00 写入） | loader 1.4.0 新增「样式表新鲜度自愈」（见下） |

### 本轮改动

- `test/targets.js` A 段作用域化 + tool/system 改色 + 用户三条规则；重新生成 `build/neko-theme-studio.css`
  **61590 B / sha8 dbba1d18**（131 emitted / 260 gated / fallbacks 0），同步 6 处副本（含安装目录）。
- 加载器 **1.4.0**（40993 B / sha8 efda2160）：`refreshStaleStylesheet()` 在 boot 时用
  `fetch(css, {cache:'reload'})` 取服务器当前 CSS，`new CSSStyleSheet().replaceSync()` 解析出
  「规则数 + 每条 cssText 长度和」签名，与页面已生效的 `link.sheet` 比较；不一致就把 `link.href` 追加
  `&nts-refresh=<Date.now()>` 强制换表并 `console.warn`；一致时不做任何事（零开销、不闪）。
- 部署后插件重启，23 个模板 marker 自动改为 `-dbba1d18` / `-efda2160`。

### 验证证据

- 新增回归测试 `test/expr-textscope.js`：在真实 `/chat`（真实部署的 CSS + loader）注入离屏夹具，
  结构照真实 React 气泡层级（`message-row > message-stack > message-bubble-* > message-block-text|markdown`），
  用插件 entry 依次「空基线 → 只配 AI → 只配 user → 只配 tool → 清空」，亮/暗各 17 项断言 →
  `verdict PASS`、failing []。实测量值（light）：空基线 user `rgb(20,32,51)`、ai `rgb(39,48,66)`、
  tool `rgb(43,58,80)`、system `rgb(96,112,134)`；只配 AI 时仅 ai 变 `rgb(1,2,3)`，user/tool/system 全不动；
  只配 user 时仅 user 变 `rgb(4,5,6)`；只配 tool 时 tool+system 变 `rgb(7,8,9)`；清空后全部回基线。
- `test/accept.ps1` 新增 F3 段（22 项）→ 真机 **78 passed, 0 failed, exit 0**；`install.ps1 -Verify` **30/30 PASS**。
- 旧 CSS 对照复现：只开 AI gate 时 user/tool/system 全部被染成 `rgb(1,2,3)`（与用户投诉一致）；
  新 CSS 三色互不影响（含暗色）。
- 陈旧样式表自愈构造测试（`_probe/stale_test_server.mjs` + `_probe/stale_check.js`）：服务器第一次回旧 CSS、
  之后回新 CSS，页面 `link` 被改写为 `…?v=old-4c8cf87c&nts-refresh=…`，新规则出现、旧的全局 AI 规则消失。
- 真页面最终状态：`NekoThemeStudio.scriptVersion='1.4.0'`、`cssRules=376`、`version=98`（用户调色板）、
  gates = ai/user/tool/dark 各 1–2 个，控制台无报错、无网络失败。
- 打包（第二轮当时的产物，已被第三轮覆盖，见文末收尾）：`dist/neko-theme-studio-0.1.4.zip` **479,985 B / 69 文件 /
  sha256 63257ba14aaf9f9e616da839181b90283a2d03e01f60251bbeb1748e56eb61f5**；内嵌
  `theme-studio/neko_theme_studio.neko-plugin` 106,320 B，包内 `static/theme.json` 是出厂空盘（148 B）、
  README 36898 B、loader 61590/40993。打包前的坑：`/plugin-cli/build` 读的是**已安装副本**，
  所以先把用户 `theme.json` 临时换回出厂版再 build、build 完立刻还原（否则会把用户颜色发出去）。

### 用户须知（重要）

**当前正在运行的聊天窗是 01:00 加载的旧页面，必须关闭聊天窗重开、或重启 N.E.K.O. 一次**，
本轮修复才会在它里面显示。之后 loader 1.4.0 遇到「页面里的样式表 ≠ 服务器上的样式表」会自动换表，
不需要再手动清缓存/重启。

### 仍 PENDING（第二轮未做）

1. 真实历史消息（非合成 DOM）气泡仍未在真历史下量测：headless 打开 `/chat` 时聊天历史不下发。
2. `--nts-button-hover-bg`（`:hover`）与 `--nts-highlight`（`::selection`）仍需强制伪类 / 人眼确认。

---

## 第三轮修复（2026-11-15 07:0x–07:3x）：作用域审计 —— 又找出 2 处同类泄漏

用户在同一诉求里追加「**并修复其他类似问题**」。这一轮把 59 个变量逐个在**真实 /chat 页面**上量了一遍
「它到底能改动哪些**可见**元素」，找与「AI 文字色串染用户文字」同类的跨作用域泄漏。

### 审计方法（可复跑）

- `_probe/vis_audit.js` + `_probe/run_vis.mjs`（CDP 9334）：逐变量写 `documentElement.style` + 开对应
  `data-nts-l-<var>` gate → 等 560ms（`transition: background-color .4s` 会让同帧 `getComputedStyle`
  读到旧值，这个坑之前踩过）→ 对 `body *` 里**可见**元素（rect ≥ 2×2、在视口内、opacity/visibility 正常）
  比对 20 个属性 → 分类成 visible / invisible 并列出元素路径。
- 命令：`node _probe/run_vis.mjs 'http://127.0.0.1:48911/chat' 6000 _probe/vis_chat.json _probe/audit_vars.json`
  （同样可跑 `http://127.0.0.1:48911/` 得到常规输入态的结果）。
- 关键坑：`audit_vars.json` 是**数组**，夹具首版按 `Object.entries` 遍历 → 拿到下标 "0".."58"，
  59 个变量全部 total=0 假阴性。修法是夹具里做 `Array.isArray(VARS) ? VARS.map(...) : Object.entries(VARS)`。

### 根因与修法

| # | 泄漏 | 证据 | 修法 |
| --- | --- | --- | --- |
| 1 | **面板文字色会改掉紧凑胶囊的文字**：`--nts-panel-text` 挂在 `.composer-panel{color}` 上，这是容器级声明，会继承给所有没有自有 color 的后代；紧凑胶囊 `.compact-chat-surface-frame` / `span.compact-chat-capsule-text` 正是它的后代 | 可见面量测：只配 panel-text 时 `--nts-panel-text` 命中 63 处（55 处可见），胶囊文字从原生 `rgb(52,83,108)` 被改掉 | `test/targets.js` 删掉 `.composer-panel{color: --nts-panel-text}`，面板文字只保留 `.composer-visit-bar{color}` 与 popupBridge 的 `--neko-popup-text`（HUD/弹层）。量测后降到 31 处且只剩 HUD 子树 |
| 2 | **基础字号只管 Markdown 消息**：`--nts-font-size` 只有一条 `.message-block-markdown{font-size}` | 应用 CSS 里 `.message-block-markdown{font-size:.94rem}`，而 `.message-block-text{white-space:pre-wrap}` 没有 font-size（继承气泡 16px）；React `yne()` 启发式决定一条消息走哪条渲染路径 → 纯文本消息的字号设置完全无效 | `test/targets.js` A 段把 font-size 同时挂到 `.message-block-text` 与 `.message-block-text-plain`（三条并列、全部 gate，未配置仍零变化） |

### 顺带确认（不是 bug，别再当 bug 修）

- `--nts-send-text` 命中 `.send-button-circle` 的 `border-*-color`：CSS 里 `border-color` 默认取
  `currentColor`，而这些元素 `border-width:0`，看不到，属于正常继承。
- `--nts-input-text` / `--nts-input-placeholder` 在 `/chat` 紧凑胶囊态**量不到**：该形态下没有
  `.composer-input`（真实输入元素是 `#text-input-area`，0×0）。主页 `/` 的常规输入态里二者都生效
  （实测输入文字 `rgb(31,35,41)`→`rgb(1,2,3)`、占位符 `rgba(102,117,141,.5)`→`rgb(4,5,6)`）。
- 死选择器 `.message.user` / `.message.gemini`（应用从不生成）保留为兼容项，空转无害。
- `#sendButton` 在 React 聊天窗里不存在（`sendButton` 在 bundle 里只是 i18n 键名），真实发按钮是
  `button.send-button-circle`；`#textSendButton` 只属于旧 DOM（`chat.html` 的 `#button-group`），
  规则留着对旧 DOM 仍有效。

### 验证证据（本轮全部真机）

- 生成器：`node tools/gen-css.js …` → `build/neko-theme-studio.css` **61886 B / sha8 0090fe93**，
  `targets: 132 emitted (262 gated rule block(s))`、`gradient kills: 4`、`fallbacks: 0`；
  同步 5 处副本（`app/css`、`build`、`plugin/static/loader`、`app-patch/files/css`、
  `resources/bin/static/css`）+ 已装副本，哈希全部一致。
- 修前/修后对照（`_probe/vis_chat.json` → `_probe/vis_chat2.json`，同一页面同一夹具）：
  `--nts-panel-text` **63 → 31** 处命中，路径从「胶囊 shell / frame / refraction / capsule-text」
  收敛到只剩 `#agent-task-hud` 与 `#agent-task-hud-header`。
- 字号：`_probe/fs_probe.js` 在真 /chat 注入真实层级夹具，空基线 `.message-block-text` 16px /
  `.message-block-text-plain` 16px / `.message-block-markdown` 15.04px；只配 `--nts-font-size:21px`
  后三者全部 21px（`pass: true`）。
- 伪类补测（`_probe/pseudo_probe.mjs`，用 CDP `CSS.forcePseudoState` 强制 `:hover`、用真实
  Selection 触发 `::selection`）：`--nts-button-hover-bg` 只在悬停时上色（灰 transparent →
  `rgb(1,2,3)`，撤 gate 后仍 transparent）；`--nts-highlight` 让选区底色变 `rgb(4,5,6)`。
  → 上一轮 PENDING 的两条已消掉。
- `test/expr-textscope.js` 扩到 6 步（空基线 → AI → user → tool → panel-text → font-size → 清空），
  亮/暗各 27 项断言，新增：`panel_keeps_capsule_text`（胶囊文字 `rgb(52,83,108)` 在改 panel-text
  后不动）、`font_applies_to_plain_text` / `font_applies_to_markdown` / `font_leaves_panel_alone`。
  基线量值（light）：capsule `rgb(52,83,108)` / shell `rgb(34,34,34)`；user `rgb(20,32,51)`、
  assistant `rgb(39,48,66)`、tool `rgb(43,58,80)`、system `rgb(96,112,134)`；
  dark：capsule `rgb(229,242,255)` / shell `rgb(224,224,224)`。
- `test/accept.ps1` F3 段新增 4 项 → 真机 **86 passed, 0 failed, exit 0**（`_probe/accept_scope2.txt`），
  跑完自动还原用户调色板（实测 version 117→143，`vars`/`dark_vars` 与跑前逐字相同）。
- `install.ps1 -Verify`：**30/30 PASS**，模板 marker 已变为 `?v={{ static_asset_version }}-0090fe93` /
  `-efda2160`，`/static` 两文件 61886 / 40993 字节。
- 真页面 `diagnose()`：`scriptVersion '1.4.0'`、`cssLoaded true`、`cssRules 378`、`lastError null`。
- 面板 `plugin/static/app.js` 只加 3 条 hint（面板背景 / 面板文字 / 基础字号），
  `node --check` 通过，真面板仍 `rows=59`、`dump` 可 `JSON.parse`、blur 18% 拒 / 18px 收。

### 本轮仍 PENDING

1. 真实历史消息气泡（非合成 DOM）仍未在真历史下量测：headless 打开 `/chat` 时聊天历史不下发。
2. `--nts-topbar-bg` 在 `/chat` 紧凑态量不到（`.window-topbar{display:none}`），只在常规态可见 —— 属形态差异。

### 收尾（重打包 + 文档同步 + 任务板）

- **重新打包**：先在已安装副本 `…\\.neko-plugin-installations\plugins\neko_theme_studio\` 里把用户
  `static/theme.json`（634 B、version 143、亮 8 / 暗 2）临时换回出厂版（148 B）→
  `POST /plugin/neko_theme_studio/stop` → `POST /plugin-cli/build`
  body `{"mode":"single","plugin_ref":{"root_id":"user","directory_name":"neko_theme_studio"}}`
  （**必须带 `Origin: http://127.0.0.1:48916`**，否则 403 `csrf_validation_failed/origin`）
  → 立刻把用户调色板写回 → `POST /plugin/neko_theme_studio/start`。
  构建产物 `%LOCALAPPDATA%\N.E.K.O\.neko-plugin-packages\neko_theme_studio.neko-plugin`
  **106,557 B**，18 条目，包内 `static/theme.json` = 148 B 出厂空盘、
  `static/app.js` 94086 B、`static/loader/neko-theme-studio.css` 61886 B、
  `static/loader/neko-theme-studio.js` 40993 B、README 36898 B。
- **zip**：`powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\package-dist.ps1 -IncludePackage`
  → `dist\neko-theme-studio-0.1.4.zip` **69 条目**；校验值写在同目录 `neko-theme-studio-0.1.4.zip.sha256`（避免文档自引用）；
  包内无 `__pycache__` / `.pyc` / `_probe` / `_work` / `build/native*` / `_vars.txt`。
- **打包后真机复核**：插件 `status=running`、`runtime_auto_start=true`；
  `GET http://127.0.0.1:48911/static/css/neko-theme-studio.css` = 61886 B；
  `GET …/plugin/neko_theme_studio/ui/theme.json` = version 143、亮 8 / 暗 2（用户原配置逐字未变）。
- **文档同步**：`DISTRIBUTION.md` 头部改为「69 文件 + 附带 `.sha256` 校验文件」并标注「三轮修复」；
  为避免文档里写死的哈希与最终包不一致，校验值改放在 `dist\neko-theme-studio-0.1.4.zip.sha256`；
  `TROUBLESHOOT.md` / `THEME_CONTRACT.md` / `plugin/README.md` 里的 loader 版本与行为描述已是 1.4.0，
  无需再改（三处均无具体字节数/哈希断言）。

### 第三轮用户须知

样式表与加载器本轮又变了一次（`0090fe93`；loader 仍是 1.4.0），模板 marker 已自动更新，
**新开窗口直接生效**；已在运行的聊天窗由 loader 1.4.0 的「陈旧样式表自愈」自动换表，
不用清缓存，也不用重启应用。

---

## 第四轮（2026-11-15 下午）：紧凑历史层 / 导出预览层的文字色（用户报「文字颜色修改不生效」）

### 根因

1. 真实窗口默认是紧凑胶囊态，消息**不走** `.message-bubble-*`，而是
   `article.compact-export-history-message.is-<role> > div.compact-export-history-bubble > …`
   （iife 里的 `Aoe()`）与导出预览层 `article.compact-export-preview-message.is-<role>`。
2. 这两层的颜色在 `resources\bin\static\react\neko-chat\neko-chat-window.css` 里是**写死**的
   （`#273042` / `.is-user{color:#142033}` / `.is-visit-peer{linear-gradient…}` / `.is-system{#607086}`），
   主题样式表在那两层**一条规则都没有** → 改文字色完全没反应。
3. 同时 `test/targets.js` E 段把 `--nts-rec-*`（推荐卡片）打在 `.compact-export-history-bubble` 上，
   **没有角色作用域** → 设定一次就把用户与 AI 气泡一起染色，即用户最初报的「串色」。

### 修复

- `test/targets.js`：删掉 E 段那 4 条 rec-* 错位目标；新增「A 聊天气泡 · 紧凑/历史层」26 条与
  「A 聊天气泡 · 导出预览层」32 条，全部按 `.is-user / .is-assistant / .is-visit-peer / .is-system`
  作用域（文字 / 内层 text·text-plain·markdown·h1-h6·blockquote·th·td / 底色 / 圆角 / 描边）；
  visit-peer 是渐变底色，另加 `background-image: none` kill（X 辅助段，选择器必须与底色目标逐字一致）。
- `test/fixture.html`：新增 `historyCompact` / `previewCompact` 两套 fixture（真实类名与层级，
  含 meta / content / table / blockquote），否则新目标在测量页里 MISSING-ELEMENT。
- 生成器不需要改（`@layer nts-theme` + 逐变量门控已就位）。

### 产物

- 样式表 **108114 B / sha256 前缀 `66ec797c`**（上一版 75292 B / `36e627f9`）；
  311 rows、209 个目标（416 个门控规则块）、102 aux-only、6 个渐变 kill、54 个变量。
- 5 处副本与 23 个模板 marker 全部同步（`-66ec797c`）。

### 验证

- `_probe/verify_two_layers.js`（真实 `/chat` 页 + 真实类名结构）：历史层与预览层的
  user/AI 文字色、底色、圆角、内层 plain/p/h1/blockquote 全部跟随；双向串色判定全 false。
- `test/run-tests.ps1` **exit 0**：6 次探测各 311 rows、ntsRules 528、零改动不变量 0 差异、
  覆盖率 175/175（亮/暗）。
- `test/accept.ps1` **86 passed, 0 failed**。
- 真实窗口（从 `Local Storage\leveldb` 读 loader 自报快照）：`scriptVersion 1.4.2`、
  `cssRules 542`（= 磁盘 543 个 `{` 减 @layer 包裹）、`sheetSwapCount 2`、门控含
  `data-nts-l-user-bubble-text`；屏幕像素里用户文字色 `rgb(151,12,12)` 在消息列表矩形内聚成
  一条文本行（容差 45 内 191 px 在面板内 / 13 px 在外）→ 新表与新门控在真实窗口已生效。

### 仍 PENDING

1. 真实历史消息（服务端下发的完整对话）下的实渲染仍未端到端量测 —— 无头打开 `/chat` 时历史不下发，
   用克隆结构 + 真实类名替代（本轮已覆盖到紧凑历史层与预览层两套真实 DOM）。
2. 插件面板 iframe 内的剪贴板写入（「复制并关闭」）无法在无头环境验证；面板里失败会提示
   「复制失败，请手动选择文本」，回退路径已确认存在。
3. 冷启动 autostart 拉起插件仍只在等价条件下验证。
