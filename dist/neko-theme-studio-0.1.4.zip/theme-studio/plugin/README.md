# 主题工坊（neko_theme_studio）

N.E.K.O 的可视化主题编辑器插件。面板里逐项调整聊天界面的颜色变量，保存成一份
调色板（palette），由应用侧加载器轮询后实时注入到应用窗口。

- 插件 id：`neko_theme_studio`
- 面板：静态页面（`static/index.html`），从 `http://127.0.0.1:48916/plugin/neko_theme_studio/ui/` 提供
- 数据文件：`static/theme.json` —— 应用侧加载器唯一读取的来源

---

## 1. 组件关系

```
┌─────────────────────────┐        POST /runs            ┌──────────────────────────┐
│  插件面板（静态页面）    │ ───────────────────────────► │  __init__.py（本插件）   │
│  48916 /plugin/<id>/ui/ │ ◄─────────────────────────── │  校验 → 合并 → 原子写盘  │
└─────────────────────────┘       导出 run 结果          └────────────┬─────────────┘
                                                                     │ os.replace
                                                                     ▼
                                                          static/theme.json
                                                                     │
                                              GET …/ui/theme.json    │ 轮询 1500ms
                                                                     ▼
                                                      ┌──────────────────────────┐
                                                      │ 应用侧加载器             │
                                                      │ neko-theme-studio.js     │
                                                      │ 注入 <style id=nts-…>    │
                                                      └──────────────────────────┘
```

面板 iframe 运行在 **48916** 源，应用窗口在 **48911** 源：两者跨源，
`localStorage` 不共享、`BroadcastChannel` 不互通，所以唯一的同步通道就是
`theme.json` 这个 HTTP 文件。

---

### 1.1 装上即用：自愈与热更新

本插件需要改动应用侧文件（模板 + 静态资源），但**这些改动全部由插件自己在 startup 完成**：

| 环节 | 谁做 | 失败后果 |
| --- | --- | --- |
| 同步样式表/加载器到 `resources\bin\static\` | `_app_patch._sync_asset()` | 只记日志 |
| 给 23 个模板打 `NTS:BEGIN/END` 标记段 | `_app_patch._patch_template()` | 该模板跳过，计入 `warnings` |
| 把 `auto_start` 偏好落盘 | `_ensure_autostart_async()`（daemon 线程） | 只记 warning |
| 插件没跑时把服务叫醒 | loader 的 `reviveService()` / 面板的 `revivePlugin()` | 下一轮轮询再试 |

**热更新**：模板标记段的 URL 形如
`/static/neko-theme-studio.js?v={{ static_asset_version }}-<内容哈希8位>`，
末尾 8 位是文件内容的 sha256 前 8 位。改了 `static\loader\` 里的文件并重启插件，
URL 会变，而 48911 对 `/static/*?v=…` 回 `immutable` 缓存 —— URL 变即缓存失效。
所以「改文件 → 重启插件 → 应用窗口自动用新版」这条链是自洽的，不需要清缓存。

> 为什么不直接改 `{{ static_asset_version }}`：它是进程启动时固定的，改文件不会让它变，
> 这一点已实测确认（把 CSS 的 mtime 改到当下，GET `/` 返回值一模一样）。

**可用性兜底**：`repair_app` entry 可随时手工重跑整套应用侧集成，返回值与 startup 相同；
面板状态栏与 `studio_context.app_patch` 也会带上最近一次的结果。

### 1.2 你看到的窗口长什么样（决定「改了颜色没变」的判断方式）

真实聊天窗默认是**紧凑胶囊态**：`.chat-window` / `.chat-body` / `#react-chat-window-root`
的高度为 0，背景被应用自己的 `transparent !important` 压平，**它们本来就看不见**。
可见面只有：

- 胶囊本身 `.compact-chat-surface-frame`（底色走应用变量 `--compact-chat-surface-bg`，
  本插件按变量门控改写它，而不是硬压 `background`）；
- 发送/工具按钮 `.compact-input-tool-toggle`（与 `.send-button-circle` 同一个元素）；
- 悬浮层 `#agent-task-hud`（猫爪任务）/ 插件面板：样式是内联 `var(--neko-popup-*)`，
  本插件把这些原生变量**桥接**到 `--nts-panel-*` / `--nts-accent*` / `--nts-shadow`。

因此：配 `--nts-chat-bg` 看胶囊底色、配 `--nts-panel-bg` 看猫爪 HUD；
盯着透明的 `.chat-body` 判断「没生效」会误判。细节与坑（400ms transition）见
`TROUBLESHOOT.md` 第 1.6 步。
## 2. 六个 entry

| id | 参数 | 说明 |
| --- | --- | --- |
| `get_theme` | 无 | 返回当前调色板（`schema`/`version`/`name`/`enabled`/`updated_at`/`vars`/`dark_vars`） |
| `apply_theme` | `vars: object`、`dark_vars: object`、`name: string`、`enabled: boolean`（均非必填） | 校验后**合并**进当前调色板，原子写盘，`version` +1，刷新 `updated_at`。`name` 传空串/纯空白 = 恢复默认名「默认」；传非字符串才报错 |
| `reset_theme` | 无 | 写回内置默认调色板（`version` 仍 +1，让应用侧感知变化） |
| `export_theme` | 无 | 返回 `payload` —— 调色板的 JSON 文本 |
| `import_theme` | `payload: string`（必填） | 解析 + 校验后**整体替换**调色板 |
| `repair_app` | 无 | 重跑应用侧集成（同步样式表/加载器 + 补模板标记），返回与 startup 相同的诊断字典 |

`apply_theme` 与 `import_theme` 的返回值在有条目被拒绝时额外带一个
`rejected: string[]` 字段，面板会把它展示给用户。

---

## 3. 安全校验（本插件的核心）

面板是跨源 iframe，它的输入**一律视为不可信**。所有值在写入磁盘之前都要经过
`_validate_palette()`，返回 `(clean_vars, clean_dark, errors)`；只有 `clean_*`
里的内容会落盘。

### 3.1 变量名

必须匹配 `^--nts-[a-z0-9-]{1,60}$`。这条规则与
`neko-theme-studio.js` 里的 `isSafeVarName()` **完全一致**，因此
`--compact-*`、`--xy-*` 之类的变量会被双方一致拒绝。

> 为什么是「形状校验」而不是「目录白名单」：随包发布的
> `neko-theme-studio.css` 用到了一些契约 §3 里没有列出的变量
> （如 `--nts-code-bg`、`--nts-bubble-radius`、`--nts-status-text`）。
> 若按目录做白名单，这些合法变量会被误杀。安全性由**值**的校验保证。

### 3.2 变量值

值先经过一道黑名单：含 `;` `{` `}` `<` `>` `\`、`@import` 或 `url(` 一律拒绝。
圆括号**故意不禁止** —— `rgb()` / `hsl()` 这类合法值本身就需要括号，真正的安全
来自下面每种类型各自的「整串锚定」正则。

| 类型 | 变量 | 接受的形态 |
| --- | --- | --- |
| `color` | 其余全部变量 | `#rgb` / `#rgba` / `#rrggbb` / `#rrggbbaa` / `rgb(…)` / `rgba(…)` / `hsl(…)` / `hsla(…)` / `transparent` |
| `length` | `--nts-radius`、`--nts-font-size`、`--nts-bubble-radius`、`--nts-shell-radius`、`--nts-card-radius`、`--nts-modal-radius`、`--nts-popover-radius`、`--nts-rec-radius` | `px` / `rem` / `em` / `%` / `pt` / `vh` / `vw` / `0`，**不接受负数** |
| `blur` | `--nts-chat-blur` | `blur(<长度>)` 或裸长度（会被规范化为 `blur(…)`，见 §3.3）；长度单位**只接受 `px` / `rem` / `em` / `pt` 或 `0`**，`%` / `vh` / `vw` 一律拒绝，**不接受负值** |
| `number` | `--nts-chat-opacity` | `0`–`1` 的小数，或 `0%`–`100%` 的百分比（落盘前归一成小数，见 §3.4） |
| `font` | `--nts-font-family` | 字母数字、中日文、空格、逗号、引号、`-_.`，最长 200 |
| `shadow` | `--nts-shadow` | 按「括号外空白」切分后按 box-shadow 语法校验：`inset` ≤1、颜色 ≤1、长度 2–4 个（合计 token ≤6）、**不接受百分比**；负值只允许出现在前两个长度（x/y 偏移） |

被拒绝的值**永远不会写进 `theme.json`**；对应变量在调色板中保留原值（若原本
不存在则继续保持不存在）。这一点有测试覆盖：注入串
`#ff8ab0; } html { display:none }`、`url(http://evil/x.png)`、
`8px; position:fixed` 提交后，磁盘文件里搜不到 `display:none` /
`position:fixed` / `url(`。

### 3.3 `--nts-chat-blur` 的陷阱

契约 §3 把它写成「px」，但 `neko-theme-studio.css` 的实际消费方式是：

```css
html body #react-chat-window-shell::before,
html body #react-chat-window-shell::after {
  backdrop-filter: var(--nts-chat-blur, blur(18px)) !important;
}
```

也就是说**原生的合法值就是 `blur(18px)`**。若只写 `18px`，
整条 `backdrop-filter` 声明会因语法非法被浏览器丢弃 —— 毛玻璃消失，而且
**不会有任何报错**。因此后端接受两种写法，并把裸长度统一规范化为
`blur(…)`（`_canonicalize_value()`），面板也提示用户填写 `blur(…)` 形式。

> **v0.1.4 修掉的真实 bug**：旧版把「长度」正则（含 `%` / `vh` / `vw`）直接用于 blur 归一化，
> `18%` 会被写成 `blur(18%)` —— 这是**非法 CSS**，加载器只接受
> `blur(px|rem|em|pt)`，于是静默丢弃整条值：面板报成功、毛玻璃毫无变化。
> 现在后端 / 加载器 / 面板三处都只放行绝对长度（`RE_BLUR_BARE`），
> 面板也会把 `18%` 直接标红，不再落盘。

### 3.4 值的规范化（`_canonicalize_value()`）

校验通过的值**不一定**原样落盘：有两种写法会被改写，目的是让 `theme.json`
里永远只有「应用侧加载器能直接消费」的形态 —— 否则就会变成「面板说成功、
外观没变」的静默空操作。

| 变量 | 用户写法 | 落盘值 | 为什么 |
| --- | --- | --- | --- |
| `--nts-chat-blur` | `18px` | `blur(18px)` | 消费方是 `backdrop-filter`，裸长度整条非法（见 §3.3） |
| `--nts-chat-opacity` | `50%` | `0.5` | 契约语义是 0–1 的乘子；百分比归一成小数（四舍五入到 4 位、去尾零：`33.3%` → `0.333`，`100%` → `1`） |

百分比只接受 `0%`–`100%`：`101%`、`999%` 直接拒绝（归一后 >1，加载器无处可放）。
归一在 `vars` 与 `dark_vars` 两路上完全一致 —— 两者走的是同一个校验/归一函数。

负值一律拒绝（`-10px`、`blur(-3px)`）：CSS 里负圆角 / 负字号 / 负模糊半径会让
**整条声明**被浏览器丢弃。但 `--nts-shadow` 的偏移量确实需要负号，所以只在
`shadow` 的前两个长度 token 上放行（`-4px 0 8px #000` 合法；负扩散半径虽合法，
但为避免与负模糊混淆，三处统一从严 —— 面板会标红而不是静默丢弃）。

> **三处校验没有方向性差异**：应用侧加载器（`app/neko-theme-studio.js` 的 `isSafeValue`）已镜像同一套
> 负数拦截与百分比上限，并**移除了**只存在于 loader 的 `var(--nts-*)` 派生色放行 —— 它曾造出
> 一条「只有手改 `theme.json` 才走得通」的路，且把颜色变量指向长度变量时整条声明会静默失效。
> 差分工具：`_local_verify/three_way.js` / `_local_verify/backend/loader_vs_backend.js`，
> 现为 **1903 / 2132 例 0 分歧**；`--nts-shadow` 自 v0.1.3 起三处都按 box-shadow 语法做结构校验
> （长度 2–4 个、颜色 ≤1、`inset` ≤1、不接受百分比）。

---

## 4. 完整变量目录与原生参考值

下表是面板里呈现的全部 **59** 个变量（面板 `CATALOG` 与本节逐条对应）。
**「亮色原生」/「暗色原生」只作参考显示**，面板不会自动把它们写进调色板 ——
原因见 §5。

| 分组 | 变量 | 亮色原生参考 | 暗色原生参考 |
| --- | --- | --- | --- |
| 聊天气泡 | `--nts-user-bubble-bg` | `#44b7fe` | `#2a7bc4` |
| 聊天气泡 | `--nts-user-bubble-text` | `#ffffff` | `#ffffff` |
| 聊天气泡 | `--nts-user-bubble-border` | `transparent` | — |
| 聊天气泡 | `--nts-ai-bubble-bg` | `#ffffff` | `rgba(42,123,196,0.18)` |
| 聊天气泡 | `--nts-ai-bubble-text` | `#24445a` | `#e0e0e0` |
| 聊天气泡 | `--nts-ai-bubble-border` | `transparent` | — |
| 聊天气泡 | `--nts-code-bg` | `rgba(91,111,145,0.12)` ※ | `rgba(100,120,160,0.18)` ※ |
| 聊天气泡 | `--nts-code-text` | `#22324d` ※ | `#c0cce0` ※ |
| 聊天气泡 | `--nts-image-bg` | `transparent` | `transparent` |
| 聊天气泡 | `--nts-tool-bubble-bg` | `linear-gradient(180deg,#f8fafc,#edf2f8)` ‡ | `linear-gradient(180deg,#232330,#1e1e2a)` ‡ |
| 聊天气泡 | `--nts-tool-bubble-text` | `#2b3a50` ‡ | `#b8bcc4` ‡ |
| 聊天气泡 | `--nts-status-bg` | `rgba(70,129,227,0.12)` ‡ | `rgba(68,130,230,0.15)` ‡ |
| 聊天气泡 | `--nts-status-text` | `#28589d` ‡ | `#6fa8ff` ‡ |
| 聊天窗口 | `--nts-chat-bg` | `transparent` | — |
| 聊天窗口 | `--nts-chat-panel-bg` | `transparent` | — |
| 聊天窗口 | `--nts-chat-panel-radius` | `0px` | — |
| 聊天窗口 | `--nts-topbar-bg` | `transparent` | — |
| 聊天窗口 | `--nts-topbar-text` | `inherit` | — |
| 聊天窗口 | `--nts-chat-blur` | `blur(18px)` | — |
| 聊天窗口 | `--nts-chat-opacity` | `1` | — |
| 输入区 | `--nts-input-bg` | `rgba(40,40,40,0.65)` ※ | `rgba(40,40,40,0.65)` |
| 输入区 | `--nts-input-text` | `inherit` | `#e0e0e0` |
| 输入区 | `--nts-input-border` | `rgba(255,255,255,0.06)` | `rgba(255,255,255,0.06)` |
| 输入区 | `--nts-input-placeholder` | `#9aa7b2` | `#999999` |
| 输入区 | `--nts-button-bg` | `transparent` | `#2d2d2d` |
| 输入区 | `--nts-button-text` | `inherit` | — |
| 输入区 | `--nts-button-hover-bg` | `#44b7fe1a` | `#44b7fe26` |
| 输入区 | `--nts-send-bg` | `#44b7fe` | `#2a7bc4` |
| 输入区 | `--nts-send-text` | `#ffffff` | `#ffffff` |
| 面板/弹窗 | `--nts-panel-bg` | `transparent` | — |
| 面板/弹窗 | `--nts-panel-text` | `#333333` | `#e0e0e0` |
| 面板/弹窗 | `--nts-panel-border` | `rgba(0,0,0,0.08)` | `rgba(255,255,255,0.1)` |
| 面板/弹窗 | `--nts-panel-text-sub` | `#666666` | `#b0b0b0` |
| 面板/弹窗 | `--nts-accent-bg` | `rgba(42,123,196,0.05)` | `rgba(58,159,216,0.1)` |
| 面板/弹窗 | `--nts-popover-bg` | `transparent` | — |
| 面板/弹窗 | `--nts-popover-text` | `inherit` | — |
| 面板/弹窗 | `--nts-popover-border` | `transparent` | — |
| 面板/弹窗 | `--nts-modal-bg` | `#ffffff` | `#2d2d2d` |
| 面板/弹窗 | `--nts-modal-text` | `#24445a` | `#e0e0e0` |
| 面板/弹窗 | `--nts-overlay-bg` | `transparent` | `rgba(0,0,0,0.65)` |
| 推荐/chip | `--nts-rec-bg` | `transparent` | — |
| 推荐/chip | `--nts-rec-text` | `inherit` | — |
| 推荐/chip | `--nts-rec-border` | `transparent` | — |
| 推荐/chip | `--nts-chip-bg` | `transparent` | — |
| 推荐/chip | `--nts-chip-text` | `inherit` | — |
| 全局 | `--nts-accent` | `#2a7bc4` | — |
| 全局 | `--nts-link` | `#2a7bc4` | — |
| 全局 | `--nts-highlight` | `rgba(68,183,254,0.35)` | `rgba(74,163,223,0.4)` |
| 全局 | `--nts-scrollbar-thumb` | `rgba(0,0,0,0.25)` | `rgba(255,255,255,0.2)` |
| 全局 | `--nts-scrollbar-track` | `transparent` | — |
| 非颜色 | `--nts-radius` | `8px` ※ | `8px` ※ |
| 非颜色 | `--nts-bubble-radius` | `16px` ※ | `16px` ※ |
| 非颜色 | `--nts-shell-radius` | `14px` | `14px` |
| 非颜色 | `--nts-card-radius` | `0px` | `0px` |
| 非颜色 | `--nts-modal-radius` | `0px` | `0px` |
| 非颜色 | `--nts-popover-radius` | `12px` | `12px` |
| 非颜色 | `--nts-rec-radius` | `18px` | `18px` |
| 非颜色 | `--nts-font-family` | `inherit` | `inherit` |
| 非颜色 | `--nts-font-size` | `0.94rem` | `0.94rem` |
| 非颜色 | `--nts-shadow` | — | — |

「—」表示该变量在对应模式下没有明确的原生字面量（多为 `inherit` 或该模式
不使用该变量）。

关于表中带 ※ / ‡ 标记的项的注记：

- **※ 一个变量对应多个原生值。** 生成的样式表把同一个变量打在多个目标上，
  而各目标的原生值并不相同，所以「原生参考」列只能给一个代表性值：
  - `--nts-code-bg` / `--nts-code-text`：`.message-markdown-inline-code`
    与 `.message-markdown-pre` 共用。行内代码原生有底色，代码块（`pre`）
    原生**没有**底色；文字色亮色下也不同（`#22324d` / `#1f2c42`）。
  - `--nts-image-bg`：`.message-block-image` 原生是 `transparent`，
    只有图片自身透明或加载失败时才看得见底色。
- **‡ 填写后会把多个原生值「拉平」成同一个值。** 这是覆盖而非替换，
  因此面板的 `hint` 里逐条写明了被拉平的另外几个原生值：
  - `--nts-tool-bubble-bg` 同时作用于 `.message-bubble-tool`（原生是
    渐变）与 `.message-bubble-system`（原生是半透明灰）。
  - `--nts-status-bg` / `--nts-status-text` 同时作用于
    `.message-block-status` 的 `tone-info` / `tone-success` /
    `tone-warning` / `tone-error` 四种 tone，而四者原生各不相同。
- `--nts-panel-text-sub` 与 `--nts-accent-bg` 是**桥接**项：生成的 CSS 不给
  目标元素直接赋值，而是写 `#agent-plugin-content` / `#agent-plugin-views`
  上的 `--neko-popup-text-sub` / `--neko-popup-accent-bg`，交给
  `agent-plugin-views.css` 消费（插件面板的标签页文字与选中/悬停底色）。

### 4.1 三个文字色变量各管各的气泡（v0.1.4 起）

真实聊天 DOM 的气泡是 `article.message-row.message-row-<role> > div.message-stack >
 div.message-bubble.message-bubble-<role>`（React 动态生成，没有 `.message.user` 这种类名）。
 文字色必须写在**气泡作用域内**，否则会互相串染：

| 变量 | 只作用于 | 说明 |
| --- | --- | --- |
| `--nts-ai-bubble-text` | `.message-bubble-assistant`（兼容 `.message.gemini`）内正文 | 改它**不会**影响用户/tool/system 气泡 |
| `--nts-user-bubble-text` | `.message-bubble-user` 内正文 | 纯文本（`.message-block-text` / `-text-plain`）与 markdown 两种块都覆盖 |
| `--nts-tool-bubble-text` | `.message-bubble-tool` 与 `.message-bubble-system` 内正文 | 与这两个气泡的底色是同一变量组，不要拿 AI 色顶替 |

### 4.2 聊天记录到底画在哪一层（这决定了「改色没反应」）

真实窗口默认是**紧凑胶囊态**，此时消息**不走** `.message-bubble-*`，而是历史层：

```html
<section class="compact-export-history-anchor">
  <div class="compact-export-history-scroll">          <!-- 消息列表底板 -->
    <div class="compact-export-history-scroll-content">
      <article class="compact-export-history-message is-user|is-assistant|is-visit-peer|is-system">
        <div class="compact-export-history-bubble">     <!-- 气泡本体 -->
          <div class="compact-export-history-meta">作者 / 时间</div>
          <div class="compact-export-history-content">
            <div class="message-block-text[.message-block-text-plain]">…</div>
            <div class="message-block-markdown">…</div>
```

「导出图片」前那一屏结构相同，只是类名换成
`compact-export-preview-message` / `compact-export-preview-bubble`
（`is-visit-peer` 角色的原生底色是 `linear-gradient`，所以生成器会补一条
`background-image: none` 才让纯色生效）。

因此气泡类变量现在覆盖**四套**界面，每一套都按角色作用域写，互不串染：

| 界面 | 类名 | 何时出现 |
| --- | --- | --- |
| React 消息列表 | `.message-bubble-<role>` | 展开 / 非紧凑形态 |
| 紧凑聊天记录层 | `.compact-export-history-message.is-<role>` | **默认形态（用户平时看到的就是它）** |
| 导出预览层 | `.compact-export-preview-message.is-<role>` | 点「导出图片」后的预览 |
| 旧窗口 | `.message.user` / `.message.gemini` | `viewer.html` 窗口 |

> 历史 bug：`--nts-user-bubble-text` / `--nts-ai-bubble-text` 原先只写在
> `.message-bubble-*`（和旧 `.message.*`）上，**紧凑历史层一条规则都没有**，而
> 应用给那一层的颜色是写死的（`#273042` / `#d0e7ffe0` / 渐变 / `#607086`）——
> 于是「改了文字颜色完全没反应」。同一时期 `--nts-rec-*`（推荐卡片）还被打在
> `.compact-export-history-bubble` 上且没有角色作用域，于是「设一次推荐卡片文字，
> 用户和 AI 气泡一起变色」。两处都已修复，覆盖用例在
> `theme-studio\test\targets.js` 的「A 聊天气泡 · 紧凑/历史层」与「· 导出预览层」两段，
> fixture 在 `theme-studio\test\fixture.html` 的 `historyCompact` / `previewCompact`。

> 早期 bug（v0.1.4 之前）：旧样式表把 AI 文字色写成无作用域的全局规则，又把用户文字
> 规则挂在死选择器 `.message.user .message-block-markdown` 上 —— 表现就是「改 AI 色，
> 用户文字也变色；改用户色，一点反应没有」。判断修复是否生效：看 Console 的 loader
> 版本（当前应为 `1.4.2`），并确认窗口是升级后新开的（旧窗口由 loader 的
> 15 秒样式表复检 + 自升级逻辑自动换掉）。

---

## 5. 为什么出厂调色板是空的

**这是本插件最重要的设计决定。**

### 5.1 生成的样式表里没有回退值

`neko-theme-studio.css`（v3 起）**刻意不含任何回退值**：没有一处
`var(--nts-X, <某个值>)` 形态。取而代之，**每一条规则都按 (模式, 变量)
两个键门控**：

```css
:root:not([data-theme="dark"])[data-nts-l-radius]:root:root body .window-topbar {
  border-radius: var(--nts-radius) !important;
}
:root[data-theme="dark"][data-nts-d-radius]:root:root body .window-topbar {
  border-radius: var(--nts-radius) !important;
}
```

- `data-nts-l-<var>` = 该变量**在亮色组**被用户配置过；
- `data-nts-d-<var>` = 该变量**在暗色组**被用户配置过；
- `data-nts-active` 同时打上，表示「至少有一个变量被配置过」。

加载器（`app/neko-theme-studio.js` 的 `setGates()` / `gateNameFor()`，
`gateNameFor(varName, mode)` 去掉整个 `--nts-` 前缀后拼 `l-` / `d-`）
负责把这些属性同步到 `<html>` 上；属性集合不变时不碰 DOM，避免多余的
整页样式重算。

三条结论因此是**构造性成立**的，不依赖任何量测：

1. **空调色板零视觉影响**：没有变量 → 加载器不打任何门控属性 →
   所有选择器不匹配 → 样式表等于没装。
2. **只配亮色的调色板碰不到暗色**：亮色规则前缀带
   `:not([data-theme="dark"])`，暗色下整条不匹配。
3. **只配暗色的调色板碰不到亮色**：暗色规则前缀要求
   `[data-theme="dark"]`。

### 5.2 为什么放弃「量出来的回退值」

早期方案是把量测页（fixture）里量到的原生值写成回退值，即
`var(--nts-radius, <量到的值>)`。该方案被**废弃**，原因是根本性的：
**在合成量测页里量到的值，不是真实页面的计算值。** 真实页至少有三处
量测页复现不了的差异——

- 真实 `/chat` 的 `<body>` 带 `.electron-chat-window` 类，使
  `body:not(.electron-chat-window) …` 这类规则在真实页根本不生效；
- 真实视口宽度（量测页会落进 `@media (max-width:768px)` 分支）；
- 应用**运行时注入的 `<style>` 层**（带 `!important`，压过所有样式表）。

于是一个「量出来的回退值」会在**用户根本没配置**的情况下静默改写外观，
直接违反契约 §9.3 的「未配置时视觉零变化」。门控方案消除了这个失效模式：
未配置 == 未加载，二者是同一件事。

样式表的加载顺序同样由安装器保证：`neko-theme-studio.css` 排在
`dark-mode.css` **之后**，因此在同等特异性下由本插件胜出。

### 5.3 由此得到的出厂状态

- `static/theme.json` 出厂即 `{"vars": {}, "dark_vars": {}}`；
- 面板每一行默认显示原生参考值作为**提示**，但只有用户真正改动过的行
  才会进入提交内容（`collect()` 只收集 `edited` / `cleared` 两个集合）；
- `reset_theme` 同样回到空调色板；加载器在 `vars` 与 `dark_vars` 都为空时
  会主动 `removeStyle()`，注释写的就是「空调色板 = 恢复原样」。

> 这与初始需求里「把完整变量目录连同默认值放进 `vars`/`dark_vars`」的字面
> 要求相冲突。我选择遵循契约 §9.3 与加载器的实际语义，把完整目录放进面板的
> `CATALOG`（以及本 README 的 §4 表格）作为可见的参考，而不是预填进调色板。
> 如果需要「一键填充原生值」，在面板里逐行填入即可。

---

## 6. 实现要点

### 6.1 原子写盘 + 互斥锁

```python
_WRITE_LOCK = threading.Lock()
```

写盘走「同目录临时文件 → `fsync` → `os.replace`」：

```python
tmp_path = self.static_dir / f".theme.json.{os.getpid()}.{threading.get_ident()}.tmp"
...
os.replace(tmp_path, self.theme_path)
```

临时文件与目标**同目录**是硬要求，否则 `os.replace` 可能跨卷而失去原子性。
整个「读 → 合并 → 写」序列都在 `_WRITE_LOCK` 内完成，避免并发丢更新。
测试用 40 个并发 `apply_theme` 验证过：得到 40 个互不相同的版本号，
没有一次丢失。

### 6.2 容错

**读路径**（`get_theme` / `export_theme` / `studio_context` / 启动）永不抛异常：

- 文件不存在 → 启动时创建为默认调色板；`_read_unlocked()` 也返回默认值。
- 文件读不出来（被占用 / 权限不足）→ 记一条 warning，返回默认值，**不覆盖文件**。
- 文件内容不是合法 JSON → 读路径返回默认值；启动时 `_ensure_file()` 会先把原文件
  改名备份成 `theme.json.corrupt`，再写入默认调色板 —— 不静默销毁用户数据。
- 文件里存在非法值（例如手工改成了 `javascript:alert(1)`）→ 读盘时同样
  过滤掉，坏值永远不会流进应用侧加载器。

**写路径**（`apply_theme`）必须拿到真实基线，因此 `_read_unlocked(strict=True)`：
文件存在却读不出来 / 解析不了时返回 `Err(...)`，并保持文件原样。这一点是必须的 ——
若像读路径那样退回默认值，一次瞬时读取失败（Windows 上杀毒软件或索引器锁文件
就能触发）就会把用户已保存的全部变量抹掉、只剩本次新值，而且返回 `Ok`。

`reset_theme` / `import_theme` 是「整体替换」，不需要旧基线，因此仍按读路径的
容错规则处理 —— 文件坏掉时它们依然能把插件救回来。

所有 entry 都包在 `try/except` 里，失败返回 `Err(SdkError(...))`。

### 6.3 删除语义

- 变量的值为空串 `""` 或 `null` → 从调色板中**删除该键**，回退到原生值。
  面板的「清空」按钮就是这个语义。
- 被**拒绝**的值不会走到删除分支（它既不在 clean 结果里，也不是空值），
  因此一次误输入不会毁掉已经保存的好值。

### 6.4 版本号

`version` 只在真正落盘时 +1。应用侧加载器靠它判断是否需要重绘
（`p.version === currentVersion` 时直接跳过），所以「重置」也必须让版本号
变化，否则应用侧感知不到。

---

## 7. 面板使用说明

| 控件 | 作用 |
| --- | --- |
| 亮色 / 暗色 | 切换编辑 `vars` 还是 `dark_vars`；两个模式各自独立记录改动 |
| 色块 `<input type="color">` | 选色；结果与透明度滑块合成 `rgba(r,g,b,a)` |
| 十六进制输入框 | 直接粘贴 `#rgb` / `#rgba` / `#rrggbb` / `#rrggbbaa`；非法输入边框变红且不生效 |
| 透明度滑块 | 只能通过它调整 alpha —— 因为最终值统一以 `rgba(...)` 形式写入 |
| 清空 | 该行回退到 N.E.K.O 原生值（提交空串 = 删除该键） |
| 主题名 / 启用主题 | 对应 `name` / `enabled`（`enabled: false` 时加载器会移除注入样式） |
| 还原本组 | 只丢弃**当前模式**的未提交改动，不影响另一模式 |
| 应用 | 提交 `edited` + `cleared` 的并集，然后重新 `get_theme` 校准界面 |
| 重置 | `reset_theme` |
| 导出 | `export_theme`，弹窗内可一键复制 |
| 导入 | 粘贴 JSON → `import_theme`（整体替换） |
| 搜索框 | 按标签 / 变量名 / 提示文字过滤 59 行；`Esc` 清空，`Enter` 跳到第一个命中行 |
| 只看改动 | 只留下本次改过或清空过的行，用于提交前复核 |
| 全部收起 / 全部展开 | 一键折叠所有分组；单个分组标题也可点击或回车折叠 |
| 复制 dump | 把右侧调色板 JSON 复制到剪贴板（含未应用改动），便于贴 issue |

键盘：`/` 聚焦搜索、`Ctrl/⌘ + Enter` 应用、`Esc` 关弹窗、模式页签支持左右方向键。
行内「已改 / 已清空」标记与左侧色条只在脏行出现，因此「哪些还没提交」一眼可见。
清空按钮对**所有**类型都提供（早期版本颜色行没有清空按钮，只能手动清空十六进制框）。

面板自身按 `prefers-color-scheme` 支持暗色（它跑在 48916 的独立 iframe 里，
跟随的是**系统**主题，而不是应用窗口里选择的亮/暗主题）。读取数据时顶部有一条
2px 进度条，分组标题在滚动时吸顶，提示文字默认单行、悬停展开。

右侧预览是**纯本地模拟**：用内联样式拼出假的用户气泡、AI 气泡、链接、
chip 和输入区，让用户在提交前就看到反馈。面板是跨源 iframe，无法给应用窗口
套样式，所以真实效果仍以应用窗口为准。

### 调用约定

面板通过宿主的 run 机制调用 entry，与 `wechat_integration` 的做法一致：

1. `GET /security/csrf-token` 取 CSRF token（失败则无 token 继续，宿主默认接受）；
2. `POST /runs` `{plugin_id, entry_id, args}` → 拿 `run_id`；
3. 每 500ms `GET /runs/{run_id}`，直到 `succeeded`（`failed`/`canceled`/`timeout` 抛错）；
4. `GET /runs/{run_id}/export` 取返回值，并拆掉 `{success, data}` / `{error}` 包装。

URL 全部使用相对路径，因为面板本身就是从 48916 被服务的。

---

## 8. 文件清单

```
plugin/
├── plugin.toml          # 清单：id/entry/i18n/store/ui 面板（mode = "static"）
├── build_info.py        # PLUGIN_VERSION
├── __init__.py          # 后端：6 个 entry + 校验 + 原子写 + startup 自愈
├── _app_patch.py        # 应用侧集成：模板补丁 + 两件套同步 + auto_start 自愈（纯 stdlib）
├── i18n/
│   ├── zh-CN.json
│   └── en.json
├── static/
│   ├── index.html       # 面板骨架
│   ├── style.css        # 面板私有样式（不使用 --nts-*）
│   ├── app.js           # CATALOG + 校验镜像 + 颜色工具 + 调用层（含自愈重试）+ 编辑器
│   ├── theme.json       # 调色板数据文件（应用侧加载器轮询它）
│   └── loader/
│       ├── neko-theme-studio.js    # 随包的应用侧加载器（启动时同步进 resources\bin\static）
│       └── neko-theme-studio.css   # 随包的应用侧样式表（同上）
└── README.md
```

插件启动时会用 `_app_patch.ensure_app_patch()` 把 `static\loader\` 里的两个文件同步进应用，
并给所有带 `dark-mode.css` 锚点的模板打上标记段（URL 带内容哈希）。因此**装上即生效**，
不需要用户再跑仓库里的 `install.ps1`。失败只写日志，绝不影响插件启动。

---

## 9. 已知限制

- `--nts-chat-opacity` 走的是**桥接**而非直接赋值：生成的 CSS 里是
  `:root[data-nts-l-chat-opacity] { --neko-chat-opacity-factor: var(--nts-chat-opacity) !important; }`，
  即复用 N.E.K.O 原生的透明度乘子机制。该乘子乘的是各聊天表面底色的 alpha
  （原生写法形如 `rgba(255,255,255,calc(.91 * var(--neko-chat-opacity-factor, 1)))`），
  因此它缩放的是**聊天面板/窗口整体的不透明度**，而不是任何单个颜色。取值 0–1。
  `--nts-shadow` 则直接写在 7 个卡片面上
  （`.message-bubble-user` / `.message-bubble-assistant` / `.composer-panel` /
  `.composer-icon-popover` / `.composer-overflow-popover` / `.modal-dialog` /
  `.proactive-recommendation-card`）。
  ⚠️ 该控件曾是**死控件**：应用侧加载器原先没有 `number` 值类型，
  面板与后端都接受、加载器却按颜色校验后静默丢弃。现已修复
  （加载器新增 kind `number`，正则 `/^(?:0|1|0?\.[0-9]+)$/`）。
- `--nts-topbar-text`、`--nts-input-text`、`--nts-button-text` 等若干变量的
  原生值是 `inherit`，面板里无法用色块表示，这类行请使用文本输入框。
- 应用侧加载器每 1500ms 轮询一次且只在窗口可见时进行，因此改完之后最多
  约 1.5 秒（或窗口重新获得焦点时）生效。
- 面板预览是模拟，不反映 `.message.gemini` 的 `border-bottom-left-radius: 4px`
  这类组件级细节。
- **每一条规则**都是门控的（`data-nts-l-<var>` / `data-nts-d-<var>`，见 §5.1）：
  只有当用户真的在对应模式里设了那个变量，加载器才会给 `<html>` 打上对应属性、
  规则才生效。这是「未配置 = 零变化」不变量的实现方式，不是缺陷。
- **静态量测页无法验证的两类目标**（它们的生效条件在静态页里根本不会出现，
  §10 的 A/B 台也覆盖不到，只能靠真实页手测）：
  - **悬停态**：`--nts-button-hover-bg` 只在鼠标悬停工具按钮时生效
    （`.composer-tool-btn:hover`），静态页没有指针，规则永不匹配；
  - **`::selection`**：`--nts-highlight` 只在用户划选文本时生效
    （`body ::selection { background-color: var(--nts-highlight) !important }`），
    静态页没有选区。
  - 二者同样是门控的，且清除后精确还原。
- 变量名现在受**白名单**限制：`plugin/__init__.py` 的 `KNOWN_VARS`（60 个名字）
  会拒绝未知变量名。此前一个拼错的名字（如 `--nts-nope-var`）会被后端照收、
  写进 `theme.json`、并回显为「已接受」，但样式表里没有任何东西消费它 ——
  一个看起来成功的静默空操作。因此：**往面板里加变量，必须同时加进 `KNOWN_VARS`**。
- 白名单实际有**三份**，漏掉任何一份都会静默丢弃：
  1. 后端入口 `plugin/__init__.py` 的 `KNOWN_VARS`（名字白名单）+ `LENGTH_VARS`
     （值类型判定，不在里面会被当颜色校验而拒收 `22px`）；
  2. 应用侧加载器 `plugin/static/loader/neko-theme-studio.js` 的 `NON_COLOR_VARS`
     （决定 `length` 还是 `color`，同样会静默 `log('reject value', …)`）；
  3. 面板 `plugin/static/app.js` 的 `CATALOG`（控件本身）。
  加变量时还必须在 `test/targets.js` 里写上消费方，否则样式表里没有规则去用它。
  **改完 `__init__.py` 必须重启插件进程**（`POST /plugins/refresh` 不够，实测
  `updated: []`；要 `POST /plugin/<id>/stop` 再 `start`），否则运行中的进程仍用
  内存里的旧 `KNOWN_VARS`，新变量会被静默丢弃而 `apply_theme` 照样返回 succeeded。
- v3 **门控的不是「少数目标」，而是全部目标**：生成的样式表里每一条规则都带
  `data-nts-l-<var>` / `data-nts-d-<var>` 门（见 §5.1），没有任何例外，
  因此也不存在「必须门控的特殊一小撮」这种分类。
- 之所以连一个回退值都不留，是因为「量到的原生值」在真实应用页上被证伪过。
  量测页（fixture）看不到四件事：
  - 真实 `/chat` 的 `<body>` 带 `.electron-chat-window` 类，使
    `body:not(.electron-chat-window) …` 这类规则在真实页**根本不生效**；
  - 真实祖先链带来的同特异性后置规则胜出（如 `.chat-body` 在
    `.chat-window.chat-surface-mode-compact` 下会被后一条
    `background: transparent` 覆盖，fixture 记到的是被压掉的那一条）；
  - 应用的真实视口宽度（fixture 会落进 `@media (max-width:768px)` 分支）；
  - 应用**运行时注入的 `<style>` 层**（带 `!important`，压过所有样式表）。
  这四条正是整个「量出来的回退值」方案被废弃的理由（§5.2）：回退值一旦写死，
  就会在用户**根本没配置**的情况下静默改写外观。v3 干脆一个都不写。
- `tools/gen-css.js` **不再读** `test/ab-baseline.json` 与 `build/ab.json`
  （其文件头把它们列为 informational，仅此而已）：生成器产出 0 个回退值，
  也就没有任何东西需要一个「否决集」去否决。
  `tools/build-theme-css.ps1` 的 [2/5] 步仍然跑一次真实页 A/B，
  但**纯属留证**（输出里写的是 `EVIDENCE ONLY -- v3 has no fallbacks to veto`）；
  真正的闸门是 [5/5] 步：部署后再量一次，若空调色板下真实页有任何变化就构建失败。

---

## 10. 校验清单（已实测）

| 项目 | 结果 |
| --- | --- |
| 后端 205 项断言（合并 / 版本号 / 拒绝 / 删除 / 容错 / 导出导入 / 原子性 / 并发 / 归一化 / 负值 / 严格读 / 导入上限） | 全部通过（`_local_verify/backend/audit_backend.py`） |
| 40 个并发 `apply_theme` 的版本号 | 40 个全不相同，无丢更新 |
| 恶意值落盘检查 | `display:none`、`position:fixed`、`url(`、`--compact-*`、`--xy-*` 均未出现在 `theme.json` |
| 面板变量目录 vs 契约 §3 | 59 个变量（契约另有 1 个 `--nts-x` 仅作注释示例），无缺失、无多余、无重复 |
| 面板 `app.js` 引用的 DOM id vs `index.html` | 47 个引用全部存在（`_local_verify/ui_consistency.js`） |
| 面板 UI 行为（搜索 / 只看改动 / 清空按钮 / 分组折叠 / 复制 dump / 弹窗焦点） | 41 项断言全部通过（`theme-studio/test/panel-ui.js`） |
| 面板提交链路（读取 → 编辑 → 应用 → 重读） | 18 项断言全部通过（`theme-studio/test/panel-smoke.js`） |
| 「面板有控件、CSS 无人消费」检查 | 0 项（曾为 2 项：`--nts-button-hover-bg`、`--nts-rec-border`，已修） |
| 前后端校验器差分（43 变量 × 86 个值 = 3698 例） | 判定完全一致，0 处分歧，0 例「前端放行、后端拒绝」 |
| 三方差分复核（面板 / 加载器 / 后端 × 2132 例，含负数、百分比与 shadow 结构边界） | 三方 **0 处分歧**，见 §3.4 |
| 面板交互缺陷探针（透明色、清空语义、预览圆角/模糊、阴影标红、被拒回填） | 11 项全部通过（`_local_verify/panel_bugs.js`） |
| `node --check static/app.js` | 通过 |

`test/accept.ps1` 的 56 项端到端闸门（全部通过，退出码 0）：

| 组 | 覆盖 |
| --- | --- |
| A | 插件已注册、`status=running`、有 static 面板、`theme.json` 可经静态路由取得 |
| C | **零变化不变量**：空调色板下，装载/不装载本样式表的计算样式逐行相同（亮、暗各 35 个量测点，差异均为 0）|
| D | 全调色板（7 类颜色）在亮/暗下都改变 ≥50% 量测点；用户气泡 = 请求色；暗色覆盖胜出；`blur(30px)` 真的生效；圆角生效 |
| E | `reset_theme` 后亮/暗都**精确**回到原生（差异 0）|
| F1 | **面板 UI 实操**：在真实面板里键入颜色 → 行变脏 → 「应用（1 项改动）」→ 报成功 → 值落到 `theme.json` → 「重置」→ 报成功 → 调色板清空、脏状态清零、色块回中性 |
| F2 | **门控变量在真实页上按模式双向可用**：对亮、暗**各测一遍**，三个门控变量（壳层圆角 / 输入区背景 / 输入区描边）在设置后移到请求值、清除后精确还原；并且**另一模式保持惰性**——另一模式的计算值仍是原生值，且另一模式那一组 `data-nts-*` 门属性从未被设置过 |
