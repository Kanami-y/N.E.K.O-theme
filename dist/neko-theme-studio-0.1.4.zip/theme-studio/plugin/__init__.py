"""neko_theme_studio —— N.E.K.O 主题工坊插件。

职责（见 theme-studio/THEME_CONTRACT.md）：

1. 保管一份「调色板」JSON（``static/theme.json``），它是应用侧加载器
   （``resources/bin/static/neko-theme-studio.js``）唯一读取的数据源。
2. 提供五个 entry 供静态面板（``static/index.html`` + ``static/app.js``）
   读取 / 修改 / 重置 / 导出 / 导入这份调色板。
3. **服务端校验是安全边界**：面板是跨源 iframe，所有输入都不可信。任何
   不合规的变量名或值都必须被拒绝，且绝不落盘。

文件位置：``static/theme.json`` 必须与面板同目录 —— 因为 48916 只把
``/plugin/<id>/ui/*`` 映射到插件的 ``static/``，加载器正是从那里取数据。
"""

from __future__ import annotations

import json
import os
import re
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from plugin.sdk.plugin import (
    Err,
    NekoPluginBase,
    Ok,
    SdkError,
    lifecycle,
    neko_plugin,
    plugin_entry,
    tr,
    ui,
)

# 应用侧自愈补丁：让「装上插件就能用」成立，不需要任何人手工跑 install.ps1。
# 插件被宿主以 plugin.plugins.neko_theme_studio 的形式导入，也可能被当成独立模块
# 载入（测试/构建工具），两条路径都要能取到。
try:  # pragma: no cover - 取决于宿主导入方式
    from . import _app_patch
except ImportError:  # pragma: no cover
    try:
        import _app_patch  # type: ignore[no-redef]
    except ImportError:  # pragma: no cover - 极端情况下退化为「无补丁」
        _app_patch = None  # type: ignore[assignment]

# --------------------------------------------------------------------------- 常量

SCHEMA_VERSION = 1
DEFAULT_THEME_NAME = "默认"

#: 写文件的全局锁。宿主可能并发调用 entry（面板点击 + 轮询 + 生命周期），
#: 必须串行化「读 → 合并 → 原子替换」整段，否则会丢更新。
_WRITE_LOCK = threading.Lock()

#: 变量名前缀与形态（契约 §3）。
RE_VAR_NAME = re.compile(r"^--nts-[a-z0-9-]{1,60}$")

#: 已知变量白名单 —— **形式合法不等于有意义**。
#:
#: 缺了这道门会出现「报成功的静默空操作」：``apply_theme`` 传入一个拼错的变量名
#: （例如 ``--nts-nope-var``）时，后端照收、写进 theme.json、回显为已接受，
#: 但 ``neko-theme-studio.css`` 里没有任何规则消费它，用户看不到任何变化。
#: 独立验证者实测确认过这一点。
#:
#: 清单来源 = ``tools/gen-css.js`` 实际产出的样式表里出现过的全部 ``--nts-*``
#: （可用 ``build/vars.json`` 交叉核对：CSS 消费 59 个 = 本集合）。
#: 新增变量的顺序：先在 ``test/targets.js`` 加目标 → 跑 ``tools/build-theme-css.ps1``
#: → 把生成 CSS 里新出现的名字加到这里与面板 CATALOG。
KNOWN_VARS = frozenset(
    {
        "--nts-accent",
        "--nts-accent-bg",
        "--nts-ai-bubble-bg",
        "--nts-ai-bubble-border",
        "--nts-ai-bubble-text",
        "--nts-bubble-radius",
        "--nts-button-bg",
        "--nts-button-hover-bg",
        "--nts-button-text",
        "--nts-card-radius",
        "--nts-chat-bg",
        "--nts-chat-blur",
        "--nts-chat-opacity",
        "--nts-chat-panel-bg",
        "--nts-chat-panel-radius",
        "--nts-chip-bg",
        "--nts-chip-text",
        "--nts-code-bg",
        "--nts-code-text",
        "--nts-font-family",
        "--nts-font-size",
        "--nts-highlight",
        "--nts-image-bg",
        "--nts-input-bg",
        "--nts-input-border",
        "--nts-input-placeholder",
        "--nts-input-text",
        "--nts-link",
        "--nts-modal-bg",
        "--nts-modal-radius",
        "--nts-modal-text",
        "--nts-overlay-bg",
        "--nts-panel-bg",
        "--nts-panel-border",
        "--nts-panel-text",
        "--nts-panel-text-sub",
        "--nts-popover-bg",
        "--nts-popover-border",
        "--nts-popover-radius",
        "--nts-popover-text",
        "--nts-radius",
        "--nts-rec-bg",
        "--nts-rec-border",
        "--nts-rec-radius",
        "--nts-rec-text",
        "--nts-scrollbar-thumb",
        "--nts-scrollbar-track",
        "--nts-send-bg",
        "--nts-send-text",
        "--nts-shadow",
        "--nts-shell-radius",
        "--nts-status-bg",
        "--nts-status-text",
        "--nts-tool-bubble-bg",
        "--nts-tool-bubble-text",
        "--nts-topbar-bg",
        "--nts-topbar-text",
        "--nts-user-bubble-bg",
        "--nts-user-bubble-border",
        "--nts-user-bubble-text",
    }
)

#: 允许的颜色值形态。刻意保守：整串锚定，杜绝把任意 CSS 注入变量。
RE_HEX = re.compile(
    r"^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$", re.IGNORECASE
)
RE_RGB = re.compile(
    r"^rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}"
    r"\s*(?:,\s*(?:0|1|0?\.[0-9]+)\s*)?\)$",
    re.IGNORECASE,
)
RE_HSL = re.compile(
    r"^hsla?\(\s*-?[0-9]{1,3}(?:\.[0-9]+)?\s*,"
    r"\s*[0-9]{1,3}(?:\.[0-9]+)?%\s*,"
    r"\s*[0-9]{1,3}(?:\.[0-9]+)?%\s*"
    r"(?:,\s*(?:0|1|0?\.[0-9]+)\s*)?\)$",
    re.IGNORECASE,
)
RE_KEYWORD_COLOR = re.compile(r"^transparent$", re.IGNORECASE)

#: 非颜色项：长度 / 百分比。
RE_LENGTH = re.compile(r"^-?[0-9]{1,4}(?:\.[0-9]+)?(?:px|rem|em|%|pt|vh|vw)$", re.IGNORECASE)
RE_PERCENT = re.compile(r"^[0-9]{1,3}(?:\.[0-9]+)?%$")
RE_ZERO = re.compile(r"^0$")

#: 透明度类（0–1 或百分比）。
RE_NUMBER = re.compile(r"^(?:0|1|0?\.[0-9]+)$")

#: 字体名白名单：字母数字、中日文、空格、逗号、引号、连字符、下划线、点。
RE_FONT = re.compile(r"^[A-Za-z0-9\u4e00-\u9fff ,'\"\-_.]{1,200}$")

#: 明确拒绝的危险片段。注意这里**不**禁用圆括号 —— rgb()/hsl() 合法值本身
#: 需要括号，安全性由上面每个 kind 的「整串锚定」正则保证。
RE_FORBIDDEN = re.compile(r"[;{}<>\\]|@import|url\s*\(", re.IGNORECASE)

#: 长度/百分比语义的变量。
#:
#: 分区圆角（``--nts-bubble-radius`` 等 6 个）与 ``--nts-radius`` 是**并列**的独立
#: 旋钮，不是别名：``neko-theme-studio.css`` 为每个区域单独生成声明，且每个变量
#: 都带自己的原生回退值（气泡 16px/8px、外壳 14px、卡片 0px、弹窗 0px、浮层 12px、
#: 推荐卡 18px）。因此留空即完全保持原生外观 —— 把它们纳入白名单不会破坏
#: 契约 §9.3 的「未配置零变化」。
LENGTH_VARS = frozenset(
    {
        "--nts-radius",
        "--nts-font-size",
        "--nts-bubble-radius",
        "--nts-shell-radius",
        "--nts-card-radius",
        "--nts-modal-radius",
        "--nts-popover-radius",
        "--nts-rec-radius",
        "--nts-chat-panel-radius",
    }
)
#: ``--nts-chat-blur`` 在契约 §3 里写作「px」，但 ``neko-theme-studio.css`` 实际
#: 把它的原生值写成 ``blur(18px)`` 并直接喂给 ``backdrop-filter``：
#:   ``backdrop-filter: var(--nts-chat-blur, blur(18px))``
#: 若只写 ``18px``，backdrop-filter 会因语法非法被整条丢弃 → 毛玻璃消失，
#: 且**没有任何报错**。这里两种写法都接受，并由面板统一输出 ``blur(...)``。
BLUR_VARS = frozenset({"--nts-chat-blur"})
RE_BLUR = re.compile(r"^blur\(\s*-?[0-9]{1,4}(?:\.[0-9]+)?(?:px|rem|em|pt)\s*\)$", re.IGNORECASE)
#: 裸长度里对 blur 合法的写法。``blur()`` 只接受绝对长度，``%``/``vh``/``vw``
#: 会被 ``backdrop-filter`` 整条丢弃；而 ``RE_LENGTH`` 为了 shadow 偏移量必须放行它们，
#: 所以这里单列一个更严的正则，避免 ``blur(18%)`` 这种「校验通过、CSS 无效」的产物。
RE_BLUR_BARE = re.compile(r"^-?[0-9]{1,4}(?:\.[0-9]+)?(?:px|rem|em|pt)$", re.IGNORECASE)
#: 阴影变量：契约 §3 列为非颜色项，但真正需要的是一个 box-shadow 串，
#: 因此按 token 逐项校验（长度 / 安全颜色 / inset），而不是当成单一长度。
SHADOW_VARS = frozenset({"--nts-shadow"})
#: 字体变量。
FONT_VARS = frozenset({"--nts-font-family"})
#: 透明度变量（契约 §3 列为非颜色项，但既非长度也非字体）。
NUMBER_VARS = frozenset({"--nts-chat-opacity"})

#: ``import_theme`` 接受的 JSON 文本上限（与 input_schema 的 ``maxLength`` 同源）。
#: input_schema 只是给宿主的声明，宿主不保证强制执行，因此代码里必须自己兜底。
IMPORT_MAX_CHARS = 262144


# --------------------------------------------------------------------------- 默认调色板

def _default_vars() -> dict[str, str]:
    """亮色（``:root``）默认值 —— **空**，这是刻意的。

    契约 §9.3 要求「未配置时视觉零变化」。而 ``neko-theme-studio.css`` 里
    同一条变量在不同规则上带着**不同**的原生回退值，例如：

    - ``--nts-radius``: ``border-radius: var(--nts-radius, 0|8px|10px|12px)``
      （topbar 是 0，卡片/面板是 12px，按钮/发送键是 10px）
    - ``--nts-input-bg``: ``#text-input-area`` 回退 ``rgba(40,40,40,0.65)``，
      而 ``.composer-input`` 回退 ``transparent``

    一旦在 ``:root`` 里钉住任一值，所有这些规则都会被同一个值覆盖 ——
    也就是「没配主题却看得到变化」，直接违反 §9.3。应用侧加载器同样把空
    调色板理解为「恢复原样」（``neko-theme-studio.js``：空 vars ⇒ removeStyle）。

    因此出厂调色板是空的；完整变量目录 + 原生参考值放在面板 ``static/app.js``
    的 CATALOG 里（面板默认显示原生值，仅在用户真正改动某一行时才写入该行）。
    """
    return {}


def _default_dark_vars() -> dict[str, str]:
    """暗色（``:root[data-theme="dark"]``）默认值 —— 同样为空，理由见上。"""
    return {}


def _now_iso() -> str:
    """本地时区 ISO-8601，例如 ``2026-11-07T16:00:00+08:00``。"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


def default_palette() -> dict[str, Any]:
    """内置默认调色板（``reset_theme`` 与首次落盘都用它）。"""
    return {
        "schema": SCHEMA_VERSION,
        "version": 1,
        "name": DEFAULT_THEME_NAME,
        "enabled": True,
        "updated_at": _now_iso(),
        "vars": _default_vars(),
        "dark_vars": _default_dark_vars(),
    }


# --------------------------------------------------------------------------- 校验

def _value_kind(name: str) -> str:
    if name in LENGTH_VARS:
        return "length"
    if name in BLUR_VARS:
        return "blur"
    if name in SHADOW_VARS:
        return "shadow"
    if name in FONT_VARS:
        return "font"
    if name in NUMBER_VARS:
        return "number"
    return "color"


def _shadow_tokens(value: str) -> list[str]:
    """按「括号外空白」切分阴影串；括号不配对则返回空列表。"""
    tokens: list[str] = []
    depth = 0
    buf = ""
    for ch in value:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return []
        if ch.isspace() and depth == 0:
            if buf:
                tokens.append(buf)
                buf = ""
            continue
        buf += ch
    if buf:
        tokens.append(buf)
    if depth != 0:
        return []
    return tokens


def _is_safe_value(name: str, value: Any) -> bool:
    """值是否可安全写进给定变量（整串匹配，不允许任何附加内容）。"""
    if not isinstance(value, str):
        return False
    v = value.strip()
    if not v or len(v) > 200:
        return False
    if RE_FORBIDDEN.search(v):
        return False

    kind = _value_kind(name)
    if kind == "color":
        return bool(
            RE_KEYWORD_COLOR.match(v)
            or RE_HEX.match(v)
            or RE_RGB.match(v)
            or RE_HSL.match(v)
        )
    if kind == "length":
        # 负长度在 CSS 里一律非法（``border-radius`` / ``font-size`` 收到负值会把整条
        # 声明丢掉 → 面板报成功、外观不变）。RE_LENGTH 为了 shadow 的偏移量必须允许
        # 负号，而 shadow 走的是自己的 token 分支，所以在这里单独拦住即可。
        if "-" in v:
            return False
        return bool(RE_LENGTH.match(v) or RE_PERCENT.match(v) or RE_ZERO.match(v))
    if kind == "blur":
        # 同时接受 `blur(18px)`（CSS 能用的形态）与裸长度 `18px`（契约 §3 的写法），
        # 裸长度稍后会被规范化为 blur(...)。
        # 负半径会让 ``backdrop-filter`` 整条失效（静默无变化），而模糊值永远用不到负号。
        if "-" in v:
            return False
        # 只收绝对长度：blur(18%) / blur(18vw) 不是合法 CSS，放行就会落盘一个
        # loader 必丢的值（面板报成功、外观不变）。
        return bool(RE_BLUR.match(v) or RE_BLUR_BARE.match(v) or RE_ZERO.match(v))
    if kind == "number":
        # 契约语义是 0–1 的小数；百分比是面板的友好写法，但只有 0%–100% 有意义
        # （999% 归一后 >1，loader 会丢弃 → 又变成「能存不能用」）。
        if RE_NUMBER.match(v):
            return True
        if not RE_PERCENT.match(v):
            return False
        try:
            return float(v[:-1]) <= 100.0
        except ValueError:  # pragma: no cover — RE_PERCENT 已保证是数字
            return False
    if kind == "font":
        return bool(RE_FONT.match(v))
    if kind == "shadow":
        # box-shadow 的 CSS 语法是 inset? && <length>{2,4} && <color>?。
        # 只做 token 白名单会放行 0 0 10% #000（百分比不是 box-shadow 的合法长度）、
        # 1px（长度不足）、1px 2px 3px 4px 5px（长度过多）——浏览器会把整条声明丢掉，
        # 面板却显示已应用（与「改了没反应」同症状）。
        # 面板 isSafeShadow / loader isSafeValue 必须逐条同判定（THEME_CONTRACT 9.10b）。
        tokens = _shadow_tokens(v)
        if not tokens or len(tokens) > 6:
            return False
        lengths = 0
        colors = 0
        insets = 0
        for token in tokens:
            if token.lower() == "inset":
                insets += 1
                if insets > 1:
                    return False
                continue
            if (
                RE_KEYWORD_COLOR.match(token)
                or RE_HEX.match(token)
                or RE_RGB.match(token)
                or RE_HSL.match(token)
            ):
                colors += 1
                if colors > 1:
                    return False
                continue
            if RE_PERCENT.match(token) or "%" in token:
                return False
            if RE_LENGTH.match(token) or RE_ZERO.match(token):
                lengths += 1
                if lengths > 4:
                    return False
                # 负值只允许前两个长度（x/y 偏移）；模糊/扩散半径不能为负
                if token.startswith("-") and lengths > 2:
                    return False
                continue
            return False
        return lengths >= 2
    return False


def _canonicalize_value(name: str, value: str) -> str:
    """把通过校验的值规范化成 CSS 真正需要的形态。

    两处：

    - ``--nts-chat-blur``：消费方是
      ``backdrop-filter: var(--nts-chat-blur, blur(18px))``，因此裸长度
      ``18px`` 必须补成 ``blur(18px)``，否则整条声明被浏览器丢弃。
    - ``--nts-chat-opacity``：契约语义是 0–1 的小数，而面板允许用户写
      ``50%``。这里统一归一成小数（四舍五入到 4 位、去尾零），使 theme.json
      里永远是 loader 能直接消费的形态 —— 否则 loader 会把百分比静默丢弃，
      用户看到「面板说成功、透明度没变」。
    """
    if name in BLUR_VARS and RE_BLUR_BARE.match(value):
        return f"blur({value})"
    if name in NUMBER_VARS and value.endswith("%"):
        try:
            fraction = round(float(value[:-1]) / 100.0, 4)
        except ValueError:  # pragma: no cover — 校验阶段已保证是数字
            return value
        text = f"{fraction:.4f}".rstrip("0").rstrip(".")
        return text or "0"
    return value


def _validate_palette(
    vars_in: Any, dark_in: Any
) -> tuple[dict[str, str], dict[str, str], list[str]]:
    """校验并过滤两组变量。

    :returns: ``(clean_vars, clean_dark, errors)`` —— clean 字典是**唯一**
        允许落盘的内容；errors 是给用户看的拒绝原因列表。
    """
    clean_vars: dict[str, str] = {}
    clean_dark: dict[str, str] = {}
    errors: list[str] = []

    for label, src, out in (("vars", vars_in, clean_vars), ("dark_vars", dark_in, clean_dark)):
        if src is None:
            continue
        if not isinstance(src, dict):
            errors.append(f"{label}: 必须是对象")
            continue
        for raw_name, raw_value in src.items():
            name = str(raw_name)
            if not RE_VAR_NAME.match(name):
                errors.append(f"{label}: 变量名非法已拒绝 {name!r}")
                continue
            if name not in KNOWN_VARS:
                # 形式合法但没有规则消费 → 必须报错。否则「报成功的静默空操作」
                # 会让用户以为改成功了（独立验证者实测过 --nts-nope-var）。
                errors.append(
                    f"{label}: 未知变量名已拒绝 {name!r}（拼写错误？见 README 变量清单）"
                )
                continue
            if raw_value is None:
                # 显式置空 = 删除该键（回退到 N.E.K.O 原生值）。
                continue
            if not isinstance(raw_value, str):
                errors.append(f"{label}: {name} 的值必须是字符串")
                continue
            value = raw_value.strip()
            if not value:
                # 空串 = 删除该键（面板的「清空」语义）。
                continue
            if not _is_safe_value(name, value):
                errors.append(f"{label}: {name} 的值非法已拒绝 {value!r}")
                continue
            out[name] = _canonicalize_value(name, value)

    return clean_vars, clean_dark, errors


_TRUE_WORDS = frozenset({"true", "1", "yes", "on"})
_FALSE_WORDS = frozenset({"false", "0", "no", "off"})


def _coerce_bool(value: Any) -> bool | None:
    """把「布尔语义」的值规整成 bool；无法判定时返回 ``None``。

    存在的理由：theme.json 可能被手工编辑成 ``"enabled": "false"``，而
    ``bool("false")`` 是 True —— 那会把用户关掉的主题静默重新启用。
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return bool(value)
    if isinstance(value, float):
        return None if value != value else bool(value)  # NaN → 无法判定
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in _TRUE_WORDS:
            return True
        if lowered in _FALSE_WORDS:
            return False
    return None


class _ThemeUnreadable(RuntimeError):
    """theme.json 存在但读不出来（权限 / 被占用 / JSON 损坏）。

    写路径遇到它必须中止：若像读路径那样退回 ``default_palette()``，一次瞬时
    读取失败（Windows 上杀毒软件或索引器锁文件即可触发）就会把用户已保存的
    全部变量抹掉、只剩本次新值，而且返回 Ok。
    """


# --------------------------------------------------------------------------- 插件

@neko_plugin
class NekoThemeStudioPlugin(NekoPluginBase):
    """主题工坊：调色板的唯一权威保管者。"""

    def __init__(self, ctx: Any) -> None:
        super().__init__(ctx)
        try:
            self.logger = self.enable_file_logging(log_level="INFO")
        except Exception:  # noqa: BLE001 — 文件日志不可用不应阻止插件启动
            self.logger = getattr(ctx, "logger", None)

        self.plugin_root = Path(__file__).resolve().parent
        self.static_dir = self.plugin_root / "static"
        self.theme_path = self.static_dir / "theme.json"
        #: 最近一次应用侧自愈补丁的诊断结果（startup 或 repair 入口写入）。
        self._app_patch_result: dict[str, Any] = {}

    # ------------------------------------------------------------- 内部工具

    def _log(self, level: str, message: str) -> None:
        logger = getattr(self, "logger", None)
        fn = getattr(logger, level, None)
        if callable(fn):
            try:
                fn(message)
            except Exception:  # noqa: BLE001
                pass

    def _normalize(self, raw: Any) -> dict[str, Any]:
        """把任意来源的数据规整成合法调色板；坏数据一律回退默认值。"""
        base = default_palette()
        if not isinstance(raw, dict):
            return base

        try:
            version = int(raw.get("version", base["version"]))
        except (TypeError, ValueError):
            version = base["version"]

        name = raw.get("name")
        name = str(name) if isinstance(name, str) and name.strip() else base["name"]

        updated_at = raw.get("updated_at")
        updated_at = (
            str(updated_at)
            if isinstance(updated_at, str) and updated_at.strip()
            else base["updated_at"]
        )

        # 磁盘上的内容也要过滤：文件可能被手工编辑或被其它程序写坏。
        clean_vars, clean_dark, errors = _validate_palette(
            raw.get("vars"), raw.get("dark_vars")
        )
        for message in errors:
            self._log("warning", f"theme.json 中被忽略的条目 —— {message}")

        # 不能直接 bool(...)：字符串 "false" 是真值，会把用户关掉的主题静默重开。
        raw_enabled = raw.get("enabled", True)
        enabled = _coerce_bool(raw_enabled)
        if enabled is None:
            self._log("warning", f"theme.json 的 enabled 无法解析（{raw_enabled!r}），按启用处理")
            enabled = True

        return {
            "schema": SCHEMA_VERSION,
            "version": max(version, 1),
            "name": name,
            "enabled": enabled,
            "updated_at": updated_at,
            "vars": clean_vars,
            "dark_vars": clean_dark,
        }

    def _read_unlocked(self, *, strict: bool = False) -> dict[str, Any]:
        """读盘。文件缺失/损坏/权限错误 → 默认值，绝不抛异常。

        :param strict: 给**写路径**用。文件存在却读不出来时抛 ``_ThemeUnreadable``
            而不是退回默认值 —— 默认值只适合「首次运行」，把它当成合并基线
            会静默清空用户已保存的变量（见 ``_ThemeUnreadable`` 的说明）。
            文件确实不存在时两条路径都返回默认值（首次运行的正常情形）。
        """
        try:
            text = self.theme_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return default_palette()
        except OSError as exc:
            if strict:
                raise _ThemeUnreadable(f"读取 theme.json 失败：{exc}") from exc
            self._log("warning", f"读取 theme.json 失败，使用默认值：{exc}")
            return default_palette()
        try:
            return self._normalize(json.loads(text))
        except (ValueError, TypeError) as exc:
            if strict:
                raise _ThemeUnreadable(f"theme.json 解析失败：{exc}") from exc
            self._log("warning", f"theme.json 解析失败，使用默认值：{exc}")
            return default_palette()

    def _write_unlocked(self, palette: dict[str, Any]) -> None:
        """原子写：同目录临时文件 → ``os.replace``。

        同目录是硬要求，否则 ``os.replace`` 可能跨卷失败（非原子）。
        """
        self.static_dir.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(palette, ensure_ascii=False, indent=2, sort_keys=False)
        tmp_path = self.static_dir / f".theme.json.{os.getpid()}.{threading.get_ident()}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path, self.theme_path)
        finally:
            # 替换成功后 tmp 已不存在；失败路径必须自己清理。
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except OSError:
                pass

    def _ensure_file(self) -> None:
        """启动时保证 ``static/theme.json`` 存在（内容不合法则备份后重写为默认）。"""
        with _WRITE_LOCK:
            if not self.theme_path.exists():
                self._write_unlocked(default_palette())
                self._log("info", f"已创建默认调色板：{self.theme_path}")
                return
            try:
                text = self.theme_path.read_text(encoding="utf-8")
                json.loads(text)
            except OSError as exc:
                # 「读不出来」（被占用 / 权限）≠「内容坏了」：绝不能拿默认值覆盖，
                # 否则一次瞬时占用就把用户的主题毁掉。保持原样，下次启动再试。
                self._log("warning", f"theme.json 暂时不可读（{exc}），保持原样")
                return
            except ValueError as exc:
                # 内容确实坏了：先把原文件留档再写默认值，不静默销毁用户数据。
                backup = self.theme_path.with_name(self.theme_path.name + ".corrupt")
                try:
                    os.replace(self.theme_path, backup)
                    self._log(
                        "warning",
                        f"theme.json 解析失败（{exc}），原文件已备份为 {backup.name}",
                    )
                except OSError as move_exc:  # pragma: no cover — 备份失败也不阻止恢复
                    self._log(
                        "warning",
                        f"theme.json 解析失败（{exc}），备份失败（{move_exc}）",
                    )
                self._write_unlocked(default_palette())

    def _apply_and_store(
        self,
        *,
        vars_in: Any = None,
        dark_in: Any = None,
        name: Any = None,
        enabled: Any = None,
    ) -> tuple[dict[str, Any], list[str]]:
        """合并 → 校验 → 原子写 → 版本号 +1。返回 (新调色板, 拒绝原因)。"""
        with _WRITE_LOCK:
            # strict：拿不到真实基线就中止，绝不用默认值覆盖用户已保存的调色板。
            palette = self._read_unlocked(strict=True)

            merged_vars = dict(palette["vars"])
            merged_dark = dict(palette["dark_vars"])

            clean_vars, clean_dark, errors = _validate_palette(vars_in, dark_in)

            # 删除语义：显式传空串 / None = 回退到 N.E.K.O 原生值。
            # 注意：**被拒绝**的值不会走到这里（它既不在 clean 里，也不是空值），
            # 因此旧值会被原样保留 —— 一次误输入不会毁掉已有的好值。
            for source, merged in ((vars_in, merged_vars), (dark_in, merged_dark)):
                if not isinstance(source, dict):
                    continue
                for raw_name, raw_value in source.items():
                    key = str(raw_name)
                    if not RE_VAR_NAME.match(key):
                        continue
                    if raw_value is None or (
                        isinstance(raw_value, str) and not raw_value.strip()
                    ):
                        merged.pop(key, None)
            merged_vars.update(clean_vars)
            merged_dark.update(clean_dark)

            palette["vars"] = merged_vars
            palette["dark_vars"] = merged_dark

            if isinstance(name, str):
                # 传空串/纯空白 = 恢复默认名（面板清空输入框时走这条），不是错误。
                palette["name"] = name.strip()[:60] or DEFAULT_THEME_NAME
            elif name is not None:
                errors.append(f"name: 必须是字符串，收到 {type(name).__name__}")

            if enabled is not None:
                coerced = _coerce_bool(enabled)
                if coerced is None:
                    errors.append(f"enabled: 无法解析为布尔值 {enabled!r}")
                else:
                    palette["enabled"] = coerced

            # 版本号只在真正落盘时自增，应用侧靠它判断是否需要重绘。
            palette["version"] = int(palette.get("version", 1)) + 1
            palette["updated_at"] = _now_iso()
            palette["schema"] = SCHEMA_VERSION

            self._write_unlocked(palette)
            return palette, errors

    # ------------------------------------------------------------- 生命周期

    @lifecycle(id="startup")
    async def startup(self, **_):
        self._ensure_file()
        palette = self._read_unlocked()
        self._log(
            "info",
            f"neko_theme_studio 已启动，调色板 v{palette['version']} "
            f"({len(palette['vars'])} 亮色 / {len(palette['dark_vars'])} 暗色变量)",
        )
        # 应用侧自愈：把 loader 两件套 + 模板标记装上/刷新。
        # 这一步是「装上插件就能用」的全部秘密 —— 宿主没有注入 API，只能靠它
        # 把 resources/bin/static 与 templates 的两行标签准备好。
        # 失败绝不影响启动（ensure_app_patch 内部吞掉一切异常）。
        patch = self._run_app_patch()
        return Ok(
            {
                "status": "ready",
                "version": palette["version"],
                "theme_path": str(self.theme_path),
                "app_patch": patch,
            }
        )

    def _run_app_patch(self) -> dict[str, Any]:
        """跑一次应用侧自愈补丁，返回诊断摘要（绝不抛异常）。"""
        if _app_patch is None:  # pragma: no cover - 极端情况
            self._log("warning", "应用侧补丁模块缺失（_app_patch.py），主题可能无法生效")
            return {"ok": False, "warnings": ["_app_patch 模块不可用"]}
        try:
            result = _app_patch.ensure_app_patch(self.plugin_root, self._log)
        except Exception as exc:  # noqa: BLE001 —— 兜底，模块内部已吞异常
            self._log("warning", f"应用侧补丁异常（已忽略）：{exc}")
            return {"ok": False, "warnings": [str(exc)]}
        for warning in result.get("warnings", []):
            self._log("warning", warning)
        self._app_patch_result = result
        return result

    @lifecycle(id="shutdown")
    def shutdown(self, **_):
        self._log("info", "neko_theme_studio 已停止")
        return Ok({"status": "shutdown"})

    # ------------------------------------------------------------- UI context

    @ui.context(id="dashboard", title=tr("plugin.name", default="主题工坊"))
    async def studio_context(self) -> dict[str, Any]:
        palette = self._read_unlocked()
        return {
            "version": palette["version"],
            "name": palette["name"],
            "enabled": palette["enabled"],
            "updated_at": palette["updated_at"],
            "var_count": len(palette["vars"]),
            "dark_count": len(palette["dark_vars"]),
            "theme_url": f"/plugin/{self.plugin_id}/ui/theme.json",
            "app_patch": getattr(self, "_app_patch_result", {}) or {},
            "actions": [
                {"id": "get_theme", "entry_id": "get_theme"},
                {"id": "apply_theme", "entry_id": "apply_theme"},
                {"id": "reset_theme", "entry_id": "reset_theme"},
                {"id": "export_theme", "entry_id": "export_theme"},
                {"id": "import_theme", "entry_id": "import_theme"},
            ],
        }

    # ------------------------------------------------------------- entries

    @plugin_entry(
        id="repair_app",
        name=tr("entries.repair_app.name", default="修复应用侧集成"),
        description=tr(
            "entries.repair_app.description",
            default="重新把主题 loader 与模板标记装进 N.E.K.O 安装目录（应用更新/删除文件后可手动重跑）。",
        ),
        input_schema={"type": "object", "properties": {}},
    )
    async def repair_app(self, **_):
        result = self._run_app_patch()
        return Ok(result)

    @plugin_entry(
        id="get_theme",
        name=tr("entries.get_theme.name", default="读取当前主题"),
        description=tr(
            "entries.get_theme.description",
            default="返回当前调色板：亮色变量、暗色变量、名称、版本号与启用状态。",
        ),
        input_schema={"type": "object", "properties": {}},
    )
    async def get_theme(self, **_):
        try:
            return Ok(self._read_unlocked())
        except Exception as exc:  # noqa: BLE001
            return Err(SdkError(f"读取主题失败：{exc}"))

    @plugin_entry(
        id="apply_theme",
        name=tr("entries.apply_theme.name", default="应用主题"),
        description=tr(
            "entries.apply_theme.description",
            default="把给定的 CSS 变量合并进当前调色板并原子写入 theme.json，版本号 +1。",
        ),
        input_schema={
            "type": "object",
            "properties": {
                "vars": {"type": "object", "description": "亮色变量表 --nts-* → 值"},
                "dark_vars": {"type": "object", "description": "暗色变量表 --nts-* → 值"},
                "name": {"type": "string", "maxLength": 60},
                "enabled": {"type": "boolean", "default": True},
            },
        },
    )
    async def apply_theme(
        self,
        vars: Any = None,  # noqa: A002 — 名称与契约 input_schema 一致
        dark_vars: Any = None,
        name: Any = None,
        enabled: Any = None,
        **_,
    ):
        try:
            palette, errors = self._apply_and_store(
                vars_in=vars, dark_in=dark_vars, name=name, enabled=enabled
            )
        except Exception as exc:  # noqa: BLE001
            return Err(SdkError(f"写入主题失败：{exc}"))

        if errors:
            # 合法部分已落盘；把被拒绝的条目如实回传给面板展示。
            self._log("warning", f"apply_theme 拒绝 {len(errors)} 条：{errors[:3]}")
            return Ok({**palette, "rejected": errors})
        return Ok(palette)

    @plugin_entry(
        id="reset_theme",
        name=tr("entries.reset_theme.name", default="恢复默认主题"),
        description=tr(
            "entries.reset_theme.description",
            default="把内置默认调色板写回 theme.json（版本号仍会 +1，便于应用侧感知变化）。",
        ),
        input_schema={"type": "object", "properties": {}},
    )
    async def reset_theme(self, **_):
        try:
            with _WRITE_LOCK:
                current = self._read_unlocked()
                palette = default_palette()
                palette["version"] = int(current.get("version", 1)) + 1
                palette["updated_at"] = _now_iso()
                self._write_unlocked(palette)
            return Ok(palette)
        except Exception as exc:  # noqa: BLE001
            return Err(SdkError(f"恢复默认主题失败：{exc}"))

    @plugin_entry(
        id="export_theme",
        name=tr("entries.export_theme.name", default="导出主题"),
        description=tr(
            "entries.export_theme.description",
            default="把当前调色板序列化为 JSON 文本，供用户复制保存或分享。",
        ),
        input_schema={"type": "object", "properties": {}},
    )
    async def export_theme(self, **_):
        try:
            palette = self._read_unlocked()
            payload = json.dumps(palette, ensure_ascii=False, indent=2, sort_keys=False)
            return Ok(
                {
                    "payload": payload,
                    "name": palette["name"],
                    "version": palette["version"],
                    "updated_at": palette["updated_at"],
                }
            )
        except Exception as exc:  # noqa: BLE001
            return Err(SdkError(f"导出主题失败：{exc}"))

    @plugin_entry(
        id="import_theme",
        name=tr("entries.import_theme.name", default="导入主题"),
        description=tr(
            "entries.import_theme.description",
            default="解析并校验一段调色板 JSON 文本，合法后整体应用（非法条目一律丢弃）。",
        ),
        input_schema={
            "type": "object",
            "properties": {
                "payload": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": IMPORT_MAX_CHARS,
                    "description": "调色板 JSON 文本",
                }
            },
            "required": ["payload"],
        },
    )
    async def import_theme(self, payload: str = "", **_):
        if not isinstance(payload, str):
            return Err(SdkError(f"导入内容必须是字符串，收到 {type(payload).__name__}。"))
        text = payload.strip()
        if not text:
            return Err(SdkError("导入内容为空。"))
        if len(text) > IMPORT_MAX_CHARS:
            # input_schema 的 maxLength 只是声明，宿主不一定执行 → 自己兜底。
            return Err(
                SdkError(f"导入内容过长（{len(text)} 字符，上限 {IMPORT_MAX_CHARS}）。")
            )

        try:
            parsed = json.loads(text)
        except (ValueError, TypeError) as exc:
            return Err(SdkError(f"导入内容不是合法 JSON：{exc}"))
        if not isinstance(parsed, dict):
            return Err(SdkError("导入内容必须是一个 JSON 对象。"))

        payload_vars = parsed.get("vars")
        payload_dark = parsed.get("dark_vars")
        if not isinstance(payload_vars, dict) and not isinstance(payload_dark, dict):
            return Err(SdkError("导入内容缺少 vars / dark_vars 字段。"))

        # 导入是「整体替换」而非合并：先清空再写入合法子集。
        try:
            with _WRITE_LOCK:
                palette = self._read_unlocked()
                clean_vars, clean_dark, errors = _validate_palette(payload_vars, payload_dark)

                palette["vars"] = clean_vars
                palette["dark_vars"] = clean_dark

                name = parsed.get("name")
                if isinstance(name, str) and name.strip():
                    palette["name"] = name.strip()[:60]
                if isinstance(parsed.get("enabled"), bool):
                    palette["enabled"] = bool(parsed["enabled"])

                palette["version"] = int(palette.get("version", 1)) + 1
                palette["updated_at"] = _now_iso()
                palette["schema"] = SCHEMA_VERSION

                self._write_unlocked(palette)
        except Exception as exc:  # noqa: BLE001
            return Err(SdkError(f"导入主题失败：{exc}"))

        if errors:
            self._log("warning", f"import_theme 拒绝 {len(errors)} 条：{errors[:3]}")
            return Ok({**palette, "rejected": errors})
        return Ok(palette)
