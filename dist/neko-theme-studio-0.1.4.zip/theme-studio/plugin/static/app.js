/**
 * 主题工坊面板脚本（静态面板，无构建步骤、无框架）
 *
 * 与后端通信的方式完全照搬 wechat_integration/static/script.js：
 *   1. GET  /security/csrf-token            → 拿 CSRF token
 *   2. POST /runs {plugin_id, entry_id, args} → 拿 run_id
 *   3. GET  /runs/{run_id}   每 500ms 轮询   → 直到 succeeded
 *   4. GET  /runs/{run_id}/export            → 取真正的返回值
 *
 * 相对路径可用，因为本页面就是从 48916 端口被服务的（面板 iframe 与 /runs 同源）。
 */

/* ============================================================================
 * 1. 变量目录 —— THEME_CONTRACT.md §3 的权威清单
 * ==========================================================================*/

var CATALOG = [
  {
    group: '聊天气泡',
    items: [
      { key: '--nts-user-bubble-bg', label: '用户气泡背景', type: 'color', native: '#44b7fe' },
      { key: '--nts-user-bubble-text', label: '用户气泡文字', type: 'color', native: '#ffffff' },
      { key: '--nts-user-bubble-border', label: '用户气泡描边', type: 'color', native: 'transparent' },
      { key: '--nts-ai-bubble-bg', label: 'AI 气泡背景', type: 'color', native: '#ffffff', darkNative: 'rgba(42,123,196,0.18)' },
      { key: '--nts-ai-bubble-text', label: 'AI 气泡文字', type: 'color', native: '#24445a', darkNative: '#e0e0e0' },
      { key: '--nts-ai-bubble-border', label: 'AI 气泡描边', type: 'color', native: 'transparent' },
      {
        key: '--nts-code-bg', label: '代码块背景', type: 'color',
        native: 'rgba(91, 111, 145, 0.12)', darkNative: 'rgba(100, 120, 160, 0.18)',
        hint: '行内代码与代码块的底色（.message-markdown-inline-code / .message-markdown-pre）；代码块本体原生没有底色，只有行内代码有；留空即保持原生配色'
      },
      {
        key: '--nts-code-text', label: '代码块文字', type: 'color',
        native: '#22324d', darkNative: '#c0cce0',
        hint: '行内代码与代码块的文字色；原生行内代码 #22324d、代码块 #1f2c42（暗色两者都是 #c0cce0）；留空即保持原生配色'
      },
      {
        key: '--nts-image-bg', label: '图片块背景', type: 'color',
        native: 'transparent', darkNative: 'transparent',
        hint: '消息里图片包裹层 .message-block-image 的底色，垫在图片下方；留空即保持原生（透明，只有图片本身透明或加载失败时才看得见）'
      },
      {
        key: '--nts-tool-bubble-bg', label: '工具/系统气泡背景', type: 'color',
        native: 'linear-gradient(180deg, #f8fafc, #edf2f8)', darkNative: 'linear-gradient(180deg, #232330, #1e1e2a)',
        hint: '工具气泡与系统气泡共用的底色（.message-bubble-tool / .message-bubble-system）；原生工具气泡是渐变、系统气泡是半透明灰（亮 rgba(131,148,175,0.14) / 暗 rgba(80,90,110,0.2)），填写后两者会被拉平成同一个纯色；留空即保持原生'
      },
      {
        key: '--nts-tool-bubble-text', label: '工具/系统气泡文字', type: 'color',
        native: '#2b3a50', darkNative: '#b8bcc4',
        hint: '工具气泡与系统气泡的文字色；原生工具 #2b3a50、系统 #607086（暗色 #b8bcc4 / #9aa0ac）；留空即保持原生配色'
      },
      {
        key: '--nts-status-bg', label: '状态块背景', type: 'color',
        native: 'rgba(70, 129, 227, 0.12)', darkNative: 'rgba(68, 130, 230, 0.15)',
        hint: '消息状态块的底色（.message-block-status 的 info / success / warning / error 四种 tone 共用这一个变量）；原生四种 tone 各不相同（亮 success rgba(48,161,100,0.12)、warning rgba(235,168,52,0.16)、error rgba(223,91,91,0.14)），填写后四种 tone 会被拉平成同一个颜色；留空即保持原生'
      },
      {
        key: '--nts-status-text', label: '状态块文字', type: 'color',
        native: '#28589d', darkNative: '#6fa8ff',
        hint: '消息状态块的文字色（四种 tone 共用这一个变量）；原生四种 tone 各不相同（亮 success #236845、warning #9a6008、error #a63a3a；暗色 #5ec790 / #e8b44a / #e07070），填写后四种 tone 会被拉平成同一个颜色；留空即保持原生'
      }
    ]
  },
  {
    group: '聊天窗口',
    items: [
      { key: '--nts-chat-bg', label: '聊天窗口背景', type: 'color', native: 'transparent',
        hint: '紧凑胶囊形态下那条胶囊的底色由它决定（背板不再抢它）。展开后还影响 #react-chat-window-root 与 .chat-window。留空即保持原生' },
      { key: '--nts-chat-panel-bg', label: '聊天背板背景', type: 'color', native: 'transparent',
        hint: '消息列表背后那块底板的颜色：紧凑态涂 .compact-export-history-scroll，展开/全屏态涂 .message-list 与 .chat-body。留空即保持原生（透明）' },
      {
        key: '--nts-chat-panel-radius', label: '聊天背板圆角', type: 'length', native: '0px',
        hint: '消息列表那块底板的圆角，与「聊天背板背景」配套。用的是独立变量——「通用圆角」会连带改圆按钮和输入框，这里只圆背板。留空即保持原生直角'
      },
      { key: '--nts-topbar-bg', label: '顶栏背景', type: 'color', native: 'transparent' },
      { key: '--nts-topbar-text', label: '顶栏文字', type: 'color', native: 'inherit' },
      {
        key: '--nts-chat-blur', label: '毛玻璃模糊', type: 'blur', native: 'blur(18px)',
        hint: 'CSS 消费方是 backdrop-filter，因此必须写成 blur(18px) 形式；只填 18px 后端会自动补成 blur(18px)；单位只接受 px/rem/em/pt（不支持 % / vh / vw）'
      },
      {
        key: '--nts-chat-opacity', label: '聊天面不透明度', type: 'number', native: '1',
        hint: '取值 0-1。走桥接写成 --neko-chat-opacity-factor —— N.E.K.O 自带的透明度乘子：它乘的是各聊天表面底色的 alpha（原生写法形如 rgba(255,255,255,calc(.91 * 该系数))），所以是整体缩放聊天面板/窗口的透明度，不改任何单个颜色。留空即保持原生（系数 1 = 100%）。注意此项曾因应用侧加载器没有 number 值类型而静默丢弃、面板却报成功，现已修复'
      }
    ]
  },
  {
    group: '输入区',
    items: [
      { key: '--nts-input-bg', label: '输入区背景', type: 'color', native: 'rgba(40, 40, 40, 0.65)', darkNative: 'rgba(40,40,40,0.65)' },
      { key: '--nts-input-text', label: '输入文字', type: 'color', native: 'inherit', darkNative: '#e0e0e0' },
      { key: '--nts-input-border', label: '输入区描边', type: 'color', native: 'rgba(255, 255, 255, 0.06)', darkNative: 'rgba(255,255,255,0.06)' },
      { key: '--nts-input-placeholder', label: '占位文字', type: 'color', native: '#9aa7b2', darkNative: '#999999' },
      { key: '--nts-button-bg', label: '工具按钮背景', type: 'color', native: 'transparent', darkNative: '#2d2d2d' },
      { key: '--nts-button-text', label: '工具按钮文字', type: 'color', native: 'inherit' },
      { key: '--nts-button-hover-bg', label: '工具按钮悬停', type: 'color', native: '#44b7fe1a', darkNative: '#44b7fe26', hint: '只在鼠标悬停工具按钮时生效（.composer-tool-btn:hover），不影响按钮静止态（那由「工具按钮背景」管）；留空即保持原生悬停色（亮 #44b7fe1a / 暗 #44b7fe26）' },
      { key: '--nts-send-bg', label: '发送按钮背景', type: 'color', native: '#44b7fe', darkNative: '#2a7bc4' },
      { key: '--nts-send-text', label: '发送按钮文字', type: 'color', native: '#ffffff', darkNative: '#ffffff' }
    ]
  },
  {
    group: '面板 / 弹窗 / 菜单',
    items: [
      {
        key: '--nts-panel-bg', label: '面板背景', type: 'color', native: 'transparent',
        hint: '作用于输入区面板（.composer-panel）与悬浮任务面板（#agent-task-hud）；紧凑胶囊态下面板本身被应用压成透明，此时看「聊天背景」'
      },
      {
        key: '--nts-panel-text', label: '面板文字', type: 'color', native: '#333333', darkNative: '#e0e0e0',
        hint: '作用于悬浮任务面板、访问条等面板面的文字；输入框里的文字请用「输入文字」。紧凑胶囊的文字颜色不跟这里走（避免改面板文字时连胶囊文字一起变色）'
      },
      { key: '--nts-panel-border', label: '面板描边', type: 'color', native: 'rgba(0, 0, 0, 0.08)', darkNative: 'rgba(255,255,255,0.1)' },
      { key: '--nts-popover-bg', label: '弹出菜单背景', type: 'color', native: 'transparent' },
      { key: '--nts-popover-text', label: '弹出菜单文字', type: 'color', native: 'inherit' },
      { key: '--nts-popover-border', label: '弹出菜单描边', type: 'color', native: 'transparent' },
      { key: '--nts-modal-bg', label: '弹窗背景', type: 'color', native: '#ffffff', darkNative: '#2d2d2d' },
      { key: '--nts-modal-text', label: '弹窗文字', type: 'color', native: '#24445a', darkNative: '#e0e0e0' },
      {
        key: '--nts-accent-bg', label: '插件页强调底纹', type: 'color',
        native: 'rgba(42, 123, 196, 0.05)', darkNative: 'rgba(58, 159, 216, 0.1)',
        hint: '走桥接：写 #agent-plugin-content / #agent-plugin-views 上的 --neko-popup-accent-bg，即插件面板标签页的悬停底色与选中底色（#agent-content-tabs button:hover / [aria-selected="true"]）；留空即保持原生（面板自身兜底亮 rgba(42,123,196,.08) / 选中 .10，模式变量亮 rgba(42,123,196,0.05) / 暗 rgba(58,159,216,0.1)）'
      },
      {
        key: '--nts-panel-text-sub', label: '面板次级文字', type: 'color',
        native: '#666666', darkNative: '#b0b0b0',
        hint: '走桥接：写 #agent-plugin-content / #agent-plugin-views 上的 --neko-popup-text-sub，消费方是插件面板顶部的标签页文字与关闭按钮（#agent-content-tabs button / #agent-plugin-close）；留空即保持原生（面板自身还有一层兜底 #667582，亮 #666666 / 暗 #b0b0b0）'
      },
      {
        key: '--nts-overlay-bg', label: '弹窗遮罩背景', type: 'color',
        native: 'transparent', darkNative: 'rgba(0, 0, 0, 0.65)',
        hint: '弹窗背后的整屏遮罩 .modal-overlay 底色；原生亮色模式基本不铺遮罩（常见组件给的 rgba(0,0,0,0.5) 只在个别弹窗生效），暗色是 rgba(0,0,0,0.65)；小剧场/串门这两类透明窗弹窗自带 transparent !important，不受此项影响；留空即保持原生'
      }
    ]
  },
  {
    group: '推荐 / 系统 chip',
    items: [
      { key: '--nts-rec-bg', label: '推荐条背景', type: 'color', native: 'transparent' },
      { key: '--nts-rec-text', label: '推荐条文字', type: 'color', native: 'inherit' },
      { key: '--nts-rec-border', label: '推荐条描边', type: 'color', native: 'rgba(108, 151, 174, 0.18)', darkNative: 'rgb(65, 84, 95)', hint: '只在 .proactive-recommendation-card 上生效；留空即保持原生描边（亮 rgba(108,151,174,0.18) / 暗 rgb(65,84,95)）' },
      { key: '--nts-chip-bg', label: 'chip 背景', type: 'color', native: 'transparent' },
      { key: '--nts-chip-text', label: 'chip 文字', type: 'color', native: 'inherit' }
    ]
  },
  {
    group: '全局',
    items: [
      { key: '--nts-accent', label: '主色调', type: 'color', native: '#2a7bc4' },
      { key: '--nts-link', label: '链接色', type: 'color', native: '#2a7bc4' },
      { key: '--nts-highlight', label: '选中高亮', type: 'color', native: 'rgba(68, 183, 254, 0.35)', darkNative: 'rgba(74,163,223,0.4)' },
      { key: '--nts-scrollbar-thumb', label: '滚动条滑块', type: 'color', native: 'rgba(0, 0, 0, 0.25)', darkNative: 'rgba(255,255,255,0.2)' },
      { key: '--nts-scrollbar-track', label: '滚动条轨道', type: 'color', native: 'transparent' }
    ]
  },
  {
    group: '非颜色项',
    items: [
      {
        key: '--nts-radius', label: '通用圆角（按钮/输入面板）', type: 'length', native: '8px',
        hint: '原生值各组件不同（顶栏 0 / 卡片 12px / 按钮 10px），留空即完全保持原生'
      },
      {
        key: '--nts-bubble-radius', label: '聊天气泡圆角', type: 'length', native: '16px',
        hint: '只影响气泡本体；留空即保持原生（用户气泡 16px/8px 不对称圆角）'
      },
      {
        key: '--nts-shell-radius', label: '聊天窗外壳圆角', type: 'length', native: '14px',
        hint: '只影响聊天窗口外壳 #react-chat-window-shell；留空即保持原生'
      },
      {
        key: '--nts-card-radius', label: '插件卡片圆角', type: 'length', native: '0px',
        hint: '只影响 .agent-plugin-view 卡片；留空即保持原生'
      },
      {
        key: '--nts-modal-radius', label: '弹窗圆角', type: 'length', native: '0px',
        hint: '只影响 .modal-dialog 对话框；留空即保持原生'
      },
      {
        key: '--nts-popover-radius', label: '浮层圆角', type: 'length', native: '12px',
        hint: '只影响 .composer-overflow-popover 等弹出层；留空即保持原生'
      },
      {
        key: '--nts-rec-radius', label: '推荐卡圆角', type: 'length', native: '18px',
        hint: '只影响推荐类气泡卡片；留空即保持原生'
      },
      { key: '--nts-font-family', label: '字体族', type: 'font', native: 'inherit' },
      {
        key: '--nts-font-size', label: '基础字号', type: 'length', native: '0.94rem',
        hint: '消息正文的字号，纯文本与 Markdown 两种消息都会跟着变（如 1rem / 17px）；留空即保持原生'
      },
      {
        key: '--nts-shadow', label: '阴影', type: 'shadow', native: '',
        hint: '如 0 2px 4px rgba(0,0,0,0.1)；作用在 7 个卡片面上（用户/AI 气泡、输入面板、两个浮层、弹窗、推荐卡），会整体替换这些面原有的阴影；留空即保持原生阴影'
      }
    ]
  }
];

var CATALOG_BY_KEY = {};
CATALOG.forEach(function (group) {
  group.items.forEach(function (item) { CATALOG_BY_KEY[item.key] = item; });
});

/** 行首的类型标签：告诉用户这一行接受什么形态的值。 */
var TYPE_LABEL = {
  color: '色',
  length: '尺寸',
  blur: '模糊',
  number: '数值',
  font: '字体',
  shadow: '阴影'
};

/* ============================================================================
 * 2. 客户端校验镜像（与后端 __init__.py 的规则保持一致，仅用于即时反馈；
 *    真正的安全边界永远是后端）
 * ==========================================================================*/

var RE_HEX = /^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i;
var RE_RGB = /^rgba?\(\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*,\s*[0-9]{1,3}\s*(,\s*(0|1|0?\.[0-9]+)\s*)?\)$/i;
var RE_HSL = /^hsla?\(\s*-?[0-9]{1,3}(\.[0-9]+)?\s*,\s*[0-9]{1,3}(\.[0-9]+)?%\s*,\s*[0-9]{1,3}(\.[0-9]+)?%\s*(,\s*(0|1|0?\.[0-9]+)\s*)?\)$/i;
var RE_LENGTH = /^-?[0-9]{1,4}(\.[0-9]+)?(px|rem|em|%|pt|vh|vw)$/i;
var RE_PERCENT = /^[0-9]{1,3}(\.[0-9]+)?%$/;
var RE_BLUR = /^blur\(\s*-?[0-9]{1,4}(\.[0-9]+)?(px|rem|em|pt)\s*\)$/i;
/* 模糊允许裸长度（后端会把 18px 补成 blur(18px)），但单位只认 px/rem/em/pt：
 * % / vh / vw 会被后端归一成 blur(18%) 这样的非法 CSS，loader 静默丢弃。 */
var RE_BLUR_LENGTH = /^-?[0-9]{1,4}(\.[0-9]+)?(px|rem|em|pt)$/i;
var RE_NUMBER = /^(0|1|0?\.[0-9]+)$/;
var RE_ZERO = /^0$/;
var RE_FONT = /^[A-Za-z0-9\u4e00-\u9fff ,'"\-_.]{1,200}$/;
var RE_FORBIDDEN = /[;{}<>\\]|@import|url\s*\(/i;
var RE_INSET = /^inset$/i;

/** 与后端 _shadow_tokens 同构：按「括号外空白」切分；括号不配对 → []。 */
function shadowTokens(value) {
  var tokens = [], depth = 0, buf = '';
  for (var i = 0; i < value.length; i += 1) {
    var ch = value[i];
    if (ch === '(') depth += 1;
    else if (ch === ')') { depth -= 1; if (depth < 0) return []; }
    if (/\s/.test(ch) && depth === 0) {
      if (buf) { tokens.push(buf); buf = ''; }
      continue;
    }
    buf += ch;
  }
  if (buf) tokens.push(buf);
  if (depth !== 0) return [];
  return tokens;
}

/**
 * box-shadow 的结构校验。只做「token 白名单」是不够的：浏览器对 box-shadow 的
 * 语法要求是 <inset>? && <length>{2,4} && <color>?，而百分比在 box-shadow 里
 * 不是合法长度。旧实现放行 '0 0 10% #000' / '1px' / '1px 2px 3px 4px 5px'，
 * 面板显示已应用，浏览器却把整条声明丢掉 —— 与「改了设置但外观不变」完全一样。
 * 三处校验（面板 / loader / 后端）必须给出同一判定，见 THEME_CONTRACT §9.10b。
 */
function isSafeShadow(value) {
  var tokens = shadowTokens(value);
  if (!tokens.length || tokens.length > 6) return false; // inset + 4 长度 + 颜色
  var lengths = 0;
  var colors = 0;
  var insets = 0;
  for (var i = 0; i < tokens.length; i += 1) {
    var t = tokens[i];
    if (RE_INSET.test(t)) {
      if (++insets > 1) return false;
      continue;
    }
    if (t.toLowerCase() === 'transparent' || RE_HEX.test(t) || RE_RGB.test(t) || RE_HSL.test(t)) {
      if (++colors > 1) return false;
      continue;
    }
    // 百分比不是 box-shadow 的合法长度（50% 会被浏览器整条丢弃）
    if (RE_PERCENT.test(t) || t.indexOf('%') !== -1) return false;
    if (RE_LENGTH.test(t) || RE_ZERO.test(t)) {
      lengths += 1;
      if (lengths > 4) return false;
      // 负值只有前两个长度（x/y 偏移）合法；模糊半径与扩散半径不能为负
      if (t.charAt(0) === '-' && lengths > 2) return false;
      continue;
    }
    return false;
  }
  return lengths >= 2;
}

/** 与后端 __init__.py 的 _is_safe_value 逐条对齐；仅作即时反馈，安全边界在后端。 */
function isSafeValue(key, value) {
  if (typeof value !== 'string') return false;
  var v = value.trim();
  if (!v || v.length > 200) return false;
  if (RE_FORBIDDEN.test(v)) return false;
  var item = CATALOG_BY_KEY[key];
  var type = item ? item.type : 'color';
  if (type === 'color') {
    return RE_HEX.test(v) || RE_RGB.test(v) || RE_HSL.test(v) || v.toLowerCase() === 'transparent';
  }
  // 负长度/负半径在 CSS 里一律非法（整条声明被丢弃 → 面板报成功、外观不变），
  // 后端 _is_safe_value 对 length/blur 单独拦 "-"；这里镜像同一条规则。
  // （shadow 的偏移量要负号，走的是 isSafeShadow 的 token 分支，不受影响。）
  if (type === 'length') {
    if (v.indexOf('-') !== -1) return false;
    return RE_LENGTH.test(v) || RE_PERCENT.test(v) || RE_ZERO.test(v);
  }
  if (type === 'blur') {
    if (v.indexOf('-') !== -1) return false;
    // 只接受 px/rem/em/pt（可写 blur(18px) 或裸 18px，后端会把裸长度补成 blur()）。
    // 旧实现直接用 RE_LENGTH（含 % / vh / vw）：18% 能通过面板校验，后端归一成
    // blur(18%) 非法 CSS 被 loader 丢弃 —— 「应用成功但外观不变」的根因之一。
    return RE_BLUR.test(v) || RE_BLUR_LENGTH.test(v) || RE_ZERO.test(v);
  }
  if (type === 'number') {
    // 百分比只接受 0–100（--nts-chat-opacity 是 0–1 乘子，999% 这类写法对应用无意义，后端会静默丢弃）
    if (RE_PERCENT.test(v)) return parseFloat(v) <= 100;
    return RE_NUMBER.test(v);
  }
  if (type === 'font') return RE_FONT.test(v);
  if (type === 'shadow') return isSafeShadow(v);
  return false;
}

/* ============================================================================
 * 3. 颜色工具
 * ==========================================================================*/

function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }

function hslToRgb(h, s, l) {
  h = ((h % 360) + 360) % 360 / 360;
  s = clamp(s, 0, 100) / 100;
  l = clamp(l, 0, 100) / 100;
  if (s === 0) { var g = Math.round(l * 255); return [g, g, g]; }
  var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  var p = 2 * l - q;
  function hue(t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  }
  return [
    Math.round(hue(h + 1 / 3) * 255),
    Math.round(hue(h) * 255),
    Math.round(hue(h - 1 / 3) * 255)
  ];
}

/** 解析一个 CSS 颜色 → {r,g,b,a}；无法解析返回 null。 */
function parseColor(input) {
  if (typeof input !== 'string') return null;
  var v = input.trim();
  if (!v) return null;
  if (v.toLowerCase() === 'transparent') return { r: 0, g: 0, b: 0, a: 0 };

  var m = v.match(/^#([0-9a-f]{3,8})$/i);
  if (m) {
    var h = m[1];
    if (h.length === 3) {
      return {
        r: parseInt(h[0] + h[0], 16), g: parseInt(h[1] + h[1], 16), b: parseInt(h[2] + h[2], 16), a: 1
      };
    }
    if (h.length === 4) {
      // #RGBA：每个 nibble 复制成双位，alpha = 末位 / 15（等价 0x尾尾 / 255）
      return {
        r: parseInt(h[0] + h[0], 16), g: parseInt(h[1] + h[1], 16), b: parseInt(h[2] + h[2], 16),
        a: parseInt(h[3] + h[3], 16) / 255
      };
    }
    if (h.length === 6) {
      return {
        r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 1
      };
    }
    if (h.length === 8) {
      return {
        r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16),
        a: parseInt(h.slice(6, 8), 16) / 255
      };
    }
    return null;
  }

  m = v.match(/^rgba?\(([^)]*)\)$/i);
  if (m) {
    var parts = m[1].split(',').map(function (s) { return s.trim(); });
    if (parts.length < 3) return null;
    var r = parseInt(parts[0], 10), g = parseInt(parts[1], 10), b = parseInt(parts[2], 10);
    var a = parts.length > 3 ? parseFloat(parts[3]) : 1;
    if ([r, g, b].some(function (n) { return !isFinite(n); })) return null;
    return { r: clamp(r, 0, 255), g: clamp(g, 0, 255), b: clamp(b, 0, 255), a: isFinite(a) ? clamp(a, 0, 1) : 1 };
  }

  m = v.match(/^hsla?\(([^)]*)\)$/i);
  if (m) {
    var hp = m[1].split(',').map(function (s) { return s.trim(); });
    if (hp.length < 3) return null;
    var rgb = hslToRgb(parseFloat(hp[0]), parseFloat(hp[1]), parseFloat(hp[2]));
    var al = hp.length > 3 ? parseFloat(hp[3]) : 1;
    return { r: rgb[0], g: rgb[1], b: rgb[2], a: isFinite(al) ? clamp(al, 0, 1) : 1 };
  }

  return null;
}

function toHex(r, g, b) {
  function h(n) { var s = clamp(Math.round(n), 0, 255).toString(16); return s.length === 1 ? '0' + s : s; }
  return '#' + h(r) + h(g) + h(b);
}

function toRgba(r, g, b, a) {
  var alpha = Math.round(clamp(a, 0, 1) * 100) / 100;
  return 'rgba(' + clamp(Math.round(r), 0, 255) + ',' + clamp(Math.round(g), 0, 255) + ',' + clamp(Math.round(b), 0, 255) + ',' + alpha + ')';
}

/* ============================================================================
 * 4. 插件调用（照搬 wechat_integration/static/script.js 的约定）
 * ==========================================================================*/

var PLUGIN_ID = 'neko_theme_studio';
var RUNS_URL = '/runs';
/* 与 plugin/__init__.py 的 DEFAULT_THEME_NAME、index.html 主题名 placeholder 三处一致。
 * v0.1.4 起后端把空串/纯空白 name 视为「恢复默认名」并返回默认名，不再报错；
 * 面板仍显式提交这个默认名，语义相同且不依赖后端实现。 */
var DEFAULT_THEME_NAME = '默认';
var POLL_DELAY_MS = 500;
var CSRF_BOOTSTRAP_TIMEOUT_MS = 5000;
var CSRF_BOOTSTRAP_RETRY_TIMEOUT_MS = 30000;
var CALL_DEADLINE_MS = 25000;
/* 单次请求超时。旧实现只有 CSRF 引导步有 AbortController，POST / 轮询 / 导出
 * 都没有超时：插件服务半死时请求永远不返回，面板一直转圈、按钮永久禁用。 */
var POST_TIMEOUT_MS = 30000;
var POLL_TIMEOUT_MS = 5000;
var EXPORT_TIMEOUT_MS = 15000;
/* 轮询连续失败多少次就放弃。旧实现把 4xx/5xx 当暂时错误重试到 25s 超时，
 * 再命中 looksLikePluginDown 触发自愈重试，最坏 ~51s 锁死。 */
var POLL_MAX_FAILURES = 3;

var csrfTokenPromise = null;

function delay(ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); }

/**
 * 带超时的 fetch。超时抛出的错误带 timeout=true，供上层区分「超时」与「HTTP 失败」。
 * 手写 AbortController 而不是 AbortSignal.timeout：后者在旧版 Electron/Chrome 里
 * 不一定存在，而这个静态面板没有构建步骤、无法做 polyfill。
 */
function fetchWithTimeout(url, options, timeoutMs) {
  var opts = options || {};
  var controller = new AbortController();
  var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
  opts.signal = controller.signal;
  return fetch(url, opts).catch(function (error) {
    if (error && error.name === 'AbortError') {
      var timeoutError = new Error('请求超时（' + Math.round(timeoutMs / 1000) + 's）');
      timeoutError.timeout = true;
      throw timeoutError;
    }
    throw error;
  }).finally(function () { clearTimeout(timer); });
}

async function mutationHeaders(timeoutMs) {
  if (!csrfTokenPromise) {
    var bootstrapAbort = new AbortController();
    var bootstrapTimer = setTimeout(function () { bootstrapAbort.abort(); }, timeoutMs);
    csrfTokenPromise = fetch('/security/csrf-token', { credentials: 'same-origin', signal: bootstrapAbort.signal })
      .then(function (response) {
        if (!response.ok) throw new Error('CSRF token bootstrap failed: HTTP ' + response.status);
        return response.json();
      })
      .then(function (data) {
        if (!data || typeof data.csrf_token !== 'string' || !data.csrf_token) {
          throw new Error('CSRF token bootstrap returned an invalid token');
        }
        return data.csrf_token;
      })
      .finally(function () { clearTimeout(bootstrapTimer); });
  }
  var pending = csrfTokenPromise;
  var waitTimer;
  try {
    var token = await Promise.race([
      pending,
      new Promise(function (resolve) { waitTimer = setTimeout(function () { resolve(null); }, timeoutMs); })
    ]);
    if (token) return { 'X-CSRF-Token': token };
    console.warn('CSRF token not ready; sending without it');
    return {};
  } catch (error) {
    if (csrfTokenPromise === pending) csrfTokenPromise = null;
    console.warn('CSRF token unavailable; sending without it:', error);
    return {};
  } finally {
    clearTimeout(waitTimer);
  }
}

async function isCsrfTokenFailure(response) {
  if (response.headers.get('X-CSRF-Failure') === 'token') return true;
  try {
    var data = await response.clone().json();
    return Boolean(data && data.detail && data.detail.csrf_failure === 'token');
  } catch (error) {
    return false;
  }
}

async function postWithCsrfRetry(url, body) {
  for (var attempt = 0; ; attempt += 1) {
    var response = await fetchWithTimeout(url, {
      method: 'POST',
      headers: Object.assign(
        { 'Content-Type': 'application/json' },
        await mutationHeaders(attempt === 0 ? CSRF_BOOTSTRAP_TIMEOUT_MS : CSRF_BOOTSTRAP_RETRY_TIMEOUT_MS)
      ),
      body: body
    }, POST_TIMEOUT_MS);
    if (attempt > 0 || response.status !== 403 || !(await isCsrfTokenFailure(response))) return response;
    csrfTokenPromise = null;
  }
}

/* 宿主的错误包装：entry 里 return Err(SdkError("导入内容为空。")) 时，宿主会把它包成
 *   Plugin 'neko_theme_studio' entry 'entry import_theme' execution failed:
 *   Plugin 'neko_theme_studio' entry 'import_theme' execution failed: 导入内容为空。
 * 有时还会套两层。原样显示给用户就是一句看不懂的内部报错，所以把外壳剥掉，
 * 只留插件自己写的中文原因；剥完仍是空串时退回原文本，绝不吞掉错误。 */
var HOST_ERROR_WRAPPER = /execution failed:\s*/g;

function stripHostErrorWrapper(text) {
  var msg = String(text == null ? '' : text);
  var cut = -1;
  var m;
  HOST_ERROR_WRAPPER.lastIndex = 0;
  while ((m = HOST_ERROR_WRAPPER.exec(msg)) !== null) cut = m.index + m[0].length;
  if (cut > 0) msg = msg.slice(cut);
  return msg.trim() || String(text == null ? '' : text).trim();
}

function pluginErrorMessage(error) {
  if (!error) return '';
  if (typeof error === 'string') return stripHostErrorWrapper(error);
  if (typeof error.message === 'string') return stripHostErrorWrapper(error.message);
  if (typeof error.detail === 'string') return stripHostErrorWrapper(error.detail);
  if (typeof error.code === 'string') return error.code;
  return '';
}

/* 自愈：插件进程没在跑时，面板自己把它拉起来再重试一次。
 * 面板本身就跑在 48916 上（同源），/plugins/refresh 与 /plugin/<id>/start 都是
 * 现成的端点，缺的只是 CSRF 令牌 —— 复用 mutationHeaders 即可。
 * 实测背景：应用冷启动后插件可能停在 stopped（用户插件总开关默认关），
 * 此时面板能打开但每次调用都失败，用户看到的就是「面板改了颜色但窗口不变」。 */
var reviveInFlight = null;

function revivePlugin() {
  if (reviveInFlight) return reviveInFlight;
  reviveInFlight = (async function () {
    // 旧实现只 await 不看 response.ok：403 / 500 也当成功，且错误全被吞掉，
    // 用户最终只看到一句「调用超时」，不知道插件根本没被拉起来。
    state.lastReviveError = '';
    var errors = [];
    try {
      var refreshResp = await postWithCsrfRetry('/plugins/refresh', '{}');
      if (!refreshResp.ok) errors.push('/plugins/refresh 返回 HTTP ' + refreshResp.status);
    } catch (error) {
      errors.push('刷新插件列表失败：' + pluginErrorMessage(error));
    }
    try {
      var startResp = await postWithCsrfRetry('/plugin/' + PLUGIN_ID + '/start', '{}');
      if (!startResp.ok) errors.push('/plugin/' + PLUGIN_ID + '/start 返回 HTTP ' + startResp.status);
    } catch (error) {
      errors.push('启动插件失败：' + pluginErrorMessage(error));
    }
    state.lastReviveError = errors.join('；');
    await delay(900);
  })();
  var done = function () { reviveInFlight = null; };
  reviveInFlight.then(done, done);
  return reviveInFlight;
}

/** 只有「插件没起来」这一类失败才值得自愈，参数错误重试没有意义。 */
function looksLikePluginDown(error) {
  var msg = pluginErrorMessage(error) || '';
  if (/^HTTP 5/.test(msg)) return true;
  if (/^HTTP 404/.test(msg)) return true;
  if (msg.indexOf('超时') !== -1) return true;
  return /not found|not running|no such plugin|插件未运行|未启动/i.test(msg);
}

/** 调用一个插件 entry，失败且像是插件没起来时，自愈一次再重试。
 *
 * 自愈只针对「创建 run」这一步失败（error.phase === 'post'）：轮询/导出失败说明
 * 插件已经接单、只是慢或服务端状态异常，重跑整轮不会更快，只会把 25s 超时
 * 拖成 ~51s（旧实现实测到过的锁死）。超时同样不重试 —— 再等一轮只是更久。 */
async function callPlugin(entryId, args) {
  try {
    return await callPluginOnce(entryId, args);
  } catch (error) {
    if (!error || error.phase !== 'post' || error.timeout || !looksLikePluginDown(error)) throw error;
    await revivePlugin();
    try {
      return await callPluginOnce(entryId, args);
    } catch (retryError) {
      // 自愈失败必须把状态码/原因带到最终错误文案里，否则用户只看到「应用失败」。
      var reason = pluginErrorMessage(retryError) || '调用失败';
      var reviveReason = state.lastReviveError || '原因未知';
      throw new Error(reason + '\n插件未运行，自动启动失败：' + reviveReason);
    }
  }
}
/** 调用一个插件 entry，返回其 JSON 结果（单次，不做自愈）。 */
async function callPluginOnce(entryId, args) {
  var resp;
  try {
    resp = await postWithCsrfRetry(
      RUNS_URL,
      JSON.stringify({ plugin_id: PLUGIN_ID, entry_id: entryId, args: args || {} })
    );
  } catch (error) {
    if (error && !error.phase) error.phase = 'post';
    throw error;
  }
  if (!resp.ok) {
    var httpError = new Error('HTTP ' + resp.status);
    httpError.phase = 'post';
    httpError.status = resp.status;
    throw httpError;
  }
  var ids = await resp.json();
  var runId = ids.run_id || ids.id;
  if (!runId) throw new Error('未获取到 run_id');

  var deadline = Date.now() + CALL_DEADLINE_MS;
  var pollFailures = 0;
  while (Date.now() < deadline) {
    var poll;
    try {
      poll = await fetchWithTimeout(RUNS_URL + '/' + runId, {}, POLL_TIMEOUT_MS);
    } catch (pollError) {
      if (pollError && !pollError.phase) pollError.phase = 'poll';
      throw pollError;
    }
    if (!poll.ok) {
      // 404 = run 记录不存在，继续轮询只是白等；其它非 2xx 连续 N 次也立即失败。
      if (poll.status === 404) {
        var notFoundError = new Error('HTTP 404（run 记录不存在）');
        notFoundError.phase = 'poll';
        notFoundError.status = 404;
        throw notFoundError;
      }
      pollFailures += 1;
      if (pollFailures >= POLL_MAX_FAILURES) {
        var pollHttpError = new Error('HTTP ' + poll.status);
        pollHttpError.phase = 'poll';
        pollHttpError.status = poll.status;
        throw pollHttpError;
      }
      await delay(POLL_DELAY_MS);
      continue;
    }
    pollFailures = 0;
    var rec = await poll.json();
    if (rec.status === 'succeeded') {
      var exp;
      try {
        exp = await fetchWithTimeout(RUNS_URL + '/' + runId + '/export', {}, EXPORT_TIMEOUT_MS);
      } catch (exportError) {
        if (exportError && !exportError.phase) exportError.phase = 'export';
        throw exportError;
      }
      if (!exp.ok) {
        var exportHttpError = new Error('导出结果失败：HTTP ' + exp.status);
        exportHttpError.phase = 'export';
        exportHttpError.status = exp.status;
        throw exportHttpError;
      }
      var payload = await exp.json();
      var items = payload.items || [];
      var item = items.find(function (i) { return i.type === 'json' && i.json; }) || items[0];
      if (!item) throw new Error('导出结果为空（没有 type=json 的条目）');
      var raw = item.json || {};
      // 剥掉 {success, code, data} 包装层。判据必须落在**当前对象自己**身上：
      // 运行结果的外层是 {"success":true,"data":{...调色板...}}，而内层的调色板
      // 自身并没有 success/error 字段。若把判据写成 raw.data.success（即检查内层），
      // 循环永不执行，调用方拿到的是包装层 —— palette.version 变 undefined、
      // palette.vars 变 undefined，面板会显示「版本 undefined」且所有颜色都被当成
      // 未设置（实测到过的真 bug）。
      while (raw && raw.data && typeof raw.data === 'object' && ('success' in raw || 'error' in raw)) {
        raw = raw.data;
      }
      if (raw && raw.error) throw new Error(pluginErrorMessage(raw.error) || '插件调用失败');
      return raw;
    }
    if (['failed', 'canceled', 'timeout'].indexOf(rec.status) !== -1) {
      throw new Error((rec.error && rec.error.message) || rec.message || rec.status);
    }
    await delay(POLL_DELAY_MS);
  }
  var deadlineError = new Error('调用超时');
  deadlineError.phase = 'poll';
  deadlineError.timeout = true;
  throw deadlineError;
}

/* ============================================================================
 * 5. 状态
 * ==========================================================================*/

var state = {
  mode: 'light',            // 'light' | 'dark' —— 编辑 vars 还是 dark_vars
  palette: null,            // 服务器上的调色板（唯一真相）
  edited: { light: {}, dark: {} },  // 用户真正改过的键 → 值
  cleared: { light: {}, dark: {} }, // 用户点了「清空」的键 → true（提交空串 = 删除）
  collapsed: {},
  filter: '',               // 搜索框里的过滤词（小写比较）
  onlyDirty: false,         // 只看改动：隐藏未改动的行
  busy: false,
  modalMode: 'import',
  modalReturnFocus: null,
  // 名称 / 启用的「已保存基线」：由 renderMeta 写入，applyTheme 用它判断有没有改动。
  // 初值等于 index.html 的 DOM 初值，所以首次 get_theme 失败（palette=null）时
  // 只改名称或启用开关也能被识别成有效改动。
  metaName: '',
  metaEnabled: true,
  // 自愈（revivePlugin）失败原因，拼进最终错误提示里。
  lastReviveError: ''
};

function editedMap() { return state.edited[state.mode]; }
function clearedMap() { return state.cleared[state.mode]; }

function isDirty(key) {
  return Object.prototype.hasOwnProperty.call(editedMap(), key) ||
    Object.prototype.hasOwnProperty.call(clearedMap(), key);
}

function dirtyCount() {
  var light = Object.keys(state.edited.light).length + Object.keys(state.cleared.light).length;
  var dark = Object.keys(state.edited.dark).length + Object.keys(state.cleared.dark).length;
  return light + dark;
}

/** 该行在当前模式下「显示」的值：改过就用改的值，否则用原生参考值。 */
function displayValue(key) {
  if (Object.prototype.hasOwnProperty.call(editedMap(), key)) return editedMap()[key];
  if (Object.prototype.hasOwnProperty.call(clearedMap(), key)) return '';
  var server = serverValue(key);
  if (server !== null) return server;
  if (state.mode === 'dark') {
    var item = CATALOG_BY_KEY[key];
    if (item && item.darkNative !== undefined) return item.darkNative;
  }
  return '';
}

/** 服务器调色板里该键的值（当前模式），没有则 null。 */
function serverValue(key) {
  if (!state.palette) return null;
  var bag = state.mode === 'dark' ? state.palette.dark_vars : state.palette.vars;
  if (bag && Object.prototype.hasOwnProperty.call(bag, key)) return bag[key];
  return null;
}

/** 提交时该键的取值：改过 → 值；清空 → ''（删除）；没碰过 → undefined（不发）。 */
function submitValue(key) {
  if (Object.prototype.hasOwnProperty.call(editedMap(), key)) return editedMap()[key];
  if (Object.prototype.hasOwnProperty.call(clearedMap(), key)) return '';
  return undefined;
}

function markEdited(key, value) {
  // 记住「上一个通过校验的编辑值」：非颜色行输入非法时要回滚到它，
  // 否则应用仍会提交上一个合法值并报成功（用户以为新输入生效了）。
  rowValidCache[key] = value;
  delete clearedMap()[key];
  // 改回服务器上已有的值 = 没改：否则把值敲回去后按钮仍显示「已改」，
  // 应用时还会把同值再写一遍（版本号 +1，用户以为哪里坏了）。
  if (serverValue(key) === value) {
    delete editedMap()[key];
    return;
  }
  editedMap()[key] = value;
}

function markCleared(key) {
  delete editedMap()[key];
  delete rowValidCache[key];
  markRowInvalid(key, false);
  clearedMap()[key] = true;
}

/**
 * 「清空」的语义是「删掉 theme.json 里的这一项」。若服务器本来就没有这一项，
 * 清空应当退化成「撤销本地编辑」而不是记一条空串提交（否则干净的行点一下清空
 * 就凭空多出一项改动，应用后版本号变化但外观不变）。
 * @returns {boolean} true = 真的提交了删除
 */
function clearRow(key) {
  var hasServer = serverValue(key) !== null;
  if (!hasServer) {
    delete editedMap()[key];
    delete clearedMap()[key];
    delete rowValidCache[key];
    markRowInvalid(key, false);
    return false;
  }
  markCleared(key);
  return true;
}

/* ---------------- 行级「非法输入」与「颜色记忆」 ----------------
 * 1) invalidRows：哪几行当前是红框非法态。applyTheme 见到非 0 就阻止应用，
 *    避免「输入非法 → 应用仍提交上一个合法值并报成功」。
 * 2) rowValidCache：每行上一次通过校验的编辑值；输入非法时把 edited 回滚到它
 *    （没有就删除该键 = 回退服务器值），使面板状态与将提交的内容一致。
 * 3) lastRgbByKey：全透明行记住最近一次的 RGB，让 alpha 滑块在 transparent
 *    状态下仍然可用（旧实现一置灰，用户就再也拖不回半透明）。 */
var rowValidCache = {};
var invalidRows = {};
var lastRgbByKey = {};

function markRowInvalid(key, bad) {
  if (bad) invalidRows[key] = true;
  else delete invalidRows[key];
}

function invalidRowCount() { return Object.keys(invalidRows).length; }

function invalidInputHint(item) {
  if (item && item.type === 'blur') return '模糊只接受 px/rem/em/pt（可写 18px 或 blur(18px)）';
  return '该值不合法，请改成合法值或点「清空」';
}

/** 非法输入时回滚到上一个合法编辑值；没有就删掉本地编辑（退回服务器值）。 */
function rollbackRowToLastValid(key) {
  if (Object.prototype.hasOwnProperty.call(rowValidCache, key)) {
    markEdited(key, rowValidCache[key]);
  } else {
    delete editedMap()[key];
  }
}

function markAllRowsValid() { invalidRows = {}; }

function clearRgbMemory() { lastRgbByKey = {}; }

/** 记住一行最近一次带颜色成分的 RGB（transparent 字面量没有颜色信息，跳过）。 */
function rememberRgbValue(key, parsed, raw) {
  if (!parsed) return;
  if (String(raw || '').trim().toLowerCase() === 'transparent') return;
  if (parsed.a > 0 || parsed.r || parsed.g || parsed.b) {
    lastRgbByKey[key] = { r: parsed.r, g: parsed.g, b: parsed.b };
  }
}

/** 统一设置输入框的红框 / 无障碍非法标记 / 提示标题。 */
function setInputInvalid(input, item, bad) {
  if (!input) return;
  input.classList.toggle('is-bad', !!bad);
  if (bad) {
    input.setAttribute('aria-invalid', 'true');
    input.title = invalidInputHint(item);
  } else {
    input.removeAttribute('aria-invalid');
    input.title = '';
  }
}

/* ============================================================================
 * 6. DOM 帮手
 * ==========================================================================*/

function el(tag, props, children) {
  var node = document.createElement(tag);
  if (props) {
    Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (v === null || v === undefined) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'style') node.setAttribute('style', v);
      else if (k.indexOf('on') === 0 && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    });
  }
  (children || []).forEach(function (c) { if (c) node.appendChild(c); });
  return node;
}

function $(id) { return document.getElementById(id); }

/** kind: 'ok' | 'error' | 空 —— 只影响配色，不影响文案。 */
function showToast(message, kind) {
  var node = $('toast');
  node.textContent = message;
  node.classList.toggle('is-ok', kind === 'ok');
  node.classList.toggle('is-error', kind === 'error');
  node.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(function () { node.classList.remove('show'); }, 3000);
}

/** kind: 'idle' | 'busy' | 'ok' | 'error' | 'warn' —— 底部状态点配色。 */
function setStatus(text, kind) {
  var node = $('status');
  if (!node) return;
  node.textContent = text;
  node.dataset.kind = kind || 'idle';
}

/** kind: 'ok' | 'warn' | 'error' —— 左侧色条与配色。传空文案即收起。 */
function showNotice(kind, text) {
  var node = $('notice');
  if (!node) return;
  if (!text) {
    node.hidden = true;
    node.className = 'notice';
    var body = $('notice-text');
    if (body) body.textContent = '';
    return;
  }
  node.className = 'notice is-' + kind;
  var target = $('notice-text') || node;
  target.textContent = text;
  node.hidden = false;
}

function hideNotice() { showNotice('ok', ''); }

/** 顶部细进度条：读取/应用期间给一个非阻塞的「在忙」信号。 */
function setLoading(loading) {
  document.body.classList.toggle('is-loading', !!loading);
}

/* ============================================================================
 * 7. 渲染编辑器
 * ==========================================================================*/

var rowsByKey = {};   // key → { hexInput, colorInput, alpha, alphaVal, textInput, rowEl, syncFn }

var groupNodes = {};   // group 名 → <section class="group">

function buildEditor() {
  var host = $('groups');
  host.textContent = '';

  CATALOG.forEach(function (group) {
    var key = group.group;
    var body = el('div', { class: 'group-body' });
    var count = el('span', { class: 'group-count' });
    var head = el('div', {
      class: 'group-head',
      role: 'button',
      tabindex: '0',
      'aria-expanded': state.collapsed[key] ? 'false' : 'true',
      'aria-label': key + ' 分组（点击展开/收起）',
      onclick: function () { toggleGroup(key); },
      onkeydown: function (event) {
        if (event.key === 'Enter' || event.key === ' ' || event.key === 'Spacebar') {
          event.preventDefault();
          toggleGroup(key);
        }
      }
    }, [
      el('span', { class: 'group-caret', 'aria-hidden': 'true', text: '▶' }),
      el('span', { class: 'group-title', text: key }),
      count
    ]);
    var wrap = el('section', { class: 'group' + (state.collapsed[key] ? ' is-collapsed' : '') }, [head, body]);
    groupNodes[key] = wrap;

    group.items.forEach(function (item) { body.appendChild(buildRow(item, count)); });

    host.appendChild(wrap);
  });

  refreshCounts();
  updateGroupToggleLabel();
}

function toggleGroup(key) {
  state.collapsed[key] = !state.collapsed[key];
  var node = groupNodes[key];
  if (!node) return;
  node.classList.toggle('is-collapsed', !!state.collapsed[key]);
  var head = node.querySelector('.group-head');
  if (head) head.setAttribute('aria-expanded', state.collapsed[key] ? 'false' : 'true');
  updateGroupToggleLabel();
}

function allCollapsed() {
  return CATALOG.every(function (group) { return !!state.collapsed[group.group]; });
}

function updateGroupToggleLabel() {
  var btn = $('btn-toggle-groups');
  if (btn) btn.textContent = allCollapsed() ? '全部展开' : '全部收起';
}

function toggleAllGroups() {
  var collapse = !allCollapsed();
  CATALOG.forEach(function (group) {
    state.collapsed[group.group] = collapse;
    var node = groupNodes[group.group];
    if (!node) return;
    node.classList.toggle('is-collapsed', collapse);
    var head = node.querySelector('.group-head');
    if (head) head.setAttribute('aria-expanded', collapse ? 'false' : 'true');
  });
  updateGroupToggleLabel();
}

/** 当前模式下的「原生参考值」：暗色优先 darkNative，没有就退回亮色原生值。 */
function nativeOf(item) {
  if (state.mode === 'dark' && item.darkNative !== undefined) return item.darkNative;
  return item.native || '';
}

/** placeholder 展示原生参考值；太长的不塞进输入框，免得像噪声。 */
function placeholderFor(item) {
  var native = nativeOf(item);
  if (native && native.length <= 28) return '原生 ' + native;
  return '留空 = 原生';
}

function buildRow(item, countNode) {
  var isColor = item.type === 'color';

  var stateTag = el('span', { class: 'row-state' });
  var label = el('div', { class: 'row-label', title: item.key }, [
    el('span', { class: 'label-line' }, [
      el('span', { class: 'label-main', text: item.label }),
      stateTag
    ]),
    el('span', { class: 'k', text: item.key })
  ]);

  var colorInput = null;
  var hexInput = null;
  var alpha = null;
  var alphaVal = null;
  var textInput = null;
  var nativeCell = null;

  if (isColor) {
    colorInput = el('input', {
      type: 'color', class: 'swatch', value: '#000000',
      'aria-label': item.label + ' 色板'
    });
    hexInput = el('input', {
      type: 'text',
      class: 'hex',
      spellcheck: 'false',
      autocomplete: 'off',
      placeholder: placeholderFor(item),
      'aria-label': item.label + ' 颜色值',
      oninput: function () {
        var raw = hexInput.value.trim();
        if (!raw) { clearRow(item.key); setInputInvalid(hexInput, item, false); syncRow(item.key, { keepHex: true }); return; }
        var parsed = parseColor(raw);
        if (!parsed) { setInputInvalid(hexInput, item, true); markRowInvalid(item.key, true); return; }
        setInputInvalid(hexInput, item, false);
        markRowInvalid(item.key, false);
        // 只有 6/3 位 hex 没有自己的 alpha，才继承当前值的 alpha；transparent、
        // 4/8 位 hex、rgba(...) 一律用解析出的 alpha。旧实现一律走 currentAlpha()，
        // 而 currentAlpha 对全透明返回 1 → 输入 "transparent" 的过程中被记成
        // rgba(0,0,0,1) 纯黑，Ctrl+Enter（不要求失焦）直接写盘。
        var isPlainHex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(raw);
        var alphaOut = isPlainHex ? currentAlpha(item.key) : parsed.a;
        rememberRgbValue(item.key, parsed, raw);
        markEdited(item.key, toRgba(parsed.r, parsed.g, parsed.b, alphaOut));
        // keepHex：输入框保留用户正在敲的原文，否则 "#ff8" 会被当成 3 位色改写，
        // 后续按键拼出用户没输入过的值（实测 #ff8800 → #ffff8880）。
        syncRow(item.key, { keepHex: true });
      },
      onchange: function () {
        // 失焦/回车才算定稿：只有此时才从 4/8 位 hex 里取 alpha 并归一化展示。
        // 逐键过程中保持原有 alpha，否则 6 位色 "#ff8800" 的 4 位前缀 "#ff88"
        // 会被当成 53% 透明的 4 位色，把用户输入的实色变成半透明。
        var raw = hexInput.value.trim();
        if (!raw) return;
        var parsed = parseColor(raw);
        if (!parsed) { setInputInvalid(hexInput, item, true); markRowInvalid(item.key, true); return; }
        setInputInvalid(hexInput, item, false);
        markRowInvalid(item.key, false);
        rememberRgbValue(item.key, parsed, raw);
        markEdited(item.key, toRgba(parsed.r, parsed.g, parsed.b, parsed.a));
        syncRow(item.key);
      }
    });

    alpha = el('input', {
      type: 'range', min: '0', max: '100', step: '1', value: '100',
      'aria-label': item.label + ' 不透明度',
      oninput: function () {
        var a = Number(alpha.value) / 100;
        var parsed = parseColor(displayValue(item.key));
        // 不是靠猜颜色：全透明行若记得上一次的 RGB（lastRgbByKey），就沿用它
        // 把不透明度拖回来 —— 旧实现此时滑块 disabled、currentAlpha 强制 1，
        // 用户再也调不回半透明。只有完全没有 RGB 记忆时才不猜（否则纯黑）。
        var rgb = parsed && parsed.a > 0 ? parsed : lastRgbByKey[item.key];
        if (!rgb) { syncRow(item.key); return; }
        rememberRgbValue(item.key, rgb, '');
        markEdited(item.key, toRgba(rgb.r, rgb.g, rgb.b, a));
        syncRow(item.key);
      }
    });
    alphaVal = el('span', { class: 'alpha-val', text: '100%' });

    colorInput.addEventListener('input', function () {
      var parsed = parseColor(colorInput.value);
      if (!parsed) return;
      rememberRgbValue(item.key, parsed, '#');
      markEdited(item.key, toRgba(parsed.r, parsed.g, parsed.b, currentAlpha(item.key)));
      syncRow(item.key);
    });
  } else {
    textInput = el('input', {
      type: 'text',
      class: 'raw',
      spellcheck: 'false',
      autocomplete: 'off',
      placeholder: placeholderFor(item),
      'aria-label': item.label,
      oninput: function () {
        // 注意：这里不能对 value 做 trim 后再回写。多 token 的值（阴影、字体族）
        // 是逐个字符敲出来的，行尾空格一被 trim 掉，下一个 token 就会粘在前一个
        // 上 —— 实测 "0 2px 4px red" 被录成 "02px4px red"，"Segoe UI" 变成
        // "SegoeUI"。所以：校验用 trim 后的值，显示保留用户原文。
        var raw = textInput.value;
        var trimmed = raw.trim();
        if (!trimmed) { clearRow(item.key); setInputInvalid(textInput, item, false); syncRow(item.key, { keepText: true }); return; }
        if (!isSafeValue(item.key, trimmed)) {
          // 非法值只标红还不够：之前 edited 里仍留着上一个合法值，applyTheme
          // 会把它提交上去并报「已应用」，用户以为刚敲的值生效了。
          // 这里回滚到上一个合法编辑值（没有就退回服务器值）并记入非法行集合，
          // applyTheme 见到红框行会直接阻止应用。
          setInputInvalid(textInput, item, true);
          markRowInvalid(item.key, true);
          rollbackRowToLastValid(item.key);
          syncRow(item.key, { keepText: true });
          return;
        }
        setInputInvalid(textInput, item, false);
        markRowInvalid(item.key, false);
        markEdited(item.key, trimmed);
        syncRow(item.key, { keepText: true });
      },
      onchange: function () {
        // 失焦/回车时定稿：去掉首尾空白，再做一次完整校验。
        var trimmed = textInput.value.trim();
        textInput.value = trimmed;
        if (!trimmed) { clearRow(item.key); setInputInvalid(textInput, item, false); syncRow(item.key); return; }
        if (!isSafeValue(item.key, trimmed)) {
          setInputInvalid(textInput, item, true);
          markRowInvalid(item.key, true);
          rollbackRowToLastValid(item.key);
          syncRow(item.key);
          return;
        }
        setInputInvalid(textInput, item, false);
        markRowInvalid(item.key, false);
        markEdited(item.key, trimmed);
        syncRow(item.key);
      }
    });
    nativeCell = el('span', {
      class: 'row-native',
      title: nativeOf(item) ? '原生值：' + nativeOf(item) : '该变量没有统一的原生值',
      text: nativeOf(item) ? '原生 ' + nativeOf(item) : ''
    });
  }

  var field = el('div', { class: 'field' }, [isColor ? hexInput : textInput]);

  var alphaCell = el('div', { class: 'alpha-cell' });
  if (isColor) {
    alphaCell.appendChild(el('span', { class: 'alpha-label', text: '透明' }));
    alphaCell.appendChild(alpha);
    alphaCell.appendChild(alphaVal);
  }

  var clearBtn = el('button', {
    type: 'button', class: 'row-clear', text: '清空',
    title: '清空该行 = 回退到 N.E.K.O 原生值',
    'aria-label': '清空 ' + item.label,
    onclick: function () {
      // 干净且服务器上没有值的行：「清空」无事可做，不能凭空造出一项改动。
      if (!isDirty(item.key) && serverValue(item.key) === null) {
        showToast('该行本来就是原生值');
        return;
      }
      var removed = clearRow(item.key);
      syncRow(item.key);
      if (!removed) showToast('已撤销本行改动');
    }
  });

  // 网格五列：标签 | 色块或类型标签 | 编辑框 | 透明度或原生值 | 清空
  // 非颜色行没有色块，用同宽类型标签占位，保证输入框左边缘对齐。
  var rowEl = el('div', { class: 'row' }, [
    label,
    isColor && colorInput ? colorInput : el('span', { class: 'type-tag', text: TYPE_LABEL[item.type] || item.type }),
    field,
    isColor ? alphaCell : (nativeCell || el('span', {})),
    clearBtn
  ]);

  var hint = null;
  if (item.hint) {
    hint = el('div', { class: 'hint', title: item.hint, text: item.hint });
  }

  var container = el('div', { class: 'row-wrap' }, [rowEl, hint]);
  rowsByKey[item.key] = {
    rowEl: rowEl, colorInput: colorInput, hexInput: hexInput,
    alpha: alpha, alphaVal: alphaVal, textInput: textInput, clearBtn: clearBtn,
    nativeCell: nativeCell, stateTag: stateTag, container: container,
    item: item, countNode: countNode
  };

  countNode.dataset.total = String(Number(countNode.dataset.total || 0) + 1);
  return container;
}

function currentAlpha(key) {
  var raw = Object.prototype.hasOwnProperty.call(editedMap(), key) ? editedMap()[key] : displayValue(key);
  var parsed = parseColor(raw);
  // 当前值全透明（transparent / rgba(...,0)）时不能把 alpha=0 继承给新颜色：
  // 用户从色板选一个实色，提交的却是 rgba(...,0)，面板显示「已改」而画面
  // 依旧完全透明 —— 看起来就是「改了没反应」。色板选色默认按实色处理。
  // 注意：alpha 滑块不走这里，它用 lastRgbByKey 里记住的 RGB 调不透明度。
  if (!parsed || parsed.a === 0) return 1;
  return parsed.a;
}

/** 把某一行的控件同步成当前状态。opts.keepHex=true 时不动正在编辑的 hex 输入框。 */
function syncRow(key, opts) {
  var ref = rowsByKey[key];
  if (!ref) return;
  var value = displayValue(key);
  var dirty = isDirty(key);

  ref.rowEl.classList.toggle('is-dirty', dirty);

  if (ref.stateTag) {
    var cleared = Object.prototype.hasOwnProperty.call(clearedMap(), key);
    ref.stateTag.textContent = dirty ? (cleared ? '已清空' : '已改') : '';
  }

  if (ref.hexInput) ref.hexInput.placeholder = placeholderFor(ref.item);
  if (ref.textInput) ref.textInput.placeholder = placeholderFor(ref.item);
  if (ref.nativeCell) {
    var native = nativeOf(ref.item);
    ref.nativeCell.textContent = native ? '原生 ' + native : '';
    ref.nativeCell.title = native ? '原生值：' + native : '该变量没有统一的原生值';
  }

  if (ref.item.type === 'color') {
    var parsed = parseColor(value);
    var fullyTransparent = !!parsed && parsed.a === 0;
    if (parsed) {
      // 记住最近一次带颜色的 RGB：transparent 之后拖动 alpha 滑块要靠它找回颜色。
      // rememberRgbValue 内部会跳过 transparent / rgba(...,0) 字面量。
      rememberRgbValue(key, parsed, value);
      // 全透明的 rgba(...,0) / #0000 若按 RGB 显示成 #000000，用户会以为颜色
      // 被改成了黑色；这里显式显示 transparent，和 alpha=0% 一起表达真实状态。
      if (!(opts && opts.keepHex)) {
        ref.hexInput.value = fullyTransparent ? 'transparent' : toHex(parsed.r, parsed.g, parsed.b);
      }
      ref.colorInput.value = toHex(parsed.r, parsed.g, parsed.b);
      ref.alpha.value = String(Math.round(parsed.a * 100));
      ref.alphaVal.textContent = Math.round(parsed.a * 100) + '%';
      setInputInvalid(ref.hexInput, ref.item, false);
      markRowInvalid(key, false);
    } else {
      // 值是 inherit / 空 等非颜色字面量：文本原样展示，控件退回中性
      // 色块也要跟着退，否则清空/重置后色块仍显示上一次的颜色，看起来像没生效。
      ref.hexInput.value = value || '';
      if (ref.colorInput) ref.colorInput.value = '#000000';
      ref.alpha.value = '100';
      ref.alphaVal.textContent = '100%';
    }
    // transparent / inherit / 空 都没有当前 RGB：滑块只在「有 RGB 记忆」时可用
    // （拖动会沿用上一次的颜色，见 lastRgbByKey）。完全没记忆时置灰，否则拖动
    // 会得到 rgba(0,0,0,x) 纯黑半透明，用户看到的是「一拖就变黑」。
    if (ref.alpha) {
      var hasRgbMemory = !!lastRgbByKey[key];
      ref.alpha.disabled = !!state.busy || !parsed || (fullyTransparent && !hasRgbMemory);
      if (!parsed) {
        ref.alpha.title = '当前值没有颜色成分（transparent / inherit / 空）；先填一个颜色再调不透明度';
      } else if (fullyTransparent && !hasRgbMemory) {
        ref.alpha.title = '当前值没有颜色成分（transparent）；先填一个颜色再调不透明度';
      } else if (fullyTransparent) {
        ref.alpha.title = '拖动不透明度会沿用上一次的颜色';
      } else {
        ref.alpha.title = '';
      }
    }
  } else {
    if (!(opts && opts.keepText)) {
      ref.textInput.value = value || '';
      // 回显的是当前有效值，红框/非法行标记必须一起清掉；
      // 否则「清空」或撤销后红框还留着，applyTheme 会一直被非法行拦住。
      setInputInvalid(ref.textInput, ref.item, false);
      markRowInvalid(key, false);
    }
  }

  refreshCounts();
  renderPreview();
  renderDump();
  updateButtons();
  // 「只看改动」开着时，某行被改回干净状态就该立刻从列表里消失
  if (state.onlyDirty) applyFilters();
}

function syncAll() {
  Object.keys(rowsByKey).forEach(syncRow);
  refreshCounts();
  renderPreview();
  renderDump();
  updateButtons();
}

function refreshCounts() {
  CATALOG.forEach(function (group) {
    var total = group.items.length;
    var dirty = group.items.filter(function (item) { return isDirtyAny(item.key); }).length;
    // 找到该组的计数节点：通过任意一行的 countNode
    var node = rowsByKey[group.items[0].key] && rowsByKey[group.items[0].key].countNode;
    if (!node) return;
    node.textContent = '';
    if (dirty) {
      node.appendChild(el('span', { class: 'is-dirty-count', text: dirty + ' 项已改' }));
      node.appendChild(el('span', { class: 'dot', text: '·' }));
    }
    node.appendChild(el('span', { text: total + ' 项' }));
  });
}

/* ---------------- 过滤：搜索 / 只看改动 ---------------- */

/** 该键在任一模式（亮/暗）里是否被改过或清空过。 */
function isDirtyAny(key) {
  return Object.prototype.hasOwnProperty.call(state.edited.light, key) ||
    Object.prototype.hasOwnProperty.call(state.edited.dark, key) ||
    Object.prototype.hasOwnProperty.call(state.cleared.light, key) ||
    Object.prototype.hasOwnProperty.call(state.cleared.dark, key);
}

function rowMatches(item, query) {
  if (state.onlyDirty && !isDirtyAny(item.key)) return false;
  if (!query) return true;
  var hay = (item.label + ' ' + item.key + ' ' + (item.hint || '')).toLowerCase();
  return hay.indexOf(query) !== -1;
}

/**
 * 把「搜索词 + 只看改动」应用到行与分组上：
 * - 行级：row-wrap[hidden]
 * - 组级：没有命中行的组整体隐藏
 * - 过滤时强制展开，否则命中项藏在折叠组里等于没找到
 */
function applyFilters() {
  var query = (state.filter || '').trim().toLowerCase();
  var filtering = !!query || state.onlyDirty;
  var shown = 0;

  CATALOG.forEach(function (group) {
    var section = groupNodes[group.group];
    var visible = 0;
    group.items.forEach(function (item) {
      var ref = rowsByKey[item.key];
      if (!ref) return;
      var match = rowMatches(item, query);
      if (ref.container) ref.container.hidden = !match;
      if (match) { visible += 1; shown += 1; }
    });
    if (section) {
      section.hidden = visible === 0;
      section.classList.toggle('is-collapsed', !filtering && !!state.collapsed[group.group]);
      var head = section.querySelector('.group-head');
      if (head) head.setAttribute('aria-expanded', section.classList.contains('is-collapsed') ? 'false' : 'true');
    }
  });

  var noMatch = $('no-match');
  if (noMatch) noMatch.hidden = !(filtering && shown === 0);

  var clear = $('search-clear');
  if (clear) clear.hidden = !query;
}

function setFilter(value) {
  state.filter = value || '';
  applyFilters();
}

function clearFilter() {
  var input = $('row-search');
  if (input) input.value = '';
  state.filter = '';
  applyFilters();
  if (input) input.focus();
}

function setOnlyDirty(on) {
  state.onlyDirty = !!on;
  applyFilters();
}

/* ============================================================================
 * 8. 预览（内联样式，纯本地模拟）
 * ==========================================================================*/

function pvValue(key, fallback) {
  var v = displayValue(key);
  if (!v) return fallback || '';
  if (v.indexOf('--') === 0) return fallback || '';
  return v;
}

function renderPreview() {
  $('preview-mode').textContent = state.mode === 'dark' ? '暗色' : '亮色';

  var chatBg = pvValue('--nts-chat-bg', state.mode === 'dark' ? '#1f242a' : '#eef3f8');
  var panelBg = pvValue('--nts-chat-panel-bg', '');
  var radius = pvValue('--nts-radius', '12px');
  // 预览必须按真实消费方取圆角：外壳读 --nts-shell-radius、气泡读
  // --nts-bubble-radius，都没配时才回退通用 --nts-radius。之前全部读通用值，
  // 于是改「聊天气泡圆角」预览纹丝不动，看起来像没生效。
  var shellRadius = pvValue('--nts-shell-radius', radius);
  var bubbleRadius = pvValue('--nts-bubble-radius', radius);
  var blur = pvValue('--nts-chat-blur', '');
  // 契约允许裸长度（"18px"），真正落盘前 loader/后端会归一成 blur(18px)。
  // 预览直接拿裸长度写 backdropFilter 是非法值，浏览器整条丢弃 —— 于是
  // 明明改了模糊，预览却毫无反应（真机上更会被误判成主题没生效）。
  // 但拼接前必须确认单位合法：blur(18%) / blur(2vw) 同样是非法值，
  // 旧实现会无条件拼上去，等于把「面板校验放过的非法输入」带进预览。
  var blurCss = '';
  if (blur) {
    if (RE_BLUR.test(blur)) blurCss = blur;
    else if (RE_BLUR_LENGTH.test(blur)) blurCss = 'blur(' + blur + ')';
    else if (RE_ZERO.test(blur)) blurCss = 'blur(0)';
  }

  var preview = $('preview');
  preview.style.background = chatBg;
  preview.style.borderRadius = shellRadius;
  if (panelBg) preview.style.backgroundColor = panelBg;
  preview.style.backdropFilter = blurCss;
  preview.style.webkitBackdropFilter = blurCss;
  preview.style.boxShadow = pvValue('--nts-shadow', '');

  // 背板（消息列表底板）在预览里对应 .pv-body。圆角必须单独取
  // --nts-chat-panel-radius：它和「通用圆角」是两个不同消费方，读错了
  // 就会出现「改了背板圆角，预览里动的却是按钮」这种假象。
  var panelRadius = pvValue('--nts-chat-panel-radius', '');
  liveStyle($('pv-body'), {
    background: 'transparent',
    borderRadius: panelRadius || '0px'
  });

  var fontFamily = pvValue('--nts-font-family', '');
  var fontSize = pvValue('--nts-font-size', '');
  preview.style.fontFamily = fontFamily || '';
  if (fontSize) preview.style.fontSize = fontSize;

  liveStyle($('pv-topbar'), {
    background: pvValue('--nts-topbar-bg', 'transparent'),
    color: pvValue('--nts-topbar-text', state.mode === 'dark' ? '#e0e0e0' : '#24445a')
  });

  styleBubble($('pv-user'), {
    background: pvValue('--nts-user-bubble-bg', '#44b7fe'),
    color: pvValue('--nts-user-bubble-text', '#ffffff'),
    borderColor: pvValue('--nts-user-bubble-border', 'transparent'),
    radius: bubbleRadius,
    align: 'flex-end'
  });

  styleBubble($('pv-ai'), {
    background: pvValue('--nts-ai-bubble-bg', state.mode === 'dark' ? 'rgba(42,123,196,0.18)' : '#ffffff'),
    color: pvValue('--nts-ai-bubble-text', state.mode === 'dark' ? '#e0e0e0' : '#24445a'),
    borderColor: pvValue('--nts-ai-bubble-border', 'transparent'),
    radius: bubbleRadius,
    align: 'flex-start'
  });

  $('pv-link').style.color = pvValue('--nts-link', '#2a7bc4');

  liveStyle($('pv-chip'), {
    background: pvValue('--nts-chip-bg', 'transparent'),
    color: pvValue('--nts-chip-text', state.mode === 'dark' ? '#e0e0e0' : '#24445a'),
    borderColor: pvValue('--nts-rec-border', 'rgba(0,0,0,0.12)'),
    borderRadius: '999px'
  });

  liveStyle($('pv-input-area'), {
    background: pvValue('--nts-input-bg', state.mode === 'dark' ? 'rgba(40,40,40,0.65)' : 'rgba(255,255,255,0.5)'),
    borderTopColor: pvValue('--nts-input-border', 'rgba(0,0,0,0.06)'),
    blur: blurCss
  });

  liveStyle($('pv-input'), {
    background: pvValue('--nts-input-bg', 'transparent'),
    color: pvValue('--nts-input-text', state.mode === 'dark' ? '#e0e0e0' : '#24445a'),
    borderColor: pvValue('--nts-input-border', 'rgba(0,0,0,0.1)'),
    borderRadius: radius
  });

  liveStyle($('pv-send'), {
    background: pvValue('--nts-send-bg', '#44b7fe'),
    color: pvValue('--nts-send-text', '#ffffff'),
    borderRadius: radius
  });
}

function liveStyle(node, cfg) {
  if (!node) return;
  if (cfg.background !== undefined) node.style.backgroundColor = cfg.background;
  if (cfg.color !== undefined) node.style.color = cfg.color;
  if (cfg.borderColor !== undefined) node.style.borderColor = cfg.borderColor;
  if (cfg.borderTopColor !== undefined) node.style.borderTopColor = cfg.borderTopColor;
  if (cfg.borderRadius !== undefined) node.style.borderRadius = cfg.borderRadius;
  // 用 !== undefined 而不是真值判断：清空 --nts-chat-blur 时要能把上一帧的
  // backdrop-filter 撤掉，否则预览里毛玻璃永远留着，看着像清空没生效。
  if (cfg.blur !== undefined) {
    node.style.backdropFilter = cfg.blur || '';
    node.style.webkitBackdropFilter = cfg.blur || '';
  }
}

function styleBubble(node, cfg) {
  if (!node) return;
  node.style.backgroundColor = cfg.background;
  node.style.color = cfg.color;
  node.style.borderColor = cfg.borderColor;
  node.style.borderStyle = 'solid';
  node.style.borderWidth = '1px';
  node.style.borderRadius = cfg.radius || '12px';
  node.style.alignSelf = cfg.align;
}

/* ============================================================================
 * 9. 调色板 dump / 元信息
 * ==========================================================================*/

function renderDump() {
  var payload = {
    name: $('theme-name') ? $('theme-name').value : undefined,
    enabled: $('theme-enabled').checked,
    vars: effectiveVars('light'),
    dark_vars: effectiveVars('dark')
  };
  var pending = Object.keys(state.edited.light).length + Object.keys(state.edited.dark).length +
    Object.keys(state.cleared.light).length + Object.keys(state.cleared.dark).length;
  // 这里必须是纯 JSON：旧实现把 "// ↑ 含 N 项未应用的改动" 拼在 JSON 末尾，
  // 与右侧 dump 说明（effectiveVars，含未应用改动）不一致，复制出去也不是合法
  // JSON。未应用提示改放 #dump-foot —— 它在 #dump 之外，复制永远拿到合法 JSON。
  $('dump').textContent = JSON.stringify(payload, null, 2);

  var foot = $('dump-foot');
  if (foot) {
    var saved = paletteCounts(state.palette);
    foot.textContent = '已保存：亮色 ' + saved.light + ' 项 / 暗色 ' + saved.dark + ' 项' +
      (pending ? '；另有 ' + pending + ' 项改动尚未应用（上面的 JSON 不含它们）。' : '；没有未应用的改动。');
  }
}

/** 某模式「生效中」的变量：服务器已保存的值叠加本地未应用的改动。
 *
 * 注意不能直接用 collect(mode)：那只包含本次会话里改过/清空过的键，读回一个
 * 已保存的调色板时会渲染成空对象 —— 面板会声称「当前调色板 vars: {}」，
 * 与磁盘上真实的 theme.json 不符，极为误导。
 */
function effectiveVars(mode) {
  var out = {};
  var saved = state.palette
    ? (mode === 'dark' ? state.palette.dark_vars : state.palette.vars)
    : null;
  if (saved) Object.keys(saved).forEach(function (k) { out[k] = saved[k]; });
  Object.keys(state.edited[mode]).forEach(function (k) { out[k] = state.edited[mode][k]; });
  Object.keys(state.cleared[mode]).forEach(function (k) { delete out[k]; });
  return out;
}

function collect(mode) {
  var out = {};
  var edited = state.edited[mode];
  var cleared = state.cleared[mode];
  Object.keys(edited).forEach(function (k) { out[k] = edited[k]; });
  Object.keys(cleared).forEach(function (k) { out[k] = ''; });
  return out;
}

function renderMeta() {
  var p = state.palette;
  if (!p) return;
  // 基线必须在每次读回调色板时刷新：applyTheme 靠它判断名称/启用是否真的变了。
  state.metaName = p.name || '';
  state.metaEnabled = p.enabled !== false;
  $('meta-version').textContent = '版本 ' + p.version;
  $('meta-name').textContent = p.name || '默认';
  var when = p.updated_at ? String(p.updated_at).replace('T', ' ').slice(0, 19) : '—';
  $('meta-updated').textContent = when;
  if (document.getElementById('theme-name') && document.activeElement !== $('theme-name')) {
    $('theme-name').value = p.name || '';
  }
  $('theme-enabled').checked = p.enabled !== false;
}

function updateButtons() {
  var n = dirtyCount();
  var applyBtn = $('btn-apply');
  applyBtn.textContent = n ? '应用（' + n + ' 项改动）' : '应用';
  applyBtn.disabled = state.busy;
  applyBtn.dataset.busy = state.busy ? 'true' : 'false';
  ['btn-reset', 'btn-export', 'btn-import', 'btn-reload', 'btn-revert-mode'].forEach(function (id) {
    var node = $(id);
    if (node) node.disabled = state.busy;
  });
}

/* ============================================================================
 * 10. 动作
 * ==========================================================================*/

function buildArgs(mode) {
  return collect(mode);
}

/** 调色板里两组各有多少项（0 是常见且值得说出来的状态）。 */
function paletteCounts(p) {
  var l = p && p.vars && typeof p.vars === 'object' ? Object.keys(p.vars).length : 0;
  var d = p && p.dark_vars && typeof p.dark_vars === 'object' ? Object.keys(p.dark_vars).length : 0;
  return { light: l, dark: d };
}

/**
 * 只改了一组时的提醒。亮/暗两组是各管各的（THEME_CONTRACT §3.0），
 * 所以「只配了亮色、应用却在暗色模式」= 零效果 —— 这是最容易误判成
 * 「插件坏了」的用法，必须在提示里点出来。
 */
function modeHint(nLight, nDark) {
  if (nLight && !nDark) {
    return '\n注意：本次只改了「亮色」组 —— 应用若正处在暗色模式，外观不会变（两组各管各的）。';
  }
  if (nDark && !nLight) {
    return '\n注意：本次只改了「暗色」组 —— 应用若正处在亮色模式，外观不会变（两组各管各的）。';
  }
  return '';
}

/** 从磁盘读回调色板时的中性文案：不是「本次只改了」，而是「当前只有」。
 * 旧实现直接用 modeHint，刷新/回读时会误报「本次只改了亮色组」。 */
function savedModeHint(nLight, nDark) {
  if (nLight && !nDark) {
    return '\n当前只有「亮色」组有自定义项（暗色模式仍是原生外观）。';
  }
  if (nDark && !nLight) {
    return '\n当前只有「暗色」组有自定义项（亮色模式仍是原生外观）。';
  }
  return '';
}

/**
 * 编辑器底部那行常驻说明：它要回答「为什么我什么都没看到」这个最常见的问题，
 * 所以把「空 = 原生」和「亮暗两组各管各的」直接写在这里，而不是藏在 README。
 */
function renderPaletteHint() {
  var node = $('empty-hint');
  if (!node) return;
  if (!state.palette) {
    node.textContent = '尚未读取到调色板；面板仍可编辑，点「应用」会重试读取。';
    return;
  }
  var c = paletteCounts(state.palette);
  if (!c.light && !c.dark) {
    node.textContent = '当前调色板为空：所有组件都使用 N.E.K.O 原生外观。任意一行填值并应用，即刻生效。';
    return;
  }
  node.textContent = '已保存 ' + (c.light + c.dark) + ' 项（亮色 ' + c.light + ' / 暗色 ' + c.dark +
    '）。留空的行保持原生外观；两组各管各的，只配一组时另一模式不会变。';
}

/** 从后端 rejected 文案里抠出被拒的变量名（后端文案带 '--nts-xxx'）。 */
function rejectedKeysOf(rejected) {
  var keys = {};
  (rejected || []).forEach(function (msg) {
    var found = String(msg).match(/--nts-[a-z0-9-]+/g);
    if (!found) return;
    found.forEach(function (k) { keys[k] = true; });
  });
  return keys;
}

/**
 * 把被拒绝的提交值放回编辑态。后端只拒绝单条，合法部分已落盘，所以这里
 * 不能清空整组改动，否则用户只能凭记忆重新输入被拒的那个值。
 * @returns {number} 恢复的条目数
 */
function restoreRejected(rejected, sentLight, sentDark) {
  var keys = rejectedKeysOf(rejected);
  var restored = 0;
  function restoreBag(sent, edited, cleared) {
    Object.keys(sent).forEach(function (k) {
      if (!keys[k]) return;
      if (sent[k] === '') cleared[k] = true;
      else edited[k] = sent[k];
      restored += 1;
    });
  }
  restoreBag(sentLight, state.edited.light, state.cleared.light);
  restoreBag(sentDark, state.edited.dark, state.cleared.dark);
  if (restored) { syncAll(); applyFilters(); }
  return restored;
}

async function applyTheme() {
  if (state.busy) return;

  // 红框行必须先解决：非法输入时 edited 里留的是「上一个合法值」，直接应用会
  // 把它提交上去并显示成功，用户会以为刚敲的非法值生效了。这里明确阻止。
  if (invalidRowCount()) {
    var nBad = invalidRowCount();
    showNotice('warn', '有 ' + nBad + ' 行输入不合法（红框），已阻止应用。\n' +
      '请把红框里的值改成合法值，或点该行「清空」。');
    showToast('有非法输入，未应用', 'error');
    setStatus('有非法输入，未应用', 'warn');
    return;
  }

  var lightVars = buildArgs('light');
  var darkVars = buildArgs('dark');
  var nLight = Object.keys(lightVars).length;
  var nDark = Object.keys(darkVars).length;
  var enabled = $('theme-enabled').checked;
  // 用 renderMeta 写入的「已保存基线」比较，而不是 !!state.palette：
  // 首次 get_theme 失败（palette=null）时旧实现一律判为没改，只改名称或启用
  // 开关永远提示「没有可应用的改动」，改动根本提交不出去。
  var enabledChanged = state.metaEnabled !== enabled;
  var nameInput = $('theme-name');
  var name = nameInput ? nameInput.value.trim() : '';
  // 只改主题名也是一次有效改动：漏掉它会让 name 永远存不进去（实测点了应用毫无反应）。
  var nameChanged = name !== (state.metaName || '');

  // 没有任何改动时不要假装成功：否则「点了应用但什么都没发生」会被当成插件故障。
  // 提示语写成诊断信息：编辑是逐键实时记录（oninput → markEdited），不需要失焦。
  if (!nLight && !nDark && !enabledChanged && !nameChanged) {
    showNotice('warn', '没有可应用的改动（当前 0 项变量改动，名称/启用未变，也没有红框非法输入）。\n' +
      '改值会在输入时立即记入面板，不必等控件失焦；如果确实改过，可能是刚才用「还原本组」撤销了。');
    showToast('没有改动可应用');
    setStatus('没有改动可应用', 'warn');
    return;
  }

  var args = {
    vars: lightVars,
    dark_vars: darkVars,
    enabled: enabled
  };
  // 名称清空按默认名提交：与后端「空串/纯空白 = 恢复默认名」一致，
  // DEFAULT_THEME_NAME 与后端常量、placeholder 一致。
  if (nameChanged) args.name = name || DEFAULT_THEME_NAME;

  setBusy(true, '正在应用…');
  try {
    var result = await callPlugin('apply_theme', args);
    var rejected = result && result.rejected;
    state.edited = { light: {}, dark: {} };
    state.cleared = { light: {}, dark: {} };
    markAllRowsValid();
    // 写入成功后必须回读，且要检查返回值：silent 失败被吞时面板还停在旧值，
    // 文案却显示「已应用，版本 N」—— 用户看到的和磁盘不一致。
    var reloaded = await reloadPalette({ silent: true });
    if (!reloaded) {
      // 回读失败时用提交值更新基线：否则下次比较基线仍是旧值，
      // 会误判出「又有改动」，或反过来把真实改动判成没改。
      if (nameChanged) state.metaName = name || DEFAULT_THEME_NAME;
      state.metaEnabled = enabled;
    }
    // 被拒条目留在面板上，让用户就地修正（合法部分后端已落盘）
    var restored = rejected && rejected.length ? restoreRejected(rejected, lightVars, darkVars) : 0;
    // 只把真正发生的变化写进文案，避免「0 项」和「主题名已改」被漏报。
    var parts = [];
    if (nLight) parts.push('亮色 ' + nLight + ' 项');
    if (nDark) parts.push('暗色 ' + nDark + ' 项');
    if (enabledChanged) parts.push(enabled ? '已启用主题' : '已停用主题');
    if (nameChanged) parts.push('主题名「' + (name || DEFAULT_THEME_NAME) + '」');
    var counts = parts.length ? parts.join(' / ') : '无变量改动';
    var readbackNote = reloaded ? '' :
      '\n已写入，但回读失败，面板显示可能不是最新值，请点「重新读取」。';
    if (rejected && rejected.length) {
      showNotice('warn', '已应用（' + counts + '），但后端拒绝了 ' + rejected.length +
        ' 条，已把它们的原值放回面板便于就地修正：\n' + rejected.join('\n') + readbackNote);
      showToast('已应用（' + rejected.length + ' 条被拒绝' + (restored ? '，已回填' : '') + '）');
    } else {
      showNotice(reloaded ? 'ok' : 'warn', '已应用并写入 theme.json：' + counts + '，当前版本 ' +
        (result && result.version) + modeHint(nLight, nDark) + readbackNote);
      showToast('已应用 ' + counts, 'ok');
    }
    setStatus('已应用 ' + counts + (restored ? '（' + restored + ' 条待修正）' : '') +
      '，版本 ' + (result && result.version) + (reloaded ? '' : '（回读失败）'),
      reloaded ? 'ok' : 'warn');
  } catch (error) {
    showNotice('error', '应用失败：' + pluginErrorMessage(error));
    showToast('应用失败', 'error');
    setStatus('应用失败', 'error');
  } finally {
    setBusy(false);
  }
}

async function resetTheme() {
  if (state.busy) return;
  if (!window.confirm('确定恢复内置默认主题？当前所有自定义颜色都会被清除。')) return;
  setBusy(true, '正在重置…');
  try {
    var result = await callPlugin('reset_theme', {});
    state.edited = { light: {}, dark: {} };
    state.cleared = { light: {}, dark: {} };
    markAllRowsValid();
    clearRgbMemory();
    var reloaded = await reloadPalette({ silent: true });
    if (reloaded) {
      showNotice('ok', '已恢复默认主题，版本 ' + (result && result.version));
    } else {
      // 重置已落盘，但面板没能回读：提示重新读取，而不是假装一切最新。
      showNotice('warn', '已恢复默认主题，版本 ' + (result && result.version) +
        '\n回读失败，面板显示可能不是最新值，请点「重新读取」。');
    }
    showToast('已重置', 'ok');
    setStatus('已重置' + (reloaded ? '' : '（回读失败）'), reloaded ? 'ok' : 'warn');
  } catch (error) {
    showNotice('error', '重置失败：' + pluginErrorMessage(error));
    showToast('重置失败', 'error');
    setStatus('重置失败', 'error');
  } finally {
    setBusy(false);
  }
}

async function exportTheme() {
  if (state.busy) return;
  // 后端 export_theme 返回的是磁盘上已保存的 theme.json，不含面板里未应用的改动。
  // 与右侧 dump（effectiveVars，含未应用改动）不一致，所以先明确告知再导出。
  var pending = dirtyCount();
  if (pending && !window.confirm('有 ' + pending + ' 项未应用的改动。\n' +
    '导出的 JSON 来自磁盘上已保存的 theme.json（不含这些未应用改动）。继续导出？')) {
    return;
  }
  setBusy(true, '正在导出…');
  try {
    var result = await callPlugin('export_theme', {});
    var hint = pending
      ? '下面是已保存到 theme.json 的调色板 JSON（不含 ' + pending + ' 项未应用改动），可复制保存或分享。'
      : '下面是当前调色板的 JSON 文本，可复制保存或分享。';
    openModal('export', '导出主题', hint, result.payload || '');
    setStatus(pending ? '已导出已保存版本（不含未应用改动）' : '已导出', 'ok');
  } catch (error) {
    showNotice('error', '导出失败：' + pluginErrorMessage(error));
    showToast('导出失败', 'error');
    setStatus('导出失败', 'error');
  } finally {
    setBusy(false);
  }
}

// 与 plugin/__init__.py 的 IMPORT_MAX_CHARS 保持一致。宿主的 input_schema 会在
// entry 被调用之前就按 maxLength 拒绝超长输入，并把错误包成 INTERNAL，用户看到的
// 是一条看不懂的内部报错 —— 所以这里先拦一次，给出人话提示。
var IMPORT_MAX_CHARS = 262144;

function openImport() {
  openModal('import', '导入主题', '粘贴调色板 JSON 文本。导入为整体替换；非法条目会被后端丢弃。', '');
}

async function doImport() {
  var text = $('modal-text').value.trim();
  if (!text) { showToast('请先粘贴内容'); return; }
  if (text.length > IMPORT_MAX_CHARS) {
    var tooLong = '导入内容过长（' + text.length + ' 字符，上限 ' + IMPORT_MAX_CHARS +
      ' 字符）。请删掉不必要的内容后重试。';
    showNotice('error', tooLong);
    showToast('导入失败', 'error');
    setStatus('导入失败：内容过长', 'error');
    openModal('import', '导入主题', tooLong + '\n粘贴内容已保留，可修改后重试。', text);
    return;
  }
  closeModal();
  setBusy(true, '正在导入…');
  try {
    var result = await callPlugin('import_theme', { payload: text });
    state.edited = { light: {}, dark: {} };
    state.cleared = { light: {}, dark: {} };
    markAllRowsValid();
    clearRgbMemory();
    var reloaded = await reloadPalette({ silent: true });
    var readbackNote = reloaded ? '' :
      '\n已写入，但回读失败，面板显示可能不是最新值，请点「重新读取」。';
    var rejected = result && result.rejected;
    if (rejected && rejected.length) {
      showNotice('warn', '已导入，但后端拒绝了 ' + rejected.length + ' 条：\n' + rejected.join('\n') + readbackNote);
      showToast('已导入（部分条目被拒绝）', 'ok');
      setStatus('已导入（' + rejected.length + ' 条被拒绝' + (reloaded ? '' : '，回读失败') + '）', 'warn');
    } else {
      showNotice(reloaded ? 'ok' : 'warn', '已导入并写入 theme.json，版本 ' + (result && result.version) + readbackNote);
      showToast('已导入', 'ok');
      setStatus('已导入' + (reloaded ? '' : '（回读失败）'), reloaded ? 'ok' : 'warn');
    }
  } catch (error) {
    showNotice('error', '导入失败：' + pluginErrorMessage(error));
    showToast('导入失败', 'error');
    setStatus('导入失败', 'error');
    // 失败时调色板没变，把用户粘贴的文本放回弹窗，避免「内容被吞、只能重新粘贴」。
    openModal('import', '导入主题',
      '导入失败：' + pluginErrorMessage(error) + '\n粘贴内容已保留，可修改后重试。', text);
  } finally {
    setBusy(false);
  }
}

function revertMode() {
  var mode = state.mode;
  var n = Object.keys(state.edited[mode]).length + Object.keys(state.cleared[mode]).length;
  if (!n) { showToast('当前' + (mode === 'dark' ? '暗色' : '亮色') + '组没有改动'); return; }
  state.edited[mode] = {};
  state.cleared[mode] = {};
  syncAll();
  showToast('已还原' + (mode === 'dark' ? '暗色' : '亮色') + '组改动', 'ok');
}

async function reloadPalette(options) {
  var silent = options && options.silent;
  setLoading(true);
  try {
    var palette = await callPlugin('get_theme', {});
    state.palette = palette;
    renderMeta();
    renderPaletteHint();
    syncAll();
    applyFilters();
    var c = paletteCounts(palette);
    if (!silent) {
      showNotice('ok', '已读取当前主题：版本 ' + palette.version + '，亮色 ' + c.light +
        ' 项 / 暗色 ' + c.dark + ' 项' + savedModeHint(c.light, c.dark));
      // 状态栏常驻显示两条腿各有多少项，避免「只配了一组」被忽略。
      setStatus('已读取，版本 ' + palette.version + ' · 亮色 ' + c.light + ' / 暗色 ' + c.dark, 'ok');
    }
    return palette;
  } catch (error) {
    if (!silent) {
      showNotice('error', '读取失败：' + pluginErrorMessage(error) + '\n（后端插件可能未启动；面板仍可编辑，点击「应用」会重试。）');
      setStatus('读取失败', 'error');
    }
    // 读取失败也不能让面板变成空白：用当前编辑状态继续渲染。
    renderPaletteHint();
    syncAll();
    return null;
  } finally {
    setLoading(false);
  }
}

/** busy 期间锁住行内控件：否则飞行中的编辑会在成功后随 state.edited 清空而静默丢失。 */
function setRowControlsDisabled(busy) {
  Object.keys(rowsByKey).forEach(function (key) {
    var ref = rowsByKey[key];
    ['hexInput', 'colorInput', 'alpha', 'textInput', 'clearBtn'].forEach(function (name) {
      if (ref[name]) ref[name].disabled = !!busy;
    });
    // 解锁时不能把 alpha 一律启用：transparent / inherit / 空 的行必须继续置灰，
    // 否则应用一次之后滑块又能拖出纯黑半透明（旧实现只在 syncRow 里设 disabled，
    // 被这里一次性覆盖掉）。但若有 RGB 记忆（拖过颜色/选过色），transparent
    // 也要保持可用 —— 拖动会沿用记忆里的颜色，见 lastRgbByKey。
    if (!busy && ref.alpha) {
      var parsed = parseColor(displayValue(key));
      var transparent = !!parsed && parsed.a === 0;
      ref.alpha.disabled = !parsed || (transparent && !lastRgbByKey[key]);
    }
  });
}

function setBusy(busy, message) {
  state.busy = busy;
  updateButtons();
  setRowControlsDisabled(busy);
  if (busy && message) setStatus(message, 'busy');
}

/* ============================================================================
 * 11. 弹窗
 * ==========================================================================*/

function openModal(mode, title, hint, text) {
  state.modalMode = mode;
  // 记住打开弹窗前焦点在哪，关闭后还回去（否则键盘用户会掉回页面顶部）
  state.modalReturnFocus = document.activeElement;
  $('modal-title').textContent = title;
  $('modal-hint').textContent = hint;
  var area = $('modal-text');
  area.value = text || '';
  area.readOnly = mode === 'export';
  if (mode === 'export') area.select();
  $('modal-ok').textContent = mode === 'export' ? '复制并关闭' : '确定';
  $('modal').hidden = false;
  area.focus();
}

function closeModal() {
  var modal = $('modal');
  if (modal) modal.hidden = true;
  var back = state.modalReturnFocus;
  state.modalReturnFocus = null;
  if (back && typeof back.focus === 'function') {
    try { back.focus(); } catch (e) { /* 元素可能已被替换，忽略 */ }
  }
}

/** 弹窗打开时把 Tab 圈在面板内，避免焦点跑到背后的行编辑器上。 */
function trapModalFocus(event) {
  var panel = $('modal-panel') || $('modal');
  if (!panel) return;
  var nodes = panel.querySelectorAll('button, textarea, input, [tabindex]:not([tabindex="-1"])');
  var list = Array.prototype.filter.call(nodes, function (node) {
    return !node.disabled && node.offsetParent !== null;
  });
  if (list.length < 2) return;
  var first = list[0];
  var last = list[list.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }
  return Promise.reject(new Error('clipboard unavailable'));
}

function onModalOk() {
  if (state.modalMode === 'export') {
    var area = $('modal-text');
    area.select();
    copyText(area.value).then(function () {
      showToast('已复制到剪贴板', 'ok');
    }).catch(function () {
      showToast('请手动复制（Ctrl+C）');
    });
    closeModal();
    return;
  }
  doImport();
}

/** 复制调色板 dump（含未应用改动），方便贴 issue / 对比。 */
function copyDump() {
  copyText($('dump').textContent || '').then(function () {
    showToast('调色板 JSON 已复制', 'ok');
  }).catch(function () {
    showToast('复制失败，请手动选择文本');
  });
}

/* ============================================================================
 * 12. 引导
 * ==========================================================================*/

function isTypingTarget(node) {
  if (!node || !node.tagName) return false;
  var tag = node.tagName.toLowerCase();
  return tag === 'input' || tag === 'textarea' || tag === 'select' || node.isContentEditable === true;
}

/** 搜索结果里第一个可见行的可编辑控件 —— 让键盘用户按回车能直接开始改。 */
function firstVisibleRow() {
  var wrap = document.querySelector('.row-wrap:not([hidden])');
  if (!wrap) return null;
  // 只返回可键入的输入框：色块是 type=color，聚焦它既不能打字、也不会弹出色板
  // （浏览器只在点击时弹），键盘用户按回车会卡在那里。
  return wrap.querySelector('input.hex, input.raw');
}

function wireEvents() {
  $('mode-light').addEventListener('click', function () { setMode('light'); });
  $('mode-dark').addEventListener('click', function () { setMode('dark'); });
  // 标签式控件按惯例支持左右方向键切换
  ['mode-light', 'mode-dark'].forEach(function (id) {
    $(id).addEventListener('keydown', function (event) {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
      event.preventDefault();
      var next = event.key === 'ArrowLeft' ? 'light' : 'dark';
      setMode(next);
      $(next === 'light' ? 'mode-light' : 'mode-dark').focus();
    });
  });

  $('btn-apply').addEventListener('click', applyTheme);
  $('btn-reset').addEventListener('click', resetTheme);
  $('btn-export').addEventListener('click', exportTheme);
  $('btn-import').addEventListener('click', openImport);
  $('btn-reload').addEventListener('click', function () { reloadPalette({}); });
  $('btn-revert-mode').addEventListener('click', revertMode);

  var search = $('row-search');
  if (search) {
    search.addEventListener('input', function () { setFilter(search.value); });
    search.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        clearFilter();
      } else if (event.key === 'Enter') {
        event.preventDefault();
        var first = firstVisibleRow();
        if (first) first.focus();
      }
    });
  }
  if ($('search-clear')) $('search-clear').addEventListener('click', clearFilter);
  if ($('only-dirty')) {
    $('only-dirty').addEventListener('change', function () { setOnlyDirty($('only-dirty').checked); });
  }
  if ($('btn-toggle-groups')) $('btn-toggle-groups').addEventListener('click', toggleAllGroups);
  if ($('btn-copy-dump')) $('btn-copy-dump').addEventListener('click', copyDump);
  if ($('notice-close')) $('notice-close').addEventListener('click', hideNotice);

  $('theme-enabled').addEventListener('change', function () { renderDump(); updateButtons(); });
  if ($('theme-name')) $('theme-name').addEventListener('input', renderDump);

  $('modal-close').addEventListener('click', closeModal);
  $('modal-cancel').addEventListener('click', closeModal);
  $('modal-ok').addEventListener('click', onModalOk);
  $('modal').addEventListener('click', function (event) {
    if (event.target === $('modal')) closeModal();
  });

  document.addEventListener('keydown', function (event) {
    var modalOpen = !$('modal').hidden;
    if (event.key === 'Escape' && modalOpen) { closeModal(); return; }
    if (event.key === 'Tab' && modalOpen) { trapModalFocus(event); return; }
    // 弹窗打开时不响应全局快捷键，否则会在用户看不到的背景下触发应用/搜索
    if (modalOpen) return;
    if ((event.ctrlKey || event.metaKey) && (event.key === 'Enter' || event.key === 'NumpadEnter')) {
      event.preventDefault();
      applyTheme();
      return;
    }
    if (event.key === '/' && !isTypingTarget(event.target) && !event.ctrlKey && !event.metaKey) {
      event.preventDefault();
      if (search) search.focus();
    }
  });
}

function setMode(mode) {
  state.mode = mode;
  $('mode-light').classList.toggle('is-active', mode === 'light');
  $('mode-dark').classList.toggle('is-active', mode === 'dark');
  $('mode-light').setAttribute('aria-selected', mode === 'light' ? 'true' : 'false');
  $('mode-dark').setAttribute('aria-selected', mode === 'dark' ? 'true' : 'false');
  syncAll();
}

function bootstrap() {
  buildEditor();
  wireEvents();
  setMode('light');
  // 先按本地状态渲染，保证面板不会白屏；随后用 get_theme 校准。
  syncAll();
  applyFilters();
  reloadPalette({});
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrap);
} else {
  bootstrap();
}
