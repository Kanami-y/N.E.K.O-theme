﻿<#
  probe.ps1 -- dot-sourceable helper that runs the computed-style fixture in real headless Chrome.

  Why this exists: the stylesheet's core invariant is
      property: var(--nts-x, <NATIVE COMPUTED VALUE>) !important;
  and it only holds if <NATIVE COMPUTED VALUE> is what the browser actually produced.
  Hand-written fallbacks were measured wrong 25 times on the first attempt, so every
  fallback in the generated CSS now comes from this probe.

  Usage (dot-source, then call):
      . "$PSScriptRoot\probe.ps1"
      $r = Invoke-NtsProbe -Mode native -Theme light -WithCss $false

  Returns the parsed JSON the page wrote into #nts-out:
      { mode, theme, mine, diag, rows[], rowsThemed[], unavailable{} }

  ASCII only on purpose: this repo is edited from Windows PowerShell 5.1, which mis-decodes
  BOM-less UTF-8 script files and dies with "missing terminator" on non-ASCII source.
#>
[CmdletBinding()]
param()

$script:NtsAppRoot = if ($env:NTS_APP_ROOT) { $env:NTS_APP_ROOT } else { 'D:\tools\enokoo' }
$script:NtsStudio  = if ($env:NTS_STUDIO)  { $env:NTS_STUDIO }  else { 'D:\tools\enokoo\theme-studio' }
$script:NtsBase    = if ($env:NTS_BASE)    { $env:NTS_BASE }    else { 'http://127.0.0.1:48911' }

function Get-NtsChrome {
  $cCands = @()
  if ($env:NTS_BROWSER_PATH) { $cCands += $env:NTS_BROWSER_PATH }
  if ($env:CHROME_PATH)      { $cCands += $env:CHROME_PATH }
  $cCands += @(
    $env:NTS_BROWSER_PATH
    $env:CHROME_PATH
    'C:\Program Files\Chrome\App\chrome.exe'
    'C:\Program Files\Google\Chrome\Application\chrome.exe'
    'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
    $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe' })
    'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
    'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
  )
  $c = $cCands | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
  if (-not $c) { throw 'no Chromium browser found: 用环境变量 NTS_BROWSER_PATH 指定 chrome.exe 完整路径（chrome-headless-shell 也可）。' }
  return $c
}

function New-NtsFixture {
  <# Writes the probe fixture into the app's served static dir and returns its URL path. #>
  $fixture = Join-Path $script:NtsStudio 'test\fixture.html'
  if (-not (Test-Path $fixture)) { throw "fixture missing: $fixture" }
  $src = [System.IO.File]::ReadAllText($fixture)
  if ($src.IndexOf('<!--NTS_CSS_HOOK-->') -lt 0) { throw 'fixture has no <!--NTS_CSS_HOOK--> placeholder' }
  if ($src.IndexOf('/*NTS_TARGETS_JS*/') -lt 0) { throw 'fixture has no /*NTS_TARGETS_JS*/ placeholder' }

  # inline the target table so the page and the generator share one source of truth
  $targetsJs = [System.IO.File]::ReadAllText((Join-Path $script:NtsStudio 'test\targets.js'))
  $targetsJs = $targetsJs -replace '(?s)if \(typeof module[\s\S]*$', ''
  $src = $src.Replace('/*NTS_TARGETS_JS*/', $targetsJs)

  $probeName = '_nts_probe_fixture.html'
  $probePath = Join-Path $script:NtsAppRoot ('resources\bin\static\' + $probeName)
  $cssUrl = "$($script:NtsBase)/static/css/neko-theme-studio.css"
  $linkTag = "<link rel=`"stylesheet`" href=`"$cssUrl`">"
  $html = if ($WithCssGlobal) { $src.Replace('<!--NTS_CSS_HOOK-->', $linkTag) } else { $src.Replace('<!--NTS_CSS_HOOK-->', '') }
  [System.IO.File]::WriteAllText($probePath, $html, (New-Object System.Text.UTF8Encoding($false)))
  return $probeName
}

$script:WithCssGlobal = $false

function Invoke-NtsProbe {
  [CmdletBinding()]
  param(
    [ValidateSet('native', 'sentinel')] [string]$Mode = 'native',
    [ValidateSet('light', 'dark')]     [string]$Theme = 'light',
    [switch]$WithCss,
    [string]$Tag = ''
  )
  $script:WithCssGlobal = [bool]$WithCss
  $probeName = New-NtsFixture
  $chrome = Get-NtsChrome

  if (-not $Tag) { $Tag = "$Mode-$Theme-$(if ($WithCss) { 'mine' } else { 'base' })" }
  $tmp = Join-Path $env:TEMP ('nts-probe-' + $Tag)
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  $dom = Join-Path $tmp 'out.dom.html'
  $udd = Join-Path $tmp 'udd'
  $url = "$($script:NtsBase)/static/$probeName" + "?mode=$Mode" + $(if ($Theme -eq 'dark') { '&theme=dark' } else { '' })

  $argv = @(
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-extensions', "--user-data-dir=$udd", '--virtual-time-budget=10000',
    '--allow-file-access-from-files', '--dump-dom', $url
  )
  # Chrome writes progress/warning noise to stderr (e.g. "externally_managed_app_manager
  # ... failed to install with reason 21"). Under $ErrorActionPreference='Stop' inherited
  # from the caller, PowerShell 5.1 turns any native stderr into a terminating error and
  # the probe dies mid-run. The DOM on stdout is the only thing that matters here, so
  # relax the preference just for this call.
  $prevEap = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try {
    & $chrome @argv 2>$null | Set-Content -LiteralPath $dom -Encoding UTF8
  } finally {
    $ErrorActionPreference = $prevEap
  }
  if (-not (Test-Path $dom)) { throw "probe '$Tag' produced no dom dump (chrome failed to start?)" }
  $txt = [System.IO.File]::ReadAllText($dom)
  $m = [regex]::Match($txt, '(?s)<pre id="nts-out"[^>]*>(.*?)</pre>')
  if (-not $m.Success) { throw "probe '$Tag' produced no #nts-out (chrome run failed?)" }
  $json = [System.Net.WebUtility]::HtmlDecode($m.Groups[1].Value)
  try { return $json | ConvertFrom-Json } catch { throw "probe '$Tag' JSON parse failed: $($_.Exception.Message)" }
}

function Remove-NtsFixture {
  $p = Join-Path $script:NtsAppRoot 'resources\bin\static\_nts_probe_fixture.html'
  Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
  Get-ChildItem -Path $env:TEMP -Filter 'nts-probe-*' -Directory -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

function Assert-NtsServices {
  <# Both servers must be up or every measurement is void. #>
  foreach ($u in @("$($script:NtsBase)/static/css/index.css")) {
    try { $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 5 }
    catch { throw "app server not reachable: $u -- $($_.Exception.Message)" }
    if ($r.StatusCode -ne 200) { throw "app server returned $($r.StatusCode) for $u" }
  }
  return $true
}

function Invoke-NtsPaletteReset {
  <# Empty the saved palette through the plugin's own entry, so the A/B zero-change check
     compares like with like: with a non-empty palette every measured difference is just
     the user's own colour, and the harness cannot tell a defect from a feature.

     Drives the panel's calling convention (CSRF -> POST /runs -> poll GET /runs/{id}).
     Returns the resulting theme.json object, or $null when the plugin is unreachable. #>
  $base = 'http://127.0.0.1:48916'
  $plugin = 'neko_theme_studio'
  try {
    $csrf = ''
    try {
      $c = Invoke-RestMethod -Uri "$base/security/csrf-token" -Method Get -TimeoutSec 8
      $csrf = [string]$c.csrf_token
    } catch { }
    $hdr = @{}
    if ($csrf) { $hdr['X-CSRF-Token'] = $csrf }
    $body = '{"plugin_id":"' + $plugin + '","entry_id":"reset_theme","args":{}}'
    $r = Invoke-RestMethod -Uri "$base/runs" -Method Post -Headers $hdr `
           -ContentType 'application/json; charset=utf-8' `
           -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 20
    $runId = if ($r.run_id) { $r.run_id } elseif ($r.id) { $r.id } else { '' }
    if (-not $runId) { return $null }
    for ($i = 0; $i -lt 50; $i++) {
      Start-Sleep -Milliseconds 500
      $st = Invoke-RestMethod -Uri "$base/runs/$runId" -Method Get -TimeoutSec 10
      if ($st.status -eq 'succeeded') { break }
      if ($st.status -in @('failed', 'canceled', 'timeout')) { return $null }
    }
    return (Invoke-RestMethod -Uri "$base/plugin/$plugin/ui/theme.json" -Method Get -TimeoutSec 8)
  } catch {
    Write-Host ("   WARNING: could not reset the palette: {0}" -f $_.Exception.Message)
    return $null
  }
}
