/*!
 * gen-css.js -- theme-studio/tools/gen-css.js -- do not edit the OUTPUT by hand.
 * ---------------------------------------------------------------------------
 * Reads:  build/native-light.json, build/native-dark.json   (measurement, INFORMATIONAL ONLY)
 *         test/targets.js                                   (the single source of truth)
 *         test/ab-baseline.json + build/ab.json             (real-page A/B history, informational)
 * Writes: <out.css>, <out.vars.json>
 *
 * ---------------------------------------------------------------------------
 * DESIGN (v3) -- the "unconfigured == not loaded" invariant is CONSTRUCTIVE
 * ---------------------------------------------------------------------------
 * v1/v2 tried to bake a measured native value into each declaration:
 *
 *     :root:root body SEL { prop: var(--nts-x, <measured native>) !important; }
 *
 * and claimed that with no variable set the rule resolves to the native value.
 * That claim was FALSE, and an independent verifier proved it on the real page:
 *
 *   - .chat-body        ours rgba(255,255,255,.91)  native rgba(0,0,0,0)
 *   - .composer-galgame-btn ours rgba(36,151,217,.45) native rgb(36,151,217)
 *   - .send-button-circle   ours rgba(0,0,0,0)      native rgba(160,220,255,.26)
 *   - .proactive-recommendation-card ours rgba(108,151,174,.18) native rgb(34,34,34)
 *
 * Root cause: getComputedStyle returns the RESOLVED value of the widget as it
 * exists in the MEASURING page. The measuring fixture cannot reproduce the real
 * page's cascade:
 *   * .chat-body in the real app sits under .chat-surface-mode-compact, where a
 *     LATER, equally-specific `.chat-window.chat-surface-mode-compact .chat-body
 *     { background: transparent }` wins -- the fixture had no such ancestor and
 *     recorded the earlier, losing rule.
 *   * .composer-galgame-btn in the real app sits under .compact-input-tool-fan,
 *     where a HIGHER-specificity rule wins.
 *   * The app's <body> carries .electron-chat-window, disabling a whole
 *     `body:not(.electron-chat-window) ...` rule; the fixture's body does not.
 *   * The app injects a runtime <style> layer with !important that the fixture
 *     cannot see at all.
 * So "the measured native value" is not a property of the target; it is a
 * property of the measuring page. Baking it in silently restyles an
 * unconfigured app. Every fallback we can measure can be wrong.
 *
 * v3 therefore emits NO fallbacks at all. Every declaration is gated on a
 * per-mode, per-variable attribute that the app-side loader sets only when the
 * user has actually configured that variable in that mode:
 *
 *   :root:not([data-theme="dark"])[data-nts-l-x]:root:root body SEL { prop: var(--nts-x) !important; }
 *   :root[data-theme="dark"][data-nts-d-x]:root:root body SEL       { prop: var(--nts-x) !important; }
 *
 * Consequences, all by construction rather than by measurement:
 *   1. No attribute set (empty palette) => the ruleset matches nothing => zero
 *      effect. The invariant is provable by reading the selector, and cannot
 *      regress when app CSS changes.
 *   2. Light-only palette: only data-nts-l-* are set, so the dark rules (which
 *      additionally require [data-theme="dark"] AND data-nts-d-*) never match.
 *      A light-only palette cannot damage dark mode. (Verifier counterexample
 *      CE-A: value defined only for dark left `backdrop-filter: var(--x)` with no
 *      value in light, which is invalid-at-computed-value-time and collapsed the
 *      native blur to `none`. Per-mode gates make that unreachable.)
 *   3. Dark-only palette: light rules require data-nts-l-*, which are not set,
 *      so light is untouched. (Verifier counterexample CE-B: the loader wrote
 *      light values into an unscoped `:root{...}`, leaking a light colour into
 *      dark mode. Light values are now scoped to :root:not([data-theme="dark"]).)
 *   4. The measured values are still written to <out.vars.json> as *reference
 *      text for the panel* (native / darkNative), and still checked by the
 *      fixture harness for coverage. They are never emitted as CSS.
 *
 * Per-mode semantics were chosen by the user: the "light" group affects light
 * mode only, the "dark" group affects dark mode only.
 */

var fs = require('fs');
var path = require('path');

var targetsMod = require(path.join(__dirname, '..', 'test', 'targets.js'));
var NTS_TARGETS = targetsMod.NTS_TARGETS;
var NTS_GATED = targetsMod.NTS_GATED;

var GATE_ATTR = 'data-nts-';
var ACTIVE_ATTR = 'data-nts-active';

/* Mode tag inside the gate attribute name. Must match the loader's gateAttrFor(). */
function gateAttrFor(varName, mode) {
  var suffix = String(varName).replace(/^--nts-/, '');
  return GATE_ATTR + (mode === 'dark' ? 'd-' : 'l-') + suffix;
}

/* Specificity is deliberately overkill: the native dark sheet uses
 * `[data-theme="dark"] SEL` (0,3,0) and some rules carry !important, and the
 * app's runtime <style> layer also uses !important. Native also uses plain
 * `SEL` and `#id SEL` forms. Repeating :root is legal (it matches the same
 * <html> element) and is the standard way to outrank them:
 *   light prefix = (0,4,1) + SEL      vs  native max (0,3,0) + SEL
 *   dark  prefix = (0,6,1) + SEL
 * Both sides carry !important, so specificity decides. */
function gatePrefix(varName, mode) {
  var attr = gateAttrFor(varName, mode);
  return mode === 'dark'
    ? ':root[data-theme="dark"][' + attr + ']:root:root body '
    : ':root:not([data-theme="dark"])[' + attr + ']:root:root body ';
}

function joinSel(prefix, sel) {
  if (!sel) return prefix.replace(/\s+$/, '');
  if (sel.indexOf('::') === 0) return prefix.replace(/\s+$/, '') + ' ' + sel;
  return prefix + sel;
}

/* Every property we are allowed to write, and how to write it. No fallbacks:
 * the whole point of v3 is that a gated rule only ever fires with a value the
 * user actually supplied. */
var GATE_DECL = {
  'background-color': function (v) { return ['background-color: var(' + v + ') !important;']; },
  'color': function (v) { return ['color: var(' + v + ') !important;']; },
  'border-color': function (v) { return ['border-color: var(' + v + ') !important;']; },
  'border-top-color': function (v) { return ['border-top-color: var(' + v + ') !important;']; },
  'border-right-color': function (v) { return ['border-right-color: var(' + v + ') !important;']; },
  'border-bottom-color': function (v) { return ['border-bottom-color: var(' + v + ') !important;']; },
  'border-left-color': function (v) { return ['border-left-color: var(' + v + ') !important;']; },
  /* outline-color alone is inert (an outline also needs width+style), so the
   * whole shorthand is written from the one colour variable. */
  'outline-color': function (v) {
    return ['outline: 1.5px solid var(' + v + ') !important;',
            'outline-offset: -1.5px !important;'];
  },
  /* Native backdrop-filter is a specific blur+saturate chain, but that does not
   * matter any more: the rule only exists when the user set the variable. */
  'backdrop-filter': function (v) {
    return ['backdrop-filter: var(' + v + ') !important;',
            '-webkit-backdrop-filter: var(' + v + ') !important;'];
  },
  'box-shadow': function (v) { return ['box-shadow: var(' + v + ') !important;']; },
  'font-size': function (v) { return ['font-size: var(' + v + ') !important;']; },
  /* A user-set radius applies to all four corners; unset means native keeps its
   * own (frequently asymmetric) corners, because no rule matches. */
  'border-radius': function (v) {
    return ['border-top-left-radius: var(' + v + ') !important;',
            'border-top-right-radius: var(' + v + ') !important;',
            'border-bottom-right-radius: var(' + v + ') !important;',
            'border-bottom-left-radius: var(' + v + ') !important;'];
  }
};

/* 单个 target 的声明展开：自定义属性直接 var() 桥接，普通属性查 GATE_DECL。 */
function declLines(prop, v) {
  if (prop.indexOf('--') === 0) return [prop + ': var(' + v + ') !important;'];
  return GATE_DECL[prop](v);
}

function main() {
  var a = process.argv.slice(2);
  if (a.length < 4) {
    console.error('usage: node gen-css.js <light.json> <dark.json> <out.css> <out.vars.json> [ab.json]');
    process.exit(2);
  }
  var light = JSON.parse(fs.readFileSync(a[0], 'utf8'));
  var dark = JSON.parse(fs.readFileSync(a[1], 'utf8'));
  var outCss = a[2], outVars = a[3];

  var warn = [];
  var all = [];   /* emitted targets */
  var aux = [];   /* measurement-only */

  NTS_TARGETS.forEach(function (t) {
    if (t.aux) { aux.push(t); return; }
    if (!t.v) { warn.push('[SKIP no var] ' + t.sel + ' | ' + t.prop); return; }
    /* 自定义属性（--foo）走「桥接」：值永远是 var(--nts-x)。这是紧凑胶囊
     * （--compact-chat-surface-bg 等）能像普通属性一样被变量控制的关键。 */
    if (t.prop.indexOf('--') !== 0 && !GATE_DECL[t.prop]) { warn.push('[SKIP no template] ' + t.sel + ' | ' + t.prop); return; }
    all.push({ sec: t.sec, sel: t.sel, prop: t.prop, v: t.v, kind: t.kind, gate: true });
  });

  /* ---------- gradients that would paint over a colour we control ----------
   * If the element's background-image is a gradient, setting only
   * background-color leaves the user's colour invisible. Emit a matching
   * `background-image: none` under the SAME variable's gate, so it appears and
   * disappears together with the colour. */
  var killImage = [];
  var seenKill = {};
  aux.forEach(function (t) {
    if (t.prop !== 'background-image') return;
    var lr = null, dr = null;
    light.rows.forEach(function (r) { if (r.sel === t.sel && r.prop === 'background-image') lr = r; });
    dark.rows.forEach(function (r) { if (r.sel === t.sel && r.prop === 'background-image') dr = r; });
    var grad = false;
    [lr, dr].forEach(function (r) { if (r && r.val && r.val !== 'none') grad = true; });
    if (!grad) return;
    all.forEach(function (e) {
      if (e.sel !== t.sel || e.prop !== 'background-color') return;
      var key = e.v + '|' + e.sel;
      if (seenKill[key]) return;
      seenKill[key] = 1;
      killImage.push({ v: e.v, sel: e.sel });
    });
  });

  /* ---------- emit ---------- */
  var out = [];

  /* ---------------------------------------------------------------------------
   * THE CASCADE LAYER — this is not cosmetic, it is the fix for the single
   * largest class of "I changed a colour and nothing happened" reports.
   *
   * For NORMAL declarations, unlayered beats layered. For !important
   * declarations the order REVERSES: a layered !important beats an unlayered
   * !important. (CSS Cascade 5, §6.4.4; verified on this exact app build with a
   * live feature test — `importantInLayerWins === "2px"`.)
   *
   * The app's own index.css ships rules like
   *     body.subtitle-web-host #react-chat-window-shell[data-chat-surface-mode="compact"]:not(.is-minimized) #react-chat-window-root { background-color: transparent !important }
   * which carry TWO id selectors -> specificity (2,4,1). Our gated prefix
   *     :root:not([data-theme="dark"])[data-nts-l-x]:root:root body SEL
   * carries ZERO ids -> (0,4,1)+SEL. Repeating :root can never close that gap
   * (it only adds class-level weight). Both sides are !important, so specificity
   * decides and we lose every time — measured on the real page:
   *     #react-chat-window-root   background-color  stayed rgba(0,0,0,0)
   *     .chat-window              background-color  stayed rgba(0,0,0,0)
   *     .composer-panel           background-color  stayed rgba(0,0,0,0)
   *     .composer-panel           box-shadow        stayed none
   * Wrapping the whole sheet in a layer flips the !important order and all four
   * win, while the "unconfigured == not loaded" invariant is untouched: with an
   * empty palette no gate attribute exists, so no rule inside the layer matches.
   * ------------------------------------------------------------------------- */
  out.push('@layer nts-theme {');
  out.push('');
  out.push('/*!');
  out.push(' * neko-theme-studio.css -- N.E.K.O theme studio, static style layer');
  out.push(' * ---------------------------------------------------------------------------');
  out.push(' * GENERATED by theme-studio/tools/gen-css.js -- do not edit by hand.');
  out.push(' *');
  out.push(' * EVERY rule is gated on `data-nts-l-<var>` (light mode) or');
  out.push(' * `data-nts-d-<var>` (dark mode), attributes the app-side loader sets only');
  out.push(' * for variables the user actually configured IN THAT MODE. There are no');
  out.push(' * baked-in fallbacks, because a fallback measured in a synthetic fixture is');
  out.push(' * not the real page\'s computed value (see the generator header for the four');
  out.push(' * independent counterexamples). Therefore:');
  out.push(' *   * empty palette      -> no attributes -> no rule matches -> zero effect');
  out.push(' *   * light-only palette -> dark rules additionally require [data-theme="dark"]');
  out.push(' *                           and data-nts-d-*, so dark mode is untouched');
  out.push(' *   * dark-only palette  -> light rules additionally require');
  out.push(' *                           data-nts-l-*, so light mode is untouched');
  out.push(' *');
  out.push(' * Safety: colours, backgrounds, borders, radii, fonts, shadow, blur only.');
  out.push(' * Never display/position/width/height/flex/overflow/z-index/transform.');
  out.push(' * Loaded AFTER dark-mode.css (install.ps1 template patch guarantees the order).');
  out.push(' *');
  out.push(' * WRAPPED IN @layer nts-theme: for !important declarations a LAYERED rule');
  out.push(' * beats an UNLAYERED one, which is the only way to outrank the app\'s own');
  out.push(' * two-id !important rules (e.g. `... #react-chat-window-root{background-color:');
  out.push(' * transparent!important}` in index.css). Specificity alone can never win.');
  out.push(' */');
  out.push('');

  var emitted = 0;

  /* Section order mirrors targets.js so the file reads like the panel. */
  var secs = [];
  all.forEach(function (e) { if (secs.indexOf(e.sec) < 0) secs.push(e.sec); });

  secs.forEach(function (sec) {
    var list = all.filter(function (e) { return e.sec === sec; });
    out.push('/* ===================== ' + sec + ' ===================== */');
    out.push('');
    ['light', 'dark'].forEach(function (mode) {
      /* group rules by (var, sel) so one gate block carries all declarations
       * the same variable makes on the same element */
      var order = [], groups = {};
      list.forEach(function (e) {
        var k = e.v + '\u0000' + e.sel;
        if (!groups[k]) { groups[k] = { v: e.v, sel: e.sel, props: [] }; order.push(k); }
        groups[k].props.push(e.prop);
      });
      if (!order.length) return;
      out.push('/* --- ' + sec + ' : ' + mode + ' (' + order.length + ' rule(s)) --- */');
      out.push('');
      order.forEach(function (k) {
        var g = groups[k];
        out.push(joinSel(gatePrefix(g.v, mode), g.sel) + ' {');
        g.props.forEach(function (p) {
          declLines(p, g.v).forEach(function (line) { out.push('  ' + line); });
        });
        out.push('}');
        out.push('');
        emitted++;
      });
    });
  });

  /* ---------- gradient killers (same gate as the colour they protect) ------ */
  if (killImage.length) {
    out.push('/* ===================== background-image kill (gradient would hide the colour) ===================== */');
    out.push('');
    killImage.forEach(function (k) {
      ['light', 'dark'].forEach(function (mode) {
        out.push(joinSel(gatePrefix(k.v, mode), k.sel) + ' { background-image: none !important; }');
      });
      out.push('');
    });
  }

  /* ---------- scrollbars ---------------------------------------------------
   * Chromium 121+ ignores ::-webkit-scrollbar-* once scrollbar-color is set,
   * and native dark uses `[data-theme="dark"] * { scrollbar-color: ... !important }`
   * as a finisher, so we must write scrollbar-color itself. */
  out.push('/* ===================== scrollbars ===================== */');
  out.push('');
  ['light', 'dark'].forEach(function (mode) {
    var thumb = NTS_GATED.scrollbar.thumbVar;
    var track = NTS_GATED.scrollbar.trackVar;
    var pair = 'var(' + thumb + ') var(' + track + ')';
    /* `body` colours the body's OWN scrollbar; `*` lets every descendant
     * scroll container inherit. The previous version emitted
     * `body > body` (impossible — body has no body child, so it matched
     * nothing) and `body > *`, which only worked by inheritance. */
    ['body', '*'].forEach(function (tgt) {
      /* require BOTH variables in this mode, so the pair is always fully defined */
      var attr = gateAttrFor(thumb, mode);
      var attr2 = gateAttrFor(track, mode);
      var head = mode === 'dark'
        ? ':root[data-theme="dark"][' + attr + '][' + attr2 + ']:root'
        : ':root:not([data-theme="dark"])[' + attr + '][' + attr2 + ']:root';
      out.push(head + ':root ' + tgt + ' { scrollbar-color: ' + pair + ' !important; }');
    });
  });
  out.push('');

  /* ---------- chat surface opacity ----------------------------------------
   * Bridges the native multiplier: native CSS reads
   * `rgba(..., calc(.91 * var(--neko-chat-opacity-factor, 1)))`, so overriding
   * the factor scales every surface at once. Requires a number 0-1. */
  out.push('/* ===================== chat surface opacity (native factor bridge) ===================== */');
  out.push('');
  ['light', 'dark'].forEach(function (mode) {
    var v = NTS_GATED.chatOpacity.varName;
    var attr = gateAttrFor(v, mode);
    var head = mode === 'dark'
      ? ':root[data-theme="dark"][' + attr + ']'
      : ':root:not([data-theme="dark"])[' + attr + ']';
    out.push(head + ' { --neko-chat-opacity-factor: var(' + v + ') !important; }');
  });
  out.push('');

  /* ---------- plugin view layer bridge ------------------------------------
   * agent-plugin-views.css already consumes five --neko-popup-* variables, so we
   * take those over. Each is gated on ITS OWN variable and mode: mapping one
   * colour must not drag the other four (and their baked fallbacks) into the
   * other mode. */
  out.push('/* ===================== plugin view layer bridge ===================== */');
  out.push('');
  Object.keys(NTS_GATED.popupBridge.map).forEach(function (target) {
    var m = NTS_GATED.popupBridge.map[target];
    var v = m[0];
    /* 可选第三项是模板：{v} 会被替换成 var(--nts-*)。
     * 用于 --neko-popup-border 这种「1px solid <colour>」简写变量。 */
    var value = m.length > 2 ? String(m[2]).replace('{v}', 'var(' + v + ')') : 'var(' + v + ')';
    ['light', 'dark'].forEach(function (mode) {
      var attr = gateAttrFor(v, mode);
      var head = mode === 'dark'
        ? ':root[data-theme="dark"][' + attr + ']'
        : ':root:not([data-theme="dark"])[' + attr + ']';
      NTS_GATED.popupBridge.sel.forEach(function (sel) {
        /* !important is NOT optional here. dark-mode.css assigns these same
         * --neko-popup-* variables itself (e.g. `[data-theme="dark"] #agent-task-hud
         * { background: var(--neko-popup-bg) !important }` plus the variable
         * definitions on :root). Both sides set a custom property on the same
         * element, so specificity/order decides — the bridge lost without it. */
        out.push(head + ' body ' + sel + ' { ' + target + ': ' + value + ' !important; }');
      });
    });
  });
  out.push('');

  /* ---------- global font family ------------------------------------------
   * TWO bridges, because `body { font-family }` alone does NOT reach the chat
   * content. The React sheet forces the content font explicitly:
   *   .message-block-text,.message-block-markdown,.composer-input,
   *   .compact-chat-capsule-text{font-family:var(--neko-chat-content-font)}
   * so a body-level declaration is overridden on exactly the elements the user
   * is looking at (bubble text and the input box). Measured before this fix:
   * body font-family became monospace while the input stayed
   * "Neko Chat Hand", "Segoe UI", ... — the setting looked dead.
   * Overriding --neko-chat-content-font hits every consumer at once (verified:
   * the input's computed font-family flips to monospace). */
  out.push('/* ===================== global font family ===================== */');
  out.push('');
  ['light', 'dark'].forEach(function (mode) {
    var v = NTS_GATED.fontFamily.varName;
    var attr = gateAttrFor(v, mode);
    var head = mode === 'dark'
      ? ':root[data-theme="dark"][' + attr + ']:root:root'
      : ':root:not([data-theme="dark"])[' + attr + ']:root:root';
    out.push(head + ' body { font-family: var(' + v + ') !important; }');
    /* The two app-level font variables must be overridden too: the React sheet
     * reads --neko-chat-content-font on bubble text / input, and --neko-ui-font
     * on .app-shell + every dialog. Without these two lines the setting changes
     * only parts of the UI (or nothing visible at all). */
    out.push(head + ' { --neko-chat-content-font: var(' + v + ') !important; }');
    out.push(head + ' { --neko-ui-font: var(' + v + ') !important; }');
    /* Font-size guard — NOT cosmetic.
     *
     * The React sheet has `:root{font-family:var(--neko-ui-font)}`, and our line
     * above points that variable at the user's family. When the user picks a
     * GENERIC family (monospace / serif / cursive), Chromium re-resolves :root's
     * initial `medium` size against that family's default table: monospace is
     * 13px, so the ENTIRE app shrinks from 16px to 13px — every rem, every
     * spacing token, the whole layout, not just the chat text. Measured: html
     * 16px -> 13px, .composer-panel 16px -> 13px.
     *
     * Pinning font-size:16px restores it (1rem/16px both work; medium/unset/100%
     * do NOT — they still resolve through the 13px table).
     *
     * Deliberately WITHOUT !important and inside @layer nts-theme: if the app
     * ever sets a root font-size itself, an unlayered (or unlayered !important)
     * declaration still wins — verified 20px and 22px !important both override
     * this guard. So the guard only repairs the collateral damage it caused. */
    out.push(head + ' { font-size: 16px; }');
  });
  out.push('');

  /* close the @layer nts-theme block opened right after `var out = []` */
  out.push('}');
  out.push('');

  fs.mkdirSync(path.dirname(outCss), { recursive: true });
  fs.writeFileSync(outCss, out.join('\n') + '\n', 'utf8');

  /* ---------- reference report for the panel ------------------------------
   * native/darkNative are DISPLAY TEXT ONLY. They are never emitted as CSS, and
   * they are only as trustworthy as the measuring page -- that is exactly why
   * they no longer appear in any declaration. */
  var LI = new Map(), DI = new Map();
  light.rows.forEach(function (r) { LI.set(r.sel + '|' + r.prop, r); });
  dark.rows.forEach(function (r) { DI.set(r.sel + '|' + r.prop, r); });

  var report = {};
  all.forEach(function (e) {
    var lr = LI.get(e.sel + '|' + e.prop);
    var dr = DI.get(e.sel + '|' + e.prop);
    if (!report[e.v]) {
      report[e.v] = { kind: e.kind, gate: true, native: null, darkNative: null, sels: [] };
    }
    var r = report[e.v];
    if (lr && lr.val && r.native === null) r.native = lr.val;
    if (dr && dr.val && r.darkNative === null) r.darkNative = dr.val;
    r.sels.push(e.sel + ' | ' + e.prop);
  });

  /* The two bridge variables are consumed by CSS but have no CATALOG control of
   * their own in targets.js; declare them so tooling can see them. */
  fs.writeFileSync(outVars, JSON.stringify(report, null, 2), 'utf8');

  var bytes = fs.statSync(outCss).size;
  console.log('generated : ' + outCss + '  (' + bytes + ' bytes)');
  console.log('targets   : ' + all.length + ' emitted (' + emitted + ' gated rule block(s)), ' +
              aux.length + ' aux-only');
  console.log('gradient kills: ' + killImage.length);
  console.log('vars      : ' + Object.keys(report).length + ' -> ' + outVars);
  console.log('fallbacks : 0 (v3 emits none by design)');
  if (warn.length) { console.log('warnings  : ' + warn.length); warn.forEach(function (w) { console.log('   ' + w); }); }
}

main();
